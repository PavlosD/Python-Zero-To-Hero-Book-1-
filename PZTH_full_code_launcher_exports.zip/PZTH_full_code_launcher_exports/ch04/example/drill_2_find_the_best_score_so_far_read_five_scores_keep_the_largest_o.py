best_score = 0
for i in range(5):
    score = int(input(f"Score {i + 1}: "))
    if score > best_score:          # new highest score?
        best_score = score          # store the new highest score
print("Best score:", best_score)    # highest entered score
