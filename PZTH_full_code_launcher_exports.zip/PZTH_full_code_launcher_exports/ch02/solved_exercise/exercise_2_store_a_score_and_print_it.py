player_score = 120
print(f"Score: {player_score}")    # f-string scoreboard
