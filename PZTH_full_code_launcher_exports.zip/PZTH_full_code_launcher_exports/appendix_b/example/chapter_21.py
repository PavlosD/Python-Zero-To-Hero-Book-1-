player_hand.append(draw_card())    # add the drawn card to the hand
update_screen("Card drawn. Hit or stand?")
