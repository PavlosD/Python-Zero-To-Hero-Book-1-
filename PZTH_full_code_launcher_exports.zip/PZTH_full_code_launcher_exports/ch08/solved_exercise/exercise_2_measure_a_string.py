player_name = "Nara"       # the name len() measures
print(len(player_name))    # name length
