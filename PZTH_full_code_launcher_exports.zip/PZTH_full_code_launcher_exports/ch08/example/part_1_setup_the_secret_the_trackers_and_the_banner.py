secret_word = "relic"    # word to uncover
guessed_letters = []     # letters already attempted
wrong_guesses = 0        # misses made so far
max_wrong = 6            # game ends after six misses

print("================================")
print("          RELIC HANGMAN         ")
print("================================")
print("Guess the relic word one letter at a time.")
print()                  # separate banner from first turn
