# -------------------- setup and helpers ---------------------
def build_stars():                       # rebuild the starfield
    stars.clear()  # reuse the existing list object
    for _ in range(105):
        stars.append({                     # one star per pass
            "x": random.randint(0, WIDTH),
            "y": random.randint(HUD_HEIGHT, HEIGHT),
            "size": random.choice([1, 1, 1, 2, 2, 3]),
            "speed": random.choice([0.25, 0.4, 0.6]),
        })
