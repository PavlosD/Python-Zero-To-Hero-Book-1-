if roll == 6:                 # critical-hit face
    print("Critical hit!")
elif roll >= 4:               # rolls 4 and 5 are solid hits
    print("Solid hit.")
else:
    print("Weak hit.")        # glancing blow
