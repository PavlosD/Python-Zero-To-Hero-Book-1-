button.pack()    # place the button on screen
