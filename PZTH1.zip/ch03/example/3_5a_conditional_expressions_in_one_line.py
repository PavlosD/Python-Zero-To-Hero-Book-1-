score = 80     # current player score
rank = "Pass" if score >= 50 else "Try again"
print(rank)
