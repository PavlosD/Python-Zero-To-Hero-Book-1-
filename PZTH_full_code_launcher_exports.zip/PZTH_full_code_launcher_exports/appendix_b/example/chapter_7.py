inventory = ["key", "map"]        # two-item pack
if "potion" in inventory:         # potion exists before remove
    inventory.remove("potion")    # remove item only if present
