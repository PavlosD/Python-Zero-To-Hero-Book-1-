for i in range(1, 6):              # test values 1 through 5
    if i == 3:                     # skip 3 but keep the loop running
        continue                   # skip the number 3
    print(i)                       # prints 1, 2, 4, 5
