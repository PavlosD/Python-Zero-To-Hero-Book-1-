def cheer(round_number):    # announce the round number
    print(f"Round {round_number} begins!")
for i in range(1, 4):       # announce rounds one to three
    cheer(i)
