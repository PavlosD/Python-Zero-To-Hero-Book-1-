for row in range(3):
    for col in range(4):
        print("#", end="")    # stay on the same row
    print()                   # end the row
