# store the current player location
# choose the destination cell
board = [
    [".", ".", "."],
    [".", "P", "."],
    [".", ".", "."]
]
player_row = 1                         # where the player starts
player_col = 1
new_row = 1
new_col = 2
board[player_row][player_col] = "."    # clear old player cell
