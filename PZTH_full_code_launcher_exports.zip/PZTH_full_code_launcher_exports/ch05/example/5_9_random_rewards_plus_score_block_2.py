import random                         # roll the chest score
score = 0
reward_roll = random.randint(1, 3)    # choose one of three point rewards
reward = reward_roll * 10             # convert roll into reward points
score = score + reward                # add the reward to the total
print(f"You opened a chest and earned {reward} points.")
print(f"Total score: {score}")
