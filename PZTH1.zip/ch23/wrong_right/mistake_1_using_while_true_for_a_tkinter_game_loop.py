# WRONG VERSION - commented out so the launcher can run safely
# while True:
#     update_game()

# RIGHT VERSION
def update_game():
    move_player()
    draw_game()
    window.after(30, update_game)
