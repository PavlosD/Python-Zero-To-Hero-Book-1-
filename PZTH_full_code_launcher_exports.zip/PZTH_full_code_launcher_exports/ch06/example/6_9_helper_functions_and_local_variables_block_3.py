def build_score(points):     # add a flat five-point bonus
    bonus = 5                # flat bonus points
    return points + bonus    # return the boosted score
score = build_score(10)
print(score)
