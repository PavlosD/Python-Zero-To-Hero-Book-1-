# Lowercase input lets Mage, MAGE, and mage match one rule.
player_class = input("Choose a class: ").strip().lower()
if player_class == "mage":          # mages get the bonus
    print("Mana bonus applied.")
