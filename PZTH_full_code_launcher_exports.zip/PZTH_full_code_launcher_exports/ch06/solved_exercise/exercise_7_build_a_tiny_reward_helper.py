def boost_reward(reward):
    return reward + 5        # return the boosted reward

points = boost_reward(20)    # keep the boosted reward for later
print(points)
