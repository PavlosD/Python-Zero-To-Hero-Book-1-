total_damage = 0                        # damage from completed turns
for i in range(5):
    damage = int(input(f"Damage roll {i + 1}: "))
    total_damage = total_damage + damage
print("Total damage:", total_damage)    # damage summed and shown
