player_name = "Nara"         # name used by the string examples below
room_name = "shadow hall"    # lowercase room text
print(player_name)
print(room_name)
