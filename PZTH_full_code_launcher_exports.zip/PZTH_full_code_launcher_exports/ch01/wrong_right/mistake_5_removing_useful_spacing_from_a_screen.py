# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: all lines run together visually
# print("=== CASTLE GATE ===")
# print("A horn sounds.")
# print("Enter before sunset.")

# RIGHT VERSION
# CORRECT: a blank line separates title and message
print("=== CASTLE GATE ===")
print("")
print("A horn sounds.")
print("Enter before sunset.")
