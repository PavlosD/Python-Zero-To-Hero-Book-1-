def clamp(value, low, high):             # keep a coordinate inside arena bounds
    return max(low, min(value, high))    # never below low, never above high

player["x"] = clamp(player["x"] + dx, 24, WIDTH - 24)
player["y"] = clamp(player["y"] + dy, HUD_HEIGHT + 26, HEIGHT - 26)
