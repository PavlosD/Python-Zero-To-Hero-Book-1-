def show_stats(name, health):    # reusable status line
    print(f"{name} has {health} health.")

# The arguments match the parameter order.
show_stats("Juno", 100)
