def load_image(name):          # try to load one sprite
    path = ASSET_DIR / name    # path to the requested sprite
    if path.exists():          # only load a real file
        # load only after the asset path is confirmed
        return tk.PhotoImage(file=str(path))
    return None                # caller falls back to shapes
