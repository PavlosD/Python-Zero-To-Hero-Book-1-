score = 7
print(f"|{score:<5}|")        # left-aligned in 5 characters
print(f"|{score:>5}|")        # right-aligned in 5 characters
print(f"|{'Knight':<10}|")    # strings work too
