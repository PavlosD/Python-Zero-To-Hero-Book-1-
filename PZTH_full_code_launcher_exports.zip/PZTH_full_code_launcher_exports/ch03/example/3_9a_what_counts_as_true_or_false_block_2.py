attempts = 0                     # no failed attempts yet
if not attempts:                 # zero attempts counts as False
    print("first attempt")       # runs because zero is falsy
