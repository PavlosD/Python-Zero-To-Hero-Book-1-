# WRONG VERSION - commented out so the launcher can run safely
# word = "dragon"
# # WRONG: index 6 does not exist
# # print(word[6])

# RIGHT VERSION
word = "dragon"
# CORRECT: index 5 is the last valid position
print(word[5])
