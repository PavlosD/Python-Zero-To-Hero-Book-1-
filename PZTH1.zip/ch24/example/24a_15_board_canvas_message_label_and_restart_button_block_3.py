restart_button = tk.Button(                # Restart button begins a fresh run
    root,                          # button belongs to window
    text="Restart",
    font=("Arial", 12, "bold"),
    command=reset_game,            # Restart rebuilds every Snake field
    bg=ACCENT,
    fg=TEXT,
    activebackground=ACCENT,       # no colour jump on click
    bd=0,
    width=16
)
restart_button.pack(pady=10)       # bottom control spacing
