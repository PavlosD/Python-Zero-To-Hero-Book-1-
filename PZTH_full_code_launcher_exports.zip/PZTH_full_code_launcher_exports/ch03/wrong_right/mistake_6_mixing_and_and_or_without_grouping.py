# WRONG VERSION - commented out so the launcher can run safely
# age = 12
# has_pass = True
# is_vip = False
# # WRONG: the intended age gate is not clear.
# if age >= 13 and has_pass or is_vip:
#     print("Entry allowed.")

# RIGHT VERSION
age = 12
has_pass = True
is_vip = False
# CORRECT: the age gate wraps the pass-or-VIP choice
if age >= 13 and (has_pass or is_vip):
    print("Entry allowed.")
else:
    print("Entry blocked.")
