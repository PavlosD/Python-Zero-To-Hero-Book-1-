a = False
b = True
left_side = not (a or b)            # left side of De Morgan's or law
right_side = (not a) and (not b)    # equivalent form using and
print(left_side)
print(right_side)
print(left_side == right_side)      # verify that both forms match
