import tkinter as tk

window = tk.Tk()
canvas = tk.Canvas(window, width=300, height=300, bg="#111111")
canvas.pack()           # canvas fills the window
canvas.create_rectangle(40, 80, 260, 120, fill="#777777", outline="")
canvas.create_oval(120, 180, 180, 240, fill="#eeeeee", outline="")
canvas.create_text(
    150, 30, text="HUD",
    fill="white", font=("Arial", 14, "bold")
)
window.mainloop()       # run the one-frame Canvas event loop
