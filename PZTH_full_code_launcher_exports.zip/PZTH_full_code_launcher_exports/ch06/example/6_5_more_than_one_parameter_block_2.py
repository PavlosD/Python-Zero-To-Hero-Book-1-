def show_reward(player_name, reward):
    print(f"{player_name} earned {reward} gold!")
show_reward("Sage", 20)
show_reward("Zev", 35)
