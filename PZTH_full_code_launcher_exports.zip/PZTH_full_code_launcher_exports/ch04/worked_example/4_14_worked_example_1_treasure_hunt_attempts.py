treasure_chest = 2                  # chest number two

for attempt in range(1, 4):         # allow three chest choices
    guess = int(input(f"Choose chest {attempt}: "))

    if guess == treasure_chest:     # correct chest selected?
        print("Treasure found!")
        break                       # prize found; end search

print("Search complete.")
