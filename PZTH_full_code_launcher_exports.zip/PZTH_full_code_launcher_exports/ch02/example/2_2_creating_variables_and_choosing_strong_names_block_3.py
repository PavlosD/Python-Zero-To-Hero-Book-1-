player_health = 100
player_name = "Rin"    # name shown in game messages
player_gold = 25
