# ---------------------- drawing helpers ---------------------
def draw_background():                 # repaint space and the playfield frame
    canvas.create_rectangle(0, 0, WIDTH, HEIGHT, fill="#111111", outline="")

    for star in stars:
        x = star["x"]
        y = star["y"]
        size = star["size"]
        canvas.create_oval(x, y, x + size, y + size, fill="#dddddd", outline="")
