with open("save.txt", "w") as file:
    file.write(player_name)
