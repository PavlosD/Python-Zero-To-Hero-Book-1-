player = {                        # ship position and size under named keys
    "x": 380,                  # horizontal center
    "y": 450,                  # near the floor
    "w": 34,                    # width in px
    "h": 32,                    # height in px
}
print(player["x"])             # x position by key
