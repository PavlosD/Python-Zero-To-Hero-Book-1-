password = ""                  # password starts blank
while password != "dragon":
    password = input("Enter the password: ")
print("Access granted.")       # password accepted
