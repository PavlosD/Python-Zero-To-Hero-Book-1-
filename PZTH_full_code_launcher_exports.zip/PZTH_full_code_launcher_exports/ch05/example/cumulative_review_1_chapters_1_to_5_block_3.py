score = 0                              # review score begins at zero
