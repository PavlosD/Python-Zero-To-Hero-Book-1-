def show_damage(base):
    print(base + 3)       # display damage only
