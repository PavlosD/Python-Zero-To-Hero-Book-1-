import random                              # random tools for enemy selection
def choose_monster():                      # pick a random foe name
    monster_roll = random.randint(1, 3)    # choose one of three foes
    if monster_roll == 1:                  # choose the brigand
        return "brigand"
    elif monster_roll == 2:                # choose the drake
        return "drake"
    else:
        return "husk"
monster = choose_monster()                 # chosen enemy for this round
print(f"A {monster} appears!")
