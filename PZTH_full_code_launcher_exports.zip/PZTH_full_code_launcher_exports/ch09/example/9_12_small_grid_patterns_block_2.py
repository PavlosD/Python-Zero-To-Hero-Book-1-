for row in board:           # row by row
    print(" ".join(row))    # display one spaced row
