def place_ship(board, row, col, size, direction):
    if direction == "H":                   # fill cells across one row
        for test_col in range(col, col + size):
            board[row][test_col] = SHIP    # mark this ship cell
    else:                                  # fill cells down one column
        for test_row in range(row, row + size):
            board[test_row][col] = SHIP    # mark this ship cell

