info_frame = tk.Frame(main_frame, bg=BG)    # counter row
info_frame.pack(pady=(0, 8))                # counters under subtitle
enemy_label = tk.Label(info_frame, font=("Arial", 12, "bold"),
                       fg=TEXT, bg=BG, width=22)
enemy_label.grid(row=0, column=0, padx=8)      # left counter
player_label = tk.Label(info_frame, font=("Arial", 12, "bold"),
                        fg=TEXT, bg=BG, width=22)
player_label.grid(row=0, column=1, padx=8)    # right counter
