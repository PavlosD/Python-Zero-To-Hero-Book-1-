def announce_round(round_number):    # round-heading function
    print(f"Round {round_number} begins!")
for i in range(1, 4):                # announce rounds one to three
    announce_round(i)
