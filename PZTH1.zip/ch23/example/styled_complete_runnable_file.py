# Cosmic Courier - Canvas Edition
# Move with arrow keys or WASD.
# Collect packages, dodge asteroids, and enter the portal.
# Press ENTER to start, H for help, P to pause, and ESC to leave help.

import random                     # spawn packages and asteroids unpredictably
import tkinter as tk
