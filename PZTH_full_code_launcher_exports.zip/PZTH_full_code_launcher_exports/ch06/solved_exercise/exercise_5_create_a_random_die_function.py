import random                      # randint() supplies the die result

def roll_die():
    return random.randint(1, 6)    # return one die roll

print(roll_die())                  # print one returned die roll
