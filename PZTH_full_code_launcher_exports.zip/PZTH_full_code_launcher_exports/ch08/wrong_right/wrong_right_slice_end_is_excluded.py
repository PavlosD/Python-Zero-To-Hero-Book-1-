# WRONG VERSION - commented out so the launcher can run safely
# name = "Drake"
# # WRONG: the end index is excluded
# print(name[0:2])  # "Dr"

# RIGHT VERSION
name = "Drake"
# CORRECT: ask for one position past the final letter
print(name[0:3])  # "Dra"
