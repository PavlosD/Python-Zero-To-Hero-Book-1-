print(coins + 5)                 # five more than typed
