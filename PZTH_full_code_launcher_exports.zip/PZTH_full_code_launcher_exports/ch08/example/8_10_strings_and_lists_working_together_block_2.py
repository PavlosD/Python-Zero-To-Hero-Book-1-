command = "take silver key"
words = command.split()        # list of words to inspect
if "key" in words:             # key mentioned anywhere?
    print("The command mentions a key.")
