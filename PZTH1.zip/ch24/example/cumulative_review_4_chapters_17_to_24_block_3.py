message_label = tk.Label(window, text="Ready")
