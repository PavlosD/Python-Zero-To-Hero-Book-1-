command = input("Enter command: ")    # store typed command
if command == "open":
    print("The chest opens.")
