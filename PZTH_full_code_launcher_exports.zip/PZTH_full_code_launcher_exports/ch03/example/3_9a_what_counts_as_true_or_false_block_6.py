has_key = False
if not has_key:                         # player is not carrying the key
    print("The door stays locked.")
else:
    print("The door can be opened.")    # key test passed
