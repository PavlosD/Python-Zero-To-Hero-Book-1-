print(max(10, 25))    # 25
print(min(10, 25))    # 10
