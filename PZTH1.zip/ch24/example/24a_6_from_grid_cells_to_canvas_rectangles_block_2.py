def draw_cell(x, y, colour):           # draw one snake tile
    left, top, right, bottom = grid_to_pixels(x, y)
    canvas.create_rectangle(                      # one solid tile
        left, top, right, bottom,      # fill this grid square
        fill=colour,
        outline=BG                     # dark seam between tiles
    )
