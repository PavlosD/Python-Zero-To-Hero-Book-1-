for item in inventory:
    print(item)
