# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: the string never closes
# # print("Hello, world!)

# RIGHT VERSION
# CORRECT: the closing quote is present
print("Hello, world!")
