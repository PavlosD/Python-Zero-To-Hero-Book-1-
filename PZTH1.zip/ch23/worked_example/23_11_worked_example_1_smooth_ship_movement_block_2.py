def update_ship():                        # move ship from held keys
    if keys["Left"]:                      # left key remains held
        player["x"] -= player["speed"]        # slide left
    if keys["Right"]:                     # right key remains held
        player["x"] += player["speed"]        # slide right
    window.after(30, update_ship)         # keep movement frame-based
