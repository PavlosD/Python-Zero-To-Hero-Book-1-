player_class = input("Choose a class: ")
if player_class == "Warrior":           # Warrior starts with extra armor
    print("You start with extra armor.")
else:
    print("Standard gear equipped.")    # fallback gear for every other class
