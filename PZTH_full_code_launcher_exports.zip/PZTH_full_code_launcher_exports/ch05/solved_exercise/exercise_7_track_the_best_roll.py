import random                      # roll five dice and keep the best
best_roll = 0                      # no best roll recorded yet
# keep only the highest roll seen
for i in range(5):
    roll = random.randint(1, 6)    # reroll inside the loop
    print("Roll:", roll)
    if roll > best_roll:           # higher than every earlier roll?
        best_roll = roll           # save the new highest roll
print("Best roll:", best_roll)     # report the stored maximum
