inventory = ["potion", "shield", "key"]    # three-item bag before pop()
removed_item = inventory.pop()             # pop takes the last item
print(removed_item)
print(inventory)                           # see every slot
