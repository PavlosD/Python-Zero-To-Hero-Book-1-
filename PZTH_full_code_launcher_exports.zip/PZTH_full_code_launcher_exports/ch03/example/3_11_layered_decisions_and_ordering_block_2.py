# This order is wrong because 95 already passes the Silver check.
score = 95             # test score for the ordering bug
if score >= 70:        # this broad test catches 95 too early
    print("Silver")
elif score >= 90:      # Gold-rank threshold
    print("Gold")
