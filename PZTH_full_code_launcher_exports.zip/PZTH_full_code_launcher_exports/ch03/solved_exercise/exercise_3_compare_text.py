player_class = "Mage"               # class selected for this bonus test
if player_class == "Mage":          # Mage receives the mana bonus
    print("Mana bonus applied.")
