inventory = ["potion", "key", "shield", "torch", "rope"]
target = "shield"
