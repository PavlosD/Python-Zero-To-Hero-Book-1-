enemy_board[row][col] = "S"     # hidden enemy ship cell
player_board[row][col] = "S"    # visible player ship cell
enemy_view[row][col] = "?"      # player has not fired here
player_view[row][col] = "?"     # computer has not fired here
