inventory = []                # empty exercise bag
inventory.append("potion")
inventory.append("shield")
print(inventory)              # both collected items
