inventory = ["key", "potion", "map"]    # three starters
for item in inventory:                  # each carried item
    print(item)
