def draw_boards():                       # redraw both fleet boards
    canvas.delete("all")                 # erase the previous board drawing
    canvas.create_rectangle(0, 0, CANVAS_W, CANVAS_H,
                            fill=PANEL, outline="")
    draw_one_board(ENEMY_X, "Enemy Waters", enemy_board,
                   enemy_view, False)    # enemy fleet is hidden
    draw_one_board(PLAYER_X, "Your Fleet", player_board,
                   player_view, True)    # show every player fleet cell
