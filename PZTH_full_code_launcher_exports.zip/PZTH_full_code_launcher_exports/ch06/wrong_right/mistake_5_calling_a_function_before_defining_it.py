# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: Python has not seen cheer() yet.
# # cheer()
# # def cheer():
# # print("Victory!")

# RIGHT VERSION
# CORRECT: define the function before calling it
def cheer():  # function name becomes available here
    print("Victory!")
cheer()
