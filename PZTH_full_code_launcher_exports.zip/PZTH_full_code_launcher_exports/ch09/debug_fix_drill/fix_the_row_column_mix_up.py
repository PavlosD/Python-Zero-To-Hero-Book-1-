# BROKEN
# board = [[".", ".", "T"], ["P", ".", "."]]
# print(board[2][0])
