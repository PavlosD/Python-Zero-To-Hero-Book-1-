player_score = 0
player_score = player_score + 10    # add the first ten-point reward
print(player_score)
