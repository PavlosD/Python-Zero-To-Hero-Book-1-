for i in range(1, 6):    # build five growing star rows
    print("*" * i)       # growing star row
