# BROKEN
# coins = input("Coins: ")
# coins = coins + 5
# print(coins)
