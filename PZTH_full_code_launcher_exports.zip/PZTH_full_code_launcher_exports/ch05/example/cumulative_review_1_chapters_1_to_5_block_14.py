roll = random.randint(1, 6)    # one roll per attempt
