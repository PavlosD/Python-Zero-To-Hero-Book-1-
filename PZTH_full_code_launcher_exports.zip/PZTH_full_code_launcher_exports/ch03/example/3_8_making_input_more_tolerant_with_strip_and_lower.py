command = input("Enter command: ").strip().lower()
if command == "open":            # did the player type open?
    print("The chest opens.")
