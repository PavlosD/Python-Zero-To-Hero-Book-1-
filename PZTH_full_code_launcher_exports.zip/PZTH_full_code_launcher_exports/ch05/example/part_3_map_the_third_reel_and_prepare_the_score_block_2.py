print(f"[ {reel_1} | {reel_2} | {reel_3} ]")
if reel_1 == reel_2 and reel_2 == reel_3:
    score = 100                     # jackpot pays full points
    print("JACKPOT! Three symbols match.")
elif reel_1 == reel_2 or reel_1 == reel_3 or reel_2 == reel_3:
    score = 25                      # two matching symbols pay 25 points
    print("Small win! Two symbols match.")
else:                               # nothing matched
    print("No match this time.")
