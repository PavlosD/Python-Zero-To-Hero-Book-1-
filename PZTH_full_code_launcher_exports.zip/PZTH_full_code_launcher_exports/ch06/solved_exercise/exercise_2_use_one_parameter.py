# The parameter name receives the player name.
def greet_player(name):           # personalized welcome line
    print(f"Welcome, {name}!")    # welcome text built from the name

# "Sage" becomes the name argument
greet_player("Sage")
