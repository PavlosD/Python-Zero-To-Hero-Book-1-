
show_final_score(score)                  # finish with the rank earned
