# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: show_score prints, but returns None.
# def show_score(score):
#     print(score)  # prints the score, but returns nothing
# result = show_score(10)  # result becomes None
# print(result)  # None, not the score

# RIGHT VERSION
# CORRECT: return the value when later code needs it
def get_score(score):
    return score  # return the score to the caller
result = get_score(10)  # result now holds 10
print(result)
