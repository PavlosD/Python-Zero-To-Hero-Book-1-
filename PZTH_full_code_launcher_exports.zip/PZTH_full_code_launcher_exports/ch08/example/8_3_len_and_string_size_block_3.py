player_name = input("Enter your hero name: ").strip()
if len(player_name) < 3:           # fewer than three characters?
    print("Name is too short.")
else:
    print("Name accepted.")        # the length rule passed
