print("=== TREASURE RUN ===")      # screen title
print("You enter the ruins.")
print("--------------------")      # separates scene from mission
print("Find the hidden relic!")
