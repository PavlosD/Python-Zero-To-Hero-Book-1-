for i in range(1, 6):    # five passes, using 1 through 5
    print(i)
