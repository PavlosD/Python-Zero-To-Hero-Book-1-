keys = {               # no movement key is held yet
    "Left": False,
    "Right": False,
    "Up": False,
    "Down": False,
}
keys["Left"] = True    # simulate held Left key
print(keys["Left"])    # confirm Left is marked held
