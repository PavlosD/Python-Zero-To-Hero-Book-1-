class Hero:                      # smallest useful Hero blueprint
    def __init__(self, name):
        self.name = name         # Hero name used by the debug example
flame_fox = Hero("Flame Fox")    # the fox as a Hero
print(flame_fox.name)            # read attribute that exists
