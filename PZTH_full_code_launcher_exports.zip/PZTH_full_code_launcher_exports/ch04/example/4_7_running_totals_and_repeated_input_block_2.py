score = 0
for round_number in range(1, 4):        # collect three round scores
    points = int(input(f"Points for round {round_number}: "))
    score = score + points              # add this round's points
    print(f"Current score: {score}")    # progress so far
