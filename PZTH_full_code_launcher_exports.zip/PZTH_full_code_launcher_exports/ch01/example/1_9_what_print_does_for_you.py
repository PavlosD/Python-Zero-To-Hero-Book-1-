print("Welcome to the dungeon.")
print("A slime appears!")
print("You gained 10 points.")
