for round_number in range(1, 6):    # run five fixed-score rounds
    score = score + 10              # each round adds ten points
    print(round_number, score)      # round and running total
