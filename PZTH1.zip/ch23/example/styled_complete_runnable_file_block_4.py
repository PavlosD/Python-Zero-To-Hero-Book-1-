window = tk.Tk()
window.configure(bg=BG)
window.title("Cosmic Courier - Canvas Edition")
window.resizable(False, False)        # lock the window size

canvas = tk.Canvas(                       # one drawing surface
    window,                                       # lives inside the window
    width=WIDTH,
    height=HEIGHT,
    bg=BG,
    highlightthickness=0,           # no focus border
)
