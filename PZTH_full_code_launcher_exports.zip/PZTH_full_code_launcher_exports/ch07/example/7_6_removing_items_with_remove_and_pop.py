inventory = ["potion", "shield", "key"]    # the familiar trio
inventory.remove("potion")
print(inventory)
