def cheer():             # shout a one-line victory
    print("Victory!")
cheer()
cheer()                  # call cheer again
