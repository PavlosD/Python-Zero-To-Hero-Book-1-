# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: the print call never closes
# # print("Battle begins"

# RIGHT VERSION
# CORRECT: the closing parenthesis is present
print("Battle begins")
