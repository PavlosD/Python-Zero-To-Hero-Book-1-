def add_points(points):    # apply a flat ten-point bonus
    return points + 10     # return the boosted score
