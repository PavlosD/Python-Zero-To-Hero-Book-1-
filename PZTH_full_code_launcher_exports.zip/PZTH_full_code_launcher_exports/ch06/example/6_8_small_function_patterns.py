def open_gate():                # gate-message function
    print("The gate opens.")
open_gate()
