def update_game():                   # advance one game frame
    move_player()
    draw_game()
    window.after(30, update_game)    # ask Tkinter for the next frame
