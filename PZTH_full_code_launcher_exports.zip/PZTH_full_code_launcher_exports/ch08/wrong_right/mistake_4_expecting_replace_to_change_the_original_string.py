# WRONG VERSION - commented out so the launcher can run safely
# message = "old gate"
# # WRONG: the changed string is not stored
# # message.replace("old", "ancient")
# # print(message)

# RIGHT VERSION
# CORRECT: store the changed string back
message = message.replace("old", "ancient")
print(message)
