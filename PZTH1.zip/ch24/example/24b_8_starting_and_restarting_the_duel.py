def reset_game():                          # rebuild both fleets for a rematch
    global enemy_board, player_board       # replace both fleets
    global enemy_view, player_view         # replace both shot maps
    global enemy_cells_left, player_cells_left      # fresh counts each game
    global game_over, waiting_for_computer, computer_job    # flags reset too

    if computer_job is not None:           # a PC shot may be queued
        root.after_cancel(computer_job)    # cancel it before restarting
        computer_job = None                # no queued PC shot remains
