def reset_game():                        # restore first-route mission state
    player["x"] = WIDTH // 2             # ship returns to horizontal centre
    player["y"] = HEIGHT - 78            # starting height near the floor
    state["screen"] = "playing"          # leave the title screen
    state["score"] = 0                   # discard the previous score
    state["lives"] = 3                   # restore all lives
    state["level"] = 1                   # return to the first route
    state["deliveries"] = 0              # no packages delivered yet
    state["required"] = 6                # six packages unlock the portal
    state["frame"] = 0                   # restart the frame counter
    state["portal_active"] = False       # portal starts closed
    packages.clear()
