gold = 20
has_key = "yes"                        # key in the pocket
if gold >= 10 and has_key == "yes":    # vault requirements satisfied
    print("Vault unlocked.")
