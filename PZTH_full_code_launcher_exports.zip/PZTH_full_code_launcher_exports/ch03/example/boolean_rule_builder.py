has_ticket = False
is_vip = True
can_enter = has_ticket or is_vip    # either pass works

if can_enter:                       # ticket or VIP status grants entry
    print("Entry allowed.")
else:
    print("Entry blocked.")
