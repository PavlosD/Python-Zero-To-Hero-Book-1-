# WRONG VERSION - commented out so the launcher can run safely
# # print(Dragon Gate) # WRONG

# RIGHT VERSION
print("Dragon Gate")
