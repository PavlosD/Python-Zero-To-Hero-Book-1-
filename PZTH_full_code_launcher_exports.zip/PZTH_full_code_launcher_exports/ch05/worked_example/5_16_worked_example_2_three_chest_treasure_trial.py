import random                           # roll treasure from three chests
total = 0                               # no loot collected yet
for chest in range(1, 4):               # number the three chests
    drop = random.randint(5, 15)
    total = total + drop                # add this chest to the haul
    print(f"Chest {chest}: +{drop}")
print(f"Total treasure: {total}")
