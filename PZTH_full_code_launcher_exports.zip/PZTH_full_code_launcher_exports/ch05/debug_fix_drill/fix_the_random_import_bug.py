# BROKEN
# roll = random.randint(1, 6)
# print(roll)
