import random                      # pick one reward from the list
rewards = ["potion", "coins", "amulet", "map"]
reward = random.choice(rewards)    # one reward drawn from the list
print(f"You found: {reward}")
