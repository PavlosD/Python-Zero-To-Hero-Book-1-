# WRONG VERSION - commented out so the launcher can run safely
# items = ["potion", "shield", "key"]
# # WRONG: index 3 is outside a three-item list.
# # print(items[3])

# RIGHT VERSION
items = ["potion", "shield", "key"]
# CORRECT: valid indexes are 0, 1 and 2
print(items[2])
