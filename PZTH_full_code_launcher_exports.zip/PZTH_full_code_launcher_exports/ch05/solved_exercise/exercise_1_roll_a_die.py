import random                  # supply the die roll used below
roll = random.randint(1, 6)    # one roll chooses the outcome
print(roll)
