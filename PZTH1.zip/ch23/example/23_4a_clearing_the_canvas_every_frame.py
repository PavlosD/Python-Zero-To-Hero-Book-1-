import tkinter as tk

window = tk.Tk()
canvas = tk.Canvas(window, width=400, height=120, bg="#111111")
canvas.pack()                 # the drawing area appears

ball = {"x": 20}              # stored x-position for the next frame
