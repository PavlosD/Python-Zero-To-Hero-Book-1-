# BROKEN
# inventory = ["key", "map"]
# inventory.remove("potion")
