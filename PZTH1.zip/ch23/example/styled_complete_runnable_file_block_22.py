def check_collisions():                    # apply contact effects
    ship = player_box()                    # one ship box reused below

    for package in packages[:]:            # catchable delivery objects
        if boxes_overlap(ship, object_box(package)):
            packages.remove(package)       # caught package leaves the screen
            state["score"] += 25 + state["level"] * 5
            state["deliveries"] += 1  # progress toward opening the portal
