# The inner decision is checked only after the key check passes.
has_key = True
knows_code = True
if has_key:                          # player has the required key?
    if knows_code:                   # player also knows the code?
        print("The vault opens.")
