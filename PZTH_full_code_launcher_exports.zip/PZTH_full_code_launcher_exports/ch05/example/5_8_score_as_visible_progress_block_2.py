score = 0
score = score + 10        # add the first ten points
print("Score:", score)
