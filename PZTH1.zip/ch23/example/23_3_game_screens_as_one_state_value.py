state = {                                  # shared game state
    "screen": "title",               # title, help, playing, paused
    "score": 0,                      # route score starts at zero
    "lives": 3,                      # crashes left
    "level": 1,                      # current stage number
}
