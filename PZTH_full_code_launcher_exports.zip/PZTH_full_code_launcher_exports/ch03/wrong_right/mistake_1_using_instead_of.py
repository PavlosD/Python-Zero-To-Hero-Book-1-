# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: = stores a value; a test needs ==
# score = 10  # assignment works on its own
# # if score = 10:  # = cannot test equality
# # print("Exact score reached.")

# RIGHT VERSION
# CORRECT: == compares two values
score = 10
if score == 10:
    print("Exact score reached.")
