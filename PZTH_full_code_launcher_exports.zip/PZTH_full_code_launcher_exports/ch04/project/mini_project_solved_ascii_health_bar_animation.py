import time                               # provides time.sleep()
max_health = 10                           # hero starts at full HP
print("=== ASCII HEALTH BAR ===")         # title before animation
print("The boss is attacking. Watch the health bar drop.")
print()                                   # separate title from first frame

for health in range(max_health, -1, -1):  # print 10, 9, ... down to 0
    filled_blocks = health                # one '#' per hp left
    empty_blocks = max_health - health    # one '.' per lost hp
    bar = "#" * filled_blocks + "." * empty_blocks
    print(f"Health: [{bar}] {health}/{max_health}")
    if health > 0:                        # no delay needed after final frame

        time.sleep(0.15)

print("The hero is out of health!")       # defeat message

print()                                   # separate defeat from the skill recap
print("Loop skill used:")
print("- each pass prints one frame")
print("- health changes every pass")
print("- the bar is rebuilt from the current health")
