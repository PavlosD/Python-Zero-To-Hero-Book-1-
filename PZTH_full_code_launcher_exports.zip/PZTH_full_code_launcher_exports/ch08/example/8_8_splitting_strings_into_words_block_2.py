command = "open door"
words = command.split()    # text becomes a list
action = words[0]          # first word is the verb
target = words[1]          # second word is the object
print(action)
print(target)
