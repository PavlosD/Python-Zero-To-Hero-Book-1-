import tkinter as tk

WIDTH = 760                               # playfield width in px
HEIGHT = 520                              # playfield height in px
window = tk.Tk()
window.title("Canvas Arcade Practice")
window.resizable(False, False)                # lock the window size
canvas = tk.Canvas(window, width=WIDTH, height=HEIGHT, bg="#111111")
canvas.pack()                             # place the canvas in the window
window.mainloop()                         # run the empty Canvas event loop
