scores = [12, 47, 33, 7, 64, 18, 90, 25]
high_scores = 0                          # no qualifying scores yet
for score in scores:                     # inspect each recorded score
    if score >= 50:                      # score reaches the 50-point cutoff
        high_scores = high_scores + 1    # count this qualifying score
print("scores at 50 or higher:", high_scores)
