inventory = ["key", "map"]    # two quest items
inventory.append("potion")
inventory.remove("key")
print(inventory)              # map and potion remain
