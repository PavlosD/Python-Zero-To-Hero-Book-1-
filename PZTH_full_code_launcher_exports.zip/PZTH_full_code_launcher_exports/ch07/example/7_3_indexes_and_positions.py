inventory = ["potion", "shield", "key"]    # the practice bag
print(inventory[0])                        # first item
print(inventory[1])                        # second item
print(inventory[2])                        # third item
