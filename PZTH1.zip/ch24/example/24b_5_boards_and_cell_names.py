def make_board(fill):                     # build one empty fleet board
    board = []                            # rows collect here
    for row in range(GRID_SIZE):          # one row per board line
        line = [fill] * GRID_SIZE         # one filled board row
        board.append(line)                # add this row to the board
    return board                          # finished 2D list


def cell_name(row, col):                  # convert indexes to labels
    return LETTERS[col] + str(row + 1)    # example: row 0, col 2 -> C1
