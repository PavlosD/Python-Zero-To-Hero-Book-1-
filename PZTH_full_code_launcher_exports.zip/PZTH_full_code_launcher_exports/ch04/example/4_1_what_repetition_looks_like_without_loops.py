print("Attack!")    # first repeated attack
print("Attack!")    # second repeated attack
print("Attack!")    # third repeated attack
print("Attack!")    # fourth repeated attack
print("Attack!")    # fifth repeated attack
