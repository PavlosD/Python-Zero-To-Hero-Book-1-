SHIP_SIZES = [4, 3, 3, 2]    # four ships: 4, 3, 3, 2
