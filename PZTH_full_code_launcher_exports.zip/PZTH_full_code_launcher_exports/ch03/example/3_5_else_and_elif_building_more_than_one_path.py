# else gives feedback when the buying rule fails.
coins = 5                               # five coins is below the potion price
if coins >= 10:                         # enough coins for the potion
    print("You can buy the potion.")
else:
    print("You need more gold.")
