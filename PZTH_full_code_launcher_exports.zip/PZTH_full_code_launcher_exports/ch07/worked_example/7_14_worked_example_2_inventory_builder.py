inventory = []
for slot in range(1, 4):      # ask the player for 3 items
    item = input(f"Item for slot {slot}: ").strip().lower()
    inventory.append(item)    # store this item in the bag

print("=== INVENTORY ===")    # inventory heading
for item in inventory:        # show the finished inventory in order
    print(f"- {item}")        # one row per item
