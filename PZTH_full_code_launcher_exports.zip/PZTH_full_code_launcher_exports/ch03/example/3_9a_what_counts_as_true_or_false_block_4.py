gold = 20
has_key = "yes"                        # text standing in for True
if gold >= 10 and has_key == "yes":    # gold and key checks both passed?
    print("You unlock the vault.")     # both tests passed
