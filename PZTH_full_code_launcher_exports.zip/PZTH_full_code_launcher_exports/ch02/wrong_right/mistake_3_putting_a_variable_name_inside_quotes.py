# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: this prints the words player_name
# player_name = "Luna"
# print("player_name")

# RIGHT VERSION
# CORRECT: this prints Luna
player_name = "Luna"
print(player_name)
