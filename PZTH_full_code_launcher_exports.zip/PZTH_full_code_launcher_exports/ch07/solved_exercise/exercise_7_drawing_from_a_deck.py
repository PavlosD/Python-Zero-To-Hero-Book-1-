deck = ["heal", "fire", "shield"]    # cards left to draw
drawn = deck.pop()                   # top card leaves the deck
print(f"You drew: {drawn}")
print(f"Cards left: {len(deck)}")    # remaining deck size
