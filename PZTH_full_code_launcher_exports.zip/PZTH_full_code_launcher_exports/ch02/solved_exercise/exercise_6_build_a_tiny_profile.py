player_name = input("Enter your hero name: ")
player_class = input("Enter your class: ")
print(f"{player_name} is a {player_class}.")
