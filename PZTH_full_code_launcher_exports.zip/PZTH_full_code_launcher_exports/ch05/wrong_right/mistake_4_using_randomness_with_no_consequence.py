# WRONG VERSION - commented out so the launcher can run safely
# import random
# # WRONG: the reward is generated but never used
# reward = random.randint(5, 21)  # chest reward
# print("Chest opened.")

# RIGHT VERSION
import random
# CORRECT: the reward changes the score
score = 0
reward = random.randint(5, 21)
score = score + reward
print("Reward:", reward)
print("Score:", score)
