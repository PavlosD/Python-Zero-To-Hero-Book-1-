import random                  # random tools for repeatable tests
random.seed(42)
print(random.randint(1, 6))    # seeded: same roll every run
print(random.randint(1, 6))    # second repeatable roll
