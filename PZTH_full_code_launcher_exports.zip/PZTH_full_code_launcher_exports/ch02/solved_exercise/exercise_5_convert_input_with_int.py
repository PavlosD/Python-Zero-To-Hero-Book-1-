coins = int(input("Enter your coins: "))
coins = coins + 5                       # add the five-coin bonus
print(f"Coins after bonus: {coins}")
