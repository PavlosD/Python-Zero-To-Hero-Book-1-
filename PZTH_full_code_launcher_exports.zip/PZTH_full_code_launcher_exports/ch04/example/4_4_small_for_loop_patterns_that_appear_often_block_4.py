score = 0
for i in range(3):              # add ten points three times
    score = score + 10          # ten per loop pass
    print(f"Score: {score}")
