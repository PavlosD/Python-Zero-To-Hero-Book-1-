command = "open"
if command == "open":      # open command matches the expected word
    print("Gate opens")    # gate opens after the valid command
