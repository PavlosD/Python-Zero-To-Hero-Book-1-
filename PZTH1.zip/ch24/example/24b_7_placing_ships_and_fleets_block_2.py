def place_fleet(board):                    # place every ship legally at random
    for size in SHIP_SIZES:                # place 4, then 3, 3, 2
        placed = False                     # this ship still needs room
        while not placed:                  # keep trying safe starts
            row = random.randrange(GRID_SIZE)
            col = random.randrange(GRID_SIZE)
            direction = random.choice(["H", "V"])
            if can_place_ship(board, row, col, size, direction):
                place_ship(board, row, col, size, direction)
                placed = True              # go to the next ship
