rewards = [10, 20, 30, 40]               # reward tiers
enemies = ["shade", "shade", "drake"]    # two shades, one drake
mixed_data = ["Luna", 100, 3.5]          # three types in one list
