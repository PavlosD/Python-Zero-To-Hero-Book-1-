def key_up(event):                      # runs on every screen
    if event.keysym in keys:            # release even while paused
        keys[event.keysym] = False      # resume starts with clean flags
