# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: 88 reaches Silver before Gold is tested
# score = 88
# if score >= 66:
#     print("Silver")
# elif score >= 84:
#     print("Gold")

# RIGHT VERSION
# CORRECT: check the stricter condition first
score = 88
if score >= 84:
    print("Gold")
elif score >= 66:
    print("Silver")
