has_key = True                         # player carries the key
if has_key:                            # player has the required key?
    print("The gate opens.")
else:
    print("The gate stays locked.")    # requirement unmet
