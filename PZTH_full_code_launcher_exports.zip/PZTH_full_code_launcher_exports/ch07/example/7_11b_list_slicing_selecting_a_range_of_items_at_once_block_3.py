bullets = [10, 50, 95, 120, 30]     # horizontal positions of five bullets
for bullet_x in bullets[:]:         # walk a copy
    if bullet_x > 100:              # bullet has moved past the right edge
        bullets.remove(bullet_x)    # remove from the original
