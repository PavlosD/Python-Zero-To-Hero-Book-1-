def reward_for(enemy_name):             # map each enemy to its gold reward
    if enemy_name == "slime":           # weakest foe
        return 5
    elif enemy_name == "goblin":        # mid-tier foe
        return 12
    elif enemy_name == "dragon":        # boss-tier foe
        return 50
    else:                               # unknown enemy
        return 0
