for row in range(4):
    print("*" * 8)      # rectangle row pattern
