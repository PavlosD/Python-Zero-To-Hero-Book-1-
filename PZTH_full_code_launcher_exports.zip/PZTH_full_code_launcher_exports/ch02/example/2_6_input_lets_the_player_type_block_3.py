player_name = input("Enter your hero name: ")
player_class = input("Enter your class: ")
print(f"{player_name} begins the journey as a {player_class}.")
