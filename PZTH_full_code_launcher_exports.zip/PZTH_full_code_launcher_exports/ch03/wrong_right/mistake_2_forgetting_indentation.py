# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: the print line sits outside the if block
# coins = 10
# # if coins >= 10:
# # print("Potion available.")

# RIGHT VERSION
# CORRECT: indent the line that belongs to the if
coins = 10
if coins >= 10:
    print("Potion available.")
