word = "treasure"    # the target word
part = word[0:4]     # slice: first four letters
print(part)
