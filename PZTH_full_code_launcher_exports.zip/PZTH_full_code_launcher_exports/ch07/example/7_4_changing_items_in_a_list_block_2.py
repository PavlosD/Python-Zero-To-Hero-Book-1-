party = ["warrior", "archer", "healer"]    # the starting party
party[2] = "mage"                          # healer swapped for mage
print(party)
