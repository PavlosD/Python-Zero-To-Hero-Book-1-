# WRONG VERSION - commented out so the launcher can run safely
# window.bind("<KeyPress>", key_down)
# # no focus call
# show_title()
# window.mainloop()

# RIGHT VERSION
window.bind("<KeyPress>", key_down)
window.focus_set()
show_title()
window.mainloop()
