player_name = "Iris"       # name used for slice practice
print(player_name[0:3])    # first three name letters
