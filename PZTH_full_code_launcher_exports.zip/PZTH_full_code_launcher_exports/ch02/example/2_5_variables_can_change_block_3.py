player_health = 100
enemy_damage = 12
player_health = player_health - enemy_damage
print(player_health)    # health after damage
