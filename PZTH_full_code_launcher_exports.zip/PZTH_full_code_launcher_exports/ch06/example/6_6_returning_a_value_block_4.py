def calculate_damage(base):         # base damage plus a flat 3
    return base + 3
damage = calculate_damage(7)
print(f"Damage dealt: {damage}")    # report the hit total
