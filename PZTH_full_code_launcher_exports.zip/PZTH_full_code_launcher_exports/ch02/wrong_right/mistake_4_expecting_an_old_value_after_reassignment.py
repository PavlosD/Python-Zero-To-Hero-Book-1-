# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: expecting this to print 21
# gold = 21
# gold = 35
# print(gold)

# RIGHT VERSION
# CORRECT: store the old value separately
old_gold = 21
gold = 35
print(old_gold)
print(gold)
