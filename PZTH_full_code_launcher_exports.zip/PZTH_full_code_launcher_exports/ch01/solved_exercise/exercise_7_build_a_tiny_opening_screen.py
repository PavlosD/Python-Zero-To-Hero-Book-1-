print("=== RUIN RUNNER ===")
print("--------------------")    # separates scene from mission
print("Find the hidden relic before sunrise.")
