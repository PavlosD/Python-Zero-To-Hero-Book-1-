print("=== BATTLE START ===")
print("Hero enters the arena.")
print("=== BATTLE START ===")
print("Hero enters the arena.")
