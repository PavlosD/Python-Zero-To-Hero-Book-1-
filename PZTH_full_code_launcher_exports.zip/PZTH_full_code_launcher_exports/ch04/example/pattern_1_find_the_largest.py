best = 0
for round_number in range(1, 6):    # collect five scores
    score = int(input(f"Score {round_number}: "))
    if score > best:                # new highest score?
        best = score                # store the new highest score
print("Best:", best)                # highest entered score
