# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: typing the expected output
# # Hello, world!

# RIGHT VERSION
# CORRECT: type the instruction that creates the output
print("Hello, world!")
