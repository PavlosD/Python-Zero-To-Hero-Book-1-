# WRONG VERSION - commented out so the launcher can run safely
# keys = {"left": False, "right": False, "A": False, "D": False}

# RIGHT VERSION
keys = {"Left": False, "Right": False, "Up": False, "Down": False,
        "a": False, "d": False, "w": False, "s": False}
