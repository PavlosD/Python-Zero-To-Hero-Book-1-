x = player["x"]                # unpack for short math
y = player["y"]                # ship centre y-coordinate
w = player["w"]                # ship width
h = player["h"]                # ship height
canvas.create_polygon(             # draw the ship from four points
    x, y - h // 2,                 # nose at the top
    x - w // 2, y + h // 2,        # left wing tip
    x, y + 8,                        # notch under the hull
    x + w // 2, y + h // 2,        # right wing tip
    fill="#eeeeee",                # light hull
    outline="#555555",             # soft gray edge
)
