canvas.pack()                     # place the canvas in the window
