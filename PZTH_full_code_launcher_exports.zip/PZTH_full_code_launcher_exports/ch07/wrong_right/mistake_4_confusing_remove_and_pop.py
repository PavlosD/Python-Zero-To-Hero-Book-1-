# WRONG VERSION - commented out so the launcher can run safely
# inventory = ["potion", "shield", "key"]
# # WRONG: remove() expects a value, not a slot
# # inventory.remove(1)

# RIGHT VERSION
inventory = ["potion", "shield", "key"]
# CORRECT: pop() removes by index and returns the item
removed_item = inventory.pop(1)
print(removed_item)
print(inventory)
