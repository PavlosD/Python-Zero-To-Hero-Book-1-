deck = []
if len(deck) > 0:
    drawn = deck.pop()
    print(f"You drew: {drawn}")
else:
    print("The deck is empty.")
