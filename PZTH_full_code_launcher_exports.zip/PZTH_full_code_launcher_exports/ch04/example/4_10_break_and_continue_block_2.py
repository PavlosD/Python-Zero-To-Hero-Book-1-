secret_number = 7                 # hidden answer to find
for attempt in range(1, 4):       # allow three chest choices
    guess = int(input("Guess the number: "))
    # Stop early when the player guesses correctly.
    if guess == secret_number:    # compare guess with the secret
        print("Correct!")
        break                     # correct guess; end search
    print("Try again.")           # give retry feedback
