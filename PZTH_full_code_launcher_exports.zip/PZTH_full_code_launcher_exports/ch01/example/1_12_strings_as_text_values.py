print("Knight")
print("Wizard")
print("Shadow Forest")    # third string prints after the first two
