screen_size = (800, 500)     # width and height in one tuple
red_color   = (255, 0, 0)    # three numbers describing a color
spawn_point = (100, 200)     # x and y of an enemy spawn
