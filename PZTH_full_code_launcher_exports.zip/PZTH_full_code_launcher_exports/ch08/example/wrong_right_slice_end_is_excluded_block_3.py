player_name = "Nara"             # name used to build a short tag
player_tag = player_name[0:3]    # three-letter tag
print(player_tag)
