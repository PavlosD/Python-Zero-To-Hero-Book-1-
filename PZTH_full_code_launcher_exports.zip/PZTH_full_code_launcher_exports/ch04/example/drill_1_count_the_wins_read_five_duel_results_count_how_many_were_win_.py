wins = 0                      # no winning rounds yet
for i in range(5):
    prompt = f"Result of duel {i + 1} (win/lose): "
    result = input(prompt).strip().lower()
    if result == "win":       # a winning round?
        wins = wins + 1       # count this winning round
print("Total wins:", wins)
