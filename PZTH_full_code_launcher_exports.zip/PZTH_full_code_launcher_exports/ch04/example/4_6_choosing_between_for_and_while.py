for i in range(3):           # repeat potion use three times
    print("Potion used")     # fixed three-use count
