word = "treasure"    # the target word
print(word[0:3])     # indexes 0, 1, and 2
print(word[3:])      # from index 3
print(word[:5])      # first 5 chars
