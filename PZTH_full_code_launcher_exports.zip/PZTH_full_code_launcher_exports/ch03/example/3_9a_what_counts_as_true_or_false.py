score = 0
if score:                        # runs only for a non-zero score
    print("there is a score")    # skipped because zero is falsy
