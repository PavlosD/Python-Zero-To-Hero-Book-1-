if state["deliveries"] >= state["required"]:
    state["portal_active"] = True   # exit target for the ship

if state["portal_active"] and boxes_overlap(ship, portal_box()):
    finish_level()                  # ship reached the portal
