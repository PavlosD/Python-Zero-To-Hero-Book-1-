bind_key("w", "Up")
bind_key("s", "Down")                     # S also steers down
bind_key("a", "Left")                     # A also steers left
bind_key("d", "Right")                    # D also steers right

reset_game()                              # draw board and queue first tick
root.mainloop()                           # listen for Snake keys and Restart
