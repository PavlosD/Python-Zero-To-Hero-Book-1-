keys = {"Left": False, "Right": False}    # two directions to track
player = {"x": 200, "speed": 7}           # start x and pixels per move

def key_down(event):                      # handle one key press
    if event.keysym in keys:              # key belongs to movement controls
        keys[event.keysym] = True         # direction is now held

def key_up(event):                        # key released
    if event.keysym in keys:              # key belongs to movement controls
        keys[event.keysym] = False        # direction is no longer held
