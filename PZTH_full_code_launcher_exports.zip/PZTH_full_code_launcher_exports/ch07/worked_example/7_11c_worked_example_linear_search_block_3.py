if found_at >= 0:                      # did the scan find it?
    print(target, "is at index", found_at)
else:
    print(target, "is not in the inventory")
