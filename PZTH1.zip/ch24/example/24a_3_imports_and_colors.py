import random           # choose an open food cell
import tkinter as tk    # GUI toolkit for Snake

BG = "#0f1226"          # dark frame around the board
PANEL = "#1b1f3a"       # empty board tile
GRID = "#252a48"        # thin seams between tiles
TEXT = "#e8eaf6"        # light text on dark panels
ACCENT = "#7c83ff"      # snake body
HEAD = "#27c66b"        # head, brighter than body
FOOD = "#ffd166"       # food dot colour
DANGER = "#ff5d6c"      # crash + game-over text
