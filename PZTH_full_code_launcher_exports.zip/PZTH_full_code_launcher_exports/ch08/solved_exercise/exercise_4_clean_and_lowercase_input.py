command = input("Enter command: ").strip().lower()
if command == "open":            # open command selected after cleanup
    print("Opened.")
else:
    print("Unknown command.")    # command did not match "open"
