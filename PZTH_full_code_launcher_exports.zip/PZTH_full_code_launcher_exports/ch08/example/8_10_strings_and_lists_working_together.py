command = "take silver key"
words = command.split()        # one word per slot
for word in words:             # inspect each command word
    print(word)
