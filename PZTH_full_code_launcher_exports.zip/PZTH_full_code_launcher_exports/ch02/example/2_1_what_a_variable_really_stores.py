player_name = "Rin"    # text goes in quotes
print(player_name)
