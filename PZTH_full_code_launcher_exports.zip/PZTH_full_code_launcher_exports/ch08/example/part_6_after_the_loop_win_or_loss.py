if wrong_guesses >= max_wrong:          # wrong guesses hit limit
    danger = "#" * max_wrong            # fully filled final danger bar
    print(f"Wrong guesses: {wrong_guesses}/{max_wrong}")
    print(f"Danger: {danger}")
    print("The relic stays sealed.")
    print(f"The word was: {secret_word}")
else:
    print("Relic recovered!")
