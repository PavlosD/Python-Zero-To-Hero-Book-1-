# WRONG VERSION - commented out so the launcher can run safely
# import random
# # WRONG: too wild for a starter sword
# damage = random.randint(1, 93)  # too wide

# RIGHT VERSION
import random
# CORRECT: controlled uncertainty
damage = random.randint(4, 7)  # fair damage
print("Damage:", damage)
