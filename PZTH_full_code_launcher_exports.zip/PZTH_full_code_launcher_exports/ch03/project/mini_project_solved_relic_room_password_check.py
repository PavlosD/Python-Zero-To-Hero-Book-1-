# Clean both inputs before comparison.
password = input("Speak the relic password: ").strip().lower()
player_rank = input("Enter your rank: ").strip().lower()

is_password_correct = password == "ember"
has_guardian_rank = player_rank == "guardian"
has_full_access = is_password_correct and has_guardian_rank

if has_full_access:                       # password and rank both passed
    print("================================")
    print("       RELIC ROOM OPENED        ")
    print("================================")
    print("The ancient door slides aside.")
elif is_password_correct:                 # correct word, insufficient rank
    print("Password accepted, but your rank is too low.")
else:                                     # password did not match
    print("The chamber stays sealed.")

print("Relic check complete.")
