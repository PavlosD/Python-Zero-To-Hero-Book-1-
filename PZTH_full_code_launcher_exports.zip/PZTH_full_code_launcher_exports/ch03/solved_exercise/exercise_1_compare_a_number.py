score = 60
if score >= 50:                      # score reaches the checkpoint target?
    print("Checkpoint unlocked.")
