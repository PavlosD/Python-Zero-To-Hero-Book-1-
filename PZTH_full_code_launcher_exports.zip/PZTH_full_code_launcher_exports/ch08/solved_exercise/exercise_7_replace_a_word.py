message = "old gate"
message = message.replace("old", "ancient")
print(message)
