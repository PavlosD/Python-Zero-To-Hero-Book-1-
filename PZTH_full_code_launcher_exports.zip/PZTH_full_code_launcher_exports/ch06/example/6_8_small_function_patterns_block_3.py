def double_points(points):    # return twice the points
    return points * 2
result = double_points(6)
print(result)
