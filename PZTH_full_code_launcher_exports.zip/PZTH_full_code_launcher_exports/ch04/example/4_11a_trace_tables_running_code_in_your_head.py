total = 0
for n in range(1, 4):    # add 1, then 2, then 3
    total = total + n    # include this pass
    print(total)         # running total
