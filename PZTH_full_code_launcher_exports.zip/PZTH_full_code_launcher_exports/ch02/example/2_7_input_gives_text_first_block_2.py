age = input("Enter age: ")    # still text at this point
# The next line would fail if age is still text.
# print(age + 1)
