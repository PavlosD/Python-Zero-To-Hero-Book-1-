parts = line.split(",")      # split saved score line
if len(parts) >= 2:          # saved line has two fields
    name = parts[0]          # name half of the line
    score = int(parts[1])
