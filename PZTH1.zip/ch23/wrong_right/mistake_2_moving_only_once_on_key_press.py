# WRONG VERSION - commented out so the launcher can run safely
# def key_down(event):
#     player["x"] += PLAYER_SPEED

# RIGHT VERSION
def key_down(event):
    if event.keysym in keys:
        keys[event.keysym] = True
