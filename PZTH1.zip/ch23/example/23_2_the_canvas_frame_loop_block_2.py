def tick():                     # advance one animation step
    ticks["n"] += 1             # count this timer pass
    label.config(text=f"ticks: {ticks['n']}")
    window.after(500, tick)     # schedule the next tick

tick()                          # kick the cycle off once
window.mainloop()               # process each scheduled tick
