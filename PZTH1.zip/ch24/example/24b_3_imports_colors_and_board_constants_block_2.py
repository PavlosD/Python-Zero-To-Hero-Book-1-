WARN = "#ffd166"             # warning color for the final overlay
