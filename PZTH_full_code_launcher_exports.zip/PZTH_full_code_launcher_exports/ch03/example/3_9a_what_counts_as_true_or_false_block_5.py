# or accepts either valid path into the arena.
has_ticket = "no"              # no ticket in hand
is_vip = "yes"                 # but the VIP list says yes
if has_ticket == "yes" or is_vip == "yes":
    print("Entry allowed.")    # at least one test passed
