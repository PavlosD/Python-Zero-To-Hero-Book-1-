# WRONG VERSION - commented out so the launcher can run safely
# inventory = ["shield", "key"]
# # WRONG: this crashes if potion is missing.
# # inventory.remove("potion")

# RIGHT VERSION
inventory = ["shield", "key"]
# CORRECT: check before removing
if "potion" in inventory:
    inventory.remove("potion")
print(inventory)
