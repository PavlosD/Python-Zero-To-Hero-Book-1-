# ---- colour palette ----
BG    = "#0f1226"                 # deep navy window
PANEL = "#1b1f3a"                 # raised panel tone
TEXT  = "#e8eaf6"                 # soft white text
ACC   = "#7c83ff"                 # accent colour
GOOD  = "#27c66b"                 # win / go / correct
BAD   = "#ff5d6c"                 # lose / wrong / miss
WARN  = "#ffd166"                 # waiting / caution
