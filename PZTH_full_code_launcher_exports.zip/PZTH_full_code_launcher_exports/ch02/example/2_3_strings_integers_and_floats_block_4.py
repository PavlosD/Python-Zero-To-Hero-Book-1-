hero_name = "Rin"       # the name used in the greeting
player_level = 4        # current level number
movement_speed = 4.5    # decimal speed stat
