# WRONG VERSION - commented out so the launcher can run safely
# ship_image = tk.PhotoImage(file="ship.png")

# RIGHT VERSION
ship_image = load_image("ship.png")
if ship_image is None:
    draw_player_shape()
