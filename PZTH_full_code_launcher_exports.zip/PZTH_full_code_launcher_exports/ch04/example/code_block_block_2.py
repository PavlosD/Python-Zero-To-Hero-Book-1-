for i in range(5):
    print("Attack!")    # repeats once per loop pass
