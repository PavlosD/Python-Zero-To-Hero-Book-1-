import tkinter as tk

window = tk.Tk()
window.title("after() demo")

label = tk.Label(window, text="ticks: 0", font=("Arial", 20))
label.pack(padx=40, pady=40)

ticks = {"n": 0}                # mutable counter shared with tick()
