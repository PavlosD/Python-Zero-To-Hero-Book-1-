# WRONG VERSION - commented out so the launcher can run safely
# word = "gate"
# # WRONG: valid indexes are 0, 1, 2, and 3
# # print(word[4])

# RIGHT VERSION
word = "gate"
# CORRECT: read the last existing character
print(word[3])
