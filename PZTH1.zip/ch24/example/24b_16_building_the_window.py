root = tk.Tk()                              # Fleet Battle window
root.title("Fleet Battle")
root.geometry("820x610")                    # fit both boards and controls
root.resizable(False, False)                # keep the fixed layout
root.configure(bg=BG)                       # use dark battle palette

main_frame = tk.Frame(root, bg=BG)          # holds all battle widgets
main_frame.pack(fill="both", expand=True, padx=18, pady=14)
