answer_entry.pack()                # place the answer entry on screen
