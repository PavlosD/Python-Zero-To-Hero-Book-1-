speed = 4.5     # movement speed needs a decimal
