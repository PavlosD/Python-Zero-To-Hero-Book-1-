import random                         # roll each round's points
for round_number in range(1, 4):      # play three scoring rounds
    reward = random.randint(1, 10)    # this round earns 1 to 10 points
    print(f"Round {round_number}: you earned {reward} points.")
