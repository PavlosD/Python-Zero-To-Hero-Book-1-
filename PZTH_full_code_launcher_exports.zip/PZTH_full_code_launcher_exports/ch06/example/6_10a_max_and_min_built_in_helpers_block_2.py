health = 12
damage = 30
health = max(0, health - damage)    # 0, not -18
print(health)                       # health clamped at zero
