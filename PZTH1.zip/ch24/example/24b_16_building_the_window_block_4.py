canvas = tk.Canvas(main_frame, width=CANVAS_W, height=CANVAS_H,
                   bg=PANEL, highlightthickness=2,
                   highlightbackground=GRID_LINE)
canvas.pack()                             # board canvas in place
canvas.bind("<Button-1>", player_fire)    # clicks filtered to the enemy grid

message_label = tk.Label(                   # status and result message
    main_frame,
    text="Fire on the enemy board. Computer fires after you.",
    font=("Arial", 11, "bold"), fg=TEXT, bg=BG,
    wraplength=740)
message_label.pack(pady=(8, 10))          # place the message label
