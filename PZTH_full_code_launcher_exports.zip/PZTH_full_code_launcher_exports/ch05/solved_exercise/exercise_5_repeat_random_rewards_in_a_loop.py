import random                         # roll a reward each round
for round_number in range(1, 4):      # play three reward rounds
    reward = random.randint(1, 10)    # this round earns 1 to 10 points
    print(f"Round {round_number}: {reward}")
