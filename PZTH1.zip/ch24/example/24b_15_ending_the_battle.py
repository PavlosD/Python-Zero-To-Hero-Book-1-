def end_game(message):                    # battle over overlay
    global game_over, waiting_for_computer    # ending writes both flags
    game_over = True                      # battle result blocks more shots
    waiting_for_computer = False          # release the pending-turn lock
    message_label.config(text=message)    # repeat result below both boards
    canvas.create_rectangle(205, 178, 555, 260,
                            fill="#071018", outline=TEXT, width=2)
    canvas.create_text(CANVAS_W // 2, 205, text="BATTLE OVER",
                       fill=WARN, font=("Arial", 22, "bold"))
    canvas.create_text(CANVAS_W // 2, 236, text=message,
                       fill=TEXT, font=("Arial", 12, "bold"))
