found_at = -1                          # -1 means "not found yet"
for index in range(len(inventory)):
    if inventory[index] == target:     # is this slot the target?
        found_at = index               # store the matching index
        break                          # target found; stop scanning
