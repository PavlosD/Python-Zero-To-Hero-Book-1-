for row in range(1, 6):    # build five staircase rows
    print("*" * row)       # staircase row pattern
