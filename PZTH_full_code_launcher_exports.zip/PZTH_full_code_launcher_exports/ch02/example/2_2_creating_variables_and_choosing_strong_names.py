player_name = "Rin"    # hero name stored as text
player_score = 0
player_gold = 25
