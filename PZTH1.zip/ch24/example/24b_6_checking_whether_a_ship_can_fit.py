def can_place_ship(board, row, col, size, direction):
    if direction == "H":            # ship runs across columns
        end_col = col + size - 1    # last column it needs
        if end_col >= GRID_SIZE:    # would leave the board
            return False            # reject a ship past the right edge
        for test_col in range(col, col + size):
            if board[row][test_col] == SHIP:
                return False        # another ship is here
    else:                           # ship runs down rows
        end_row = row + size - 1    # last row it needs
        if end_row >= GRID_SIZE:    # would leave the board
            return False            # reject a ship past the bottom edge
