print("=== ADVENTURER BACKPACK ===")       # backpack heading
print("Choose 4 items for your backpack.")
print()                                    # blank line before item entry
backpack = []

for slot in range(1, 5):                   # ask for four backpack items
    item = input(f"Enter item {slot}: ").strip().lower()
    backpack.append(item)                  # store this item in the bag
