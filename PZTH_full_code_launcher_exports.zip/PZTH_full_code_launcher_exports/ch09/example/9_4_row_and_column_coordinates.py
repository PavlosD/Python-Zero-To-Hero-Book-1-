# store row and column coordinates
board = [
    [".", ".", "P", "."],
    [".", "#", ".", "."],
    ["T", ".", ".", "."]
]
row = 0                   # pick the row to read
col = 2
print(board[row][col])
