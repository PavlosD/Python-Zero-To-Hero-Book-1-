def try_move(board, player_row, player_col, new_row, new_col):
    rows = len(board)                    # number of board rows
    cols = len(board[0])                 # board width
    if (
        0 <= new_row < rows
        and 0 <= new_col < cols
        and board[new_row][new_col] != "#"
    ):
        board[player_row][player_col] = "."
        board[new_row][new_col] = "P"    # move player to a valid cell
        return new_row, new_col          # valid destination
    return player_row, player_col        # blocked move keeps the old position
