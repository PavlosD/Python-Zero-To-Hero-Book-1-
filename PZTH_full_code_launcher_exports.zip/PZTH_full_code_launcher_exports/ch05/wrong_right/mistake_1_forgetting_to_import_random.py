# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: random was never imported
# # roll = random.randint(1, 6)

# RIGHT VERSION
# CORRECT: import the module first
import random
# Roll one die for this random outcome.
roll = random.randint(1, 6)
print(roll)
