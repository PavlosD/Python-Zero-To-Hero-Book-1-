import random                        # pick one of three prize types
prize_roll = random.randint(1, 3)    # choose one of three prizes
if prize_roll == 1:                  # potion prize
    prize = "potion"
elif prize_roll == 2:                # shield prize
    prize = "shield"
else:
    prize = "coins"
if prize == "coins":                 # only coins reach the shop
    print("You can spend your reward in the shop.")
else:
    print("You add the item to your inventory.")
