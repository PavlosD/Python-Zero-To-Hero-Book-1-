total = 0                               # the run opens with no gold
total = total + reward_for("slime")     # add slime payout
total = total + reward_for("goblin")    # add goblin payout
total = total + reward_for("dragon")    # add dragon payout
print(f"Total reward: {total}")
