
update()                           # start the repeating refresh once
window.mainloop()                # run each scheduled HUD refresh
