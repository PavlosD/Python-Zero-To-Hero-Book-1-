# CORRECT: the closing parenthesis is present
print("Battle begins")
