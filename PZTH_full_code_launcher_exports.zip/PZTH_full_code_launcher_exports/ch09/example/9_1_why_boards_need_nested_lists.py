row = [".", ".", "P", "."]    # one board row, P in slot 2
print(row)
