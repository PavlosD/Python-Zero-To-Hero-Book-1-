score = 70
