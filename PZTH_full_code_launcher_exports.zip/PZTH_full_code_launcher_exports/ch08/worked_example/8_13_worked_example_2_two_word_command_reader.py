line = input("Command: ").strip().lower()
parts = line.split()     # split into separate words
if len(parts) >= 2:      # safe to read parts[1]
    verb = parts[0]      # the action word
    target = parts[1]    # object the verb acts on
    print(f"You try to {verb} the {target}.")
else:                    # too few words to act
    print("Use two words, e.g. 'open door'.")
