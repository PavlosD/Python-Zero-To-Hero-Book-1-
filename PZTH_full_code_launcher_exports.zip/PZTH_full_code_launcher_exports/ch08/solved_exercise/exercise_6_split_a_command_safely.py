command = "open door"
words = command.split()    # words for the parser
if len(words) >= 2:        # enough words to act on?
    action = words[0]      # first word is the verb
    target = words[1]      # second word is the object
    print(action)
    print(target)
