for i in range(4):
    print("Training starts!")
