def finish_level():                    # award this route and prepare the next
    state["score"] += 100 * state["level"]

    if state["level"] == MAX_LEVEL:    # final route has been cleared
        state["screen"] = "won"        # victory screen next frame
        return

    state["level"] += 1                  # advance to the next route
    state["deliveries"] = 0            # no packages delivered on the new route
    state["required"] = 5 + state["level"]
    state["portal_active"] = False     # earn the portal again
    packages.clear()                     # remove old route objects
