def greet_player(name):
    print(f"Welcome, {name}!")    # build a named welcome message
