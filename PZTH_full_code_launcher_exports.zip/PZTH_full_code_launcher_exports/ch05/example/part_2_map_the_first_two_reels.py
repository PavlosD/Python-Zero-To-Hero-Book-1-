if roll_1 == 1:
    reel_1 = "cherry"
elif roll_1 == 2:
    reel_1 = "lemon"
elif roll_1 == 3:
    reel_1 = "star"
else:
    reel_1 = "bell"
