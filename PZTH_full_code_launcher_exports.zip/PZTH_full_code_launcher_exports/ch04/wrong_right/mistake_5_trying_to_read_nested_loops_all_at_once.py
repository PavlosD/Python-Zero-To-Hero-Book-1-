# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: starting inside hides the row-by-row structure
# # for row in range(2):
# # for col in range(3):
# # print("#", end="")

# RIGHT VERSION
# CORRECT: outer rows, inner columns
for row in range(2):
    for col in range(3):
        print("#", end="")
    print()
