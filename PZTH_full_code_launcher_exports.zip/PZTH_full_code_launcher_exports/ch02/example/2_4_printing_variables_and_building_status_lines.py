player_name = "Rin"    # same name reused in later messages
print(player_name)
