game_state = "menu"         # open on the menu
if game_state == "menu":    # menu branch is active
    print("Show title")
