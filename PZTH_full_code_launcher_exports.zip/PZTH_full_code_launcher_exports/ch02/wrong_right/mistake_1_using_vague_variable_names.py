# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: the meaning is hidden
# x = "Luna"
# y = 111

# RIGHT VERSION
# CORRECT: the names explain the values
player_name = "Luna"
player_score = 111
