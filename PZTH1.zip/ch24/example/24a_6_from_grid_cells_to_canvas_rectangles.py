# convert grid coordinates into canvas coordinates
def grid_to_pixels(x, y):              # cell coords to pixel box
    left = x * CELL_SIZE               # left edge of snake tile
    top = y * CELL_SIZE                # top edge of snake tile
    right = left + CELL_SIZE           # right edge of snake tile
    bottom = top + CELL_SIZE           # cell bottom edge
    return left, top, right, bottom    # canvas rectangle edges
