for i in range(1, 6):    # count upward until break stops the loop
    print(i)
    if i == 3:           # time to stop?
        break            # stop when i reaches 3
