while wrong_guesses < max_wrong:      # guesses remain?
    display = ""                      # rebuild mask this turn

    for letter in secret_word:        # inspect each secret letter
        if letter in guessed_letters: # has player tried this letter?
            display = display + letter + " "
        else:
            display = display + "_ "  # hide unguessed letter
