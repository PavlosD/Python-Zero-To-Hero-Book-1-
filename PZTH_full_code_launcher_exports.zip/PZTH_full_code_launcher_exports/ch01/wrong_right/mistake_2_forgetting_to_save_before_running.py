# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: code changed, but the old saved version runs
# # The file on disk still contains the old code.

# RIGHT VERSION
# CORRECT: save first, then run
print("Saved version running now.")
