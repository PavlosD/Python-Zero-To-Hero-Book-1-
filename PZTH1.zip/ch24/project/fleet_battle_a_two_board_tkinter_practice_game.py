SHIP_SIZES = [4, 3, 3, 2]    # four ships: 4, 3, 3, 2

enemy_board[row][col] = "S"     # hidden enemy ship cell
player_board[row][col] = "S"    # visible player ship cell
enemy_view[row][col] = "?"      # player has not fired here
player_view[row][col] = "?"     # computer has not fired here

import random                # place both fleets and choose computer shots
import tkinter as tk         # GUI toolkit for both boards

BG = "#101820"               # dark window frame
PANEL = "#172a3a"            # canvas sea background
WATER = "#244b67"            # unknown water square
SHIP_FILL = "#6c757d"        # your visible ship cells
GRID_LINE = "#d8f3dc"        # board lines and labels
TEXT = "#f2f2f2"             # light text on dark panels
ACCENT = "#7c83ff"           # restart button colour
HIT_COLOUR = "#ff5d6c"       # hit marker colour
MISS_COLOUR = "#d8f3dc"      # miss dot colour

WARN = "#ffd166"             # warning color for the final overlay

GRID_SIZE = 8                # 8 by 8 board
CELL = 34                    # pixel size of one cell
ENEMY_X = 54                 # enemy board left edge
PLAYER_X = 430               # player board left edge
BOARD_Y = 76                 # top edge for both boards
CANVAS_W = 760               # two boards plus gap
CANVAS_H = 430               # boards, labels, overlay
COMPUTER_DELAY = 600         # pause before computer fires

UNKNOWN = "?"                # square not fired
MISS = "o"                   # shot with no ship
HIT = "X"                    # shot that found a ship
SHIP = "S"                   # hidden or visible ship
SEA = "~"                    # empty sea cell
SHIP_SIZES = [4, 3, 3, 2]    # four ships: 4, 3, 3, 2
LETTERS = "ABCDEFGH"         # column labels

enemy_board = []                # enemy ships, hidden
player_board = []               # player ships, visible
enemy_view = []                 # player shots at enemy
player_view = []                # computer shots at player
enemy_cells_left = 0            # enemy ship cells alive
player_cells_left = 0           # player ship cells alive
game_over = False               # battle has not ended
waiting_for_computer = False    # blocks double player turns
computer_job = None             # callback ID for one computer turn

def make_board(fill):                     # build one empty fleet board
    board = []                            # rows collect here
    for row in range(GRID_SIZE):          # one row per board line
        line = [fill] * GRID_SIZE         # one filled board row
        board.append(line)                # add this row to the board
    return board                          # finished 2D list


def cell_name(row, col):                  # convert indexes to labels
    return LETTERS[col] + str(row + 1)    # example: row 0, col 2 -> C1

def can_place_ship(board, row, col, size, direction):
    if direction == "H":            # ship runs across columns
        end_col = col + size - 1    # last column it needs
        if end_col >= GRID_SIZE:    # would leave the board
            return False            # reject a ship past the right edge
        for test_col in range(col, col + size):
            if board[row][test_col] == SHIP:
                return False        # another ship is here
    else:                           # ship runs down rows
        end_row = row + size - 1    # last row it needs
        if end_row >= GRID_SIZE:    # would leave the board
            return False            # reject a ship past the bottom edge

        for test_row in range(row, row + size):
            if board[test_row][col] == SHIP:
                return False        # another ship is here
    return True                     # ship fits without overlap or overflow

def place_ship(board, row, col, size, direction):
    if direction == "H":                   # fill cells across one row
        for test_col in range(col, col + size):
            board[row][test_col] = SHIP    # mark this ship cell
    else:                                  # fill cells down one column
        for test_row in range(row, row + size):
            board[test_row][col] = SHIP    # mark this ship cell

def place_fleet(board):                    # place every ship legally at random
    for size in SHIP_SIZES:                # place 4, then 3, 3, 2
        placed = False                     # this ship still needs room
        while not placed:                  # keep trying safe starts
            row = random.randrange(GRID_SIZE)
            col = random.randrange(GRID_SIZE)
            direction = random.choice(["H", "V"])
            if can_place_ship(board, row, col, size, direction):
                place_ship(board, row, col, size, direction)
                placed = True              # go to the next ship

def reset_game():                          # rebuild both fleets for a rematch
    global enemy_board, player_board       # replace both fleets
    global enemy_view, player_view         # replace both shot maps
    global enemy_cells_left, player_cells_left      # fresh counts each game
    global game_over, waiting_for_computer, computer_job    # flags reset too

    if computer_job is not None:           # a PC shot may be queued
        root.after_cancel(computer_job)    # cancel it before restarting
        computer_job = None                # no queued PC shot remains

    enemy_board = make_board(SEA)          # hidden enemy fleet map
    player_board = make_board(SEA)
    enemy_view = make_board(UNKNOWN)       # enemy board stays hidden
    player_view = make_board(UNKNOWN)      # computer-view cells begin unknown
    place_fleet(enemy_board)               # hide enemy ships
    place_fleet(player_board)              # place visible player ships

    enemy_cells_left = sum(SHIP_SIZES)     # enemy has 12 ship cells
    player_cells_left = sum(SHIP_SIZES)    # player has 12 ship cells
    game_over = False                      # new battle accepts player shots
    waiting_for_computer = False           # player starts the duel

    update_labels()                        # counters match new battle
    draw_boards()                          # repaint reset battle
    message_label.config(                    # opening instruction
        text="Fire on the enemy board. Computer fires after you."
    )

def update_labels():                       # both fleet counters
    enemy_label.config(text=f"Enemy ship cells: {enemy_cells_left}")
    player_label.config(text=f"Your ship cells: {player_cells_left}")


def draw_marker(x1, y1, x2, y2, state):    # draw one shot symbol
    cx = (x1 + x2) // 2                    # marker center x
    cy = (y1 + y2) // 2                    # marker center y
    if state == MISS:                      # miss is a small dot
        canvas.create_oval(cx - 5, cy - 5, cx + 5, cy + 5,
                           fill=MISS_COLOUR, outline=MISS_COLOUR)
    elif state == HIT:                     # hit is a bold X

        canvas.create_rectangle(x1 + 3, y1 + 3, x2 - 3, y2 - 3,
                                fill="#4a1f2b", outline="")
        canvas.create_line(x1 + 9, y1 + 9, x2 - 9, y2 - 9,
                           fill=HIT_COLOUR, width=4)
        canvas.create_line(x2 - 9, y1 + 9, x1 + 9, y2 - 9,
                           fill=HIT_COLOUR, width=4)

def draw_one_board(base_x, title, board, view, show_ships):
    canvas.create_text(base_x + 4 * CELL, BOARD_Y - 48,
                       text=title, fill=TEXT,
                       font=("Arial", 15, "bold"))
    for col in range(GRID_SIZE):             # letters above this board
        x = base_x + col * CELL + CELL // 2      # letter centered on column
        canvas.create_text(x, BOARD_Y - 18, text=LETTERS[col],
                           fill=TEXT, font=("Arial", 9, "bold"))
    for row in range(GRID_SIZE):             # numbers beside this board
        y = BOARD_Y + row * CELL + CELL // 2
        canvas.create_text(base_x - 20, y, text=str(row + 1),
                           fill=TEXT, font=("Arial", 9, "bold"))

    for row in range(GRID_SIZE):             # draw each board row
        for col in range(GRID_SIZE):         # draw each board column
            x1 = base_x + col * CELL         # cell left edge
            y1 = BOARD_Y + row * CELL        # cell top edge
            x2 = x1 + CELL                   # cell right edge
            y2 = y1 + CELL                   # cell bottom edge
            fill = WATER                     # enemy ships stay hidden
            if show_ships and board[row][col] == SHIP:
                fill = SHIP_FILL             # player ships are visible
            canvas.create_rectangle(x1, y1, x2, y2,
                                    fill=fill, outline=GRID_LINE)
            draw_marker(x1, y1, x2, y2, view[row][col])

def draw_boards():                       # redraw both fleet boards
    canvas.delete("all")                 # erase the previous board drawing
    canvas.create_rectangle(0, 0, CANVAS_W, CANVAS_H,
                            fill=PANEL, outline="")
    draw_one_board(ENEMY_X, "Enemy Waters", enemy_board,
                   enemy_view, False)    # enemy fleet is hidden
    draw_one_board(PLAYER_X, "Your Fleet", player_board,
                   player_view, True)    # show every player fleet cell

def enemy_cell_from_click(event):        # map a canvas click to an enemy cell
    col = (event.x - ENEMY_X) // CELL    # pixel x to enemy column
    row = (event.y - BOARD_Y) // CELL    # pixel y to enemy row
    inside_row = 0 <= row < GRID_SIZE    # row must be valid
    inside_col = 0 <= col < GRID_SIZE    # column must be valid
    if inside_row and inside_col:        # click is inside enemy grid
        return row, col                  # convert a click to its board cell
    return None                          # ignore outside clicks

def player_fire(event):                    # handle one player shot
    global enemy_cells_left                # a hit may remove one enemy cell
    global waiting_for_computer            # locks turn until PC fires
    global computer_job                    # reuse the pending shot ID

    if game_over or waiting_for_computer:    # turn is locked
        return
    cell = enemy_cell_from_click(event)    # convert mouse to target
    if cell is None:                       # click missed enemy board
        return                               # outside the enemy grid
    row, col = cell                        # split the target cell
    if enemy_view[row][col] != UNKNOWN:    # already fired here

        message_label.config(text="That enemy square was already checked.")
        return                               # wait for a different target

    if enemy_board[row][col] == SHIP:      # hidden ship is present
        enemy_view[row][col] = HIT         # reveal a hit to player
        enemy_cells_left -= 1              # enemy loses one ship cell
        message = f"Hit at {cell_name(row, col)}!"
    else:                                  # hidden board has sea
        enemy_view[row][col] = MISS        # reveal a miss to player
        message = f"Miss at {cell_name(row, col)}."

    update_labels()                        # refresh remaining-ship counts
    draw_boards()                          # refresh both boards
    if enemy_cells_left == 0:              # enemy fleet destroyed
        end_game("You sank the enemy fleet. You win!")
        return                               # enemy fleet gone; end battle

    waiting_for_computer = True            # player cannot fire again yet
    message_label.config(text=message + " Computer is aiming...")
    computer_job = root.after(COMPUTER_DELAY, computer_fire)

def computer_fire():                      # the delayed reply shot
    global player_cells_left              # a hit may remove one player cell
    global waiting_for_computer           # unlock player afterward
    global computer_job                   # reuse the pending shot ID

    computer_job = None                   # computer callback no longer queued
    if game_over:                         # round ended during delay
        return                              # too late to fire
    targets = []                          # every unshot square
    for row in range(GRID_SIZE):          # scan every player row
        for col in range(GRID_SIZE):      # scan every player column
            if player_view[row][col] == UNKNOWN:

                targets.append((row, col))      # still a legal target
    if not targets:                       # board fully fired upon
        waiting_for_computer = False      # let the player continue
        return                            # skip an impossible shot
    row, col = random.choice(targets)     # pick one legal computer target

    if player_board[row][col] == SHIP:    # computer found your ship
        player_view[row][col] = HIT       # mark hit on your open board
        player_cells_left -= 1            # player loses one ship cell
        message = f"Computer hit your fleet at {cell_name(row, col)}."
    else:                                 # computer fired into sea
        player_view[row][col] = MISS      # mark miss on your board
        message = f"Computer missed at {cell_name(row, col)}."

    waiting_for_computer = False          # player may fire again
    update_labels()                       # refresh both counters
    draw_boards()                         # repaint computer shot
    if player_cells_left == 0:            # player fleet destroyed
        end_game("Computer sank your fleet.")
    else:                                   # battle continues
        message_label.config(text=message + " Your turn.")

def end_game(message):                    # battle over overlay
    global game_over, waiting_for_computer    # ending writes both flags
    game_over = True                      # battle result blocks more shots
    waiting_for_computer = False          # release the pending-turn lock
    message_label.config(text=message)    # repeat result below both boards
    canvas.create_rectangle(205, 178, 555, 260,
                            fill="#071018", outline=TEXT, width=2)
    canvas.create_text(CANVAS_W // 2, 205, text="BATTLE OVER",
                       fill=WARN, font=("Arial", 22, "bold"))
    canvas.create_text(CANVAS_W // 2, 236, text=message,
                       fill=TEXT, font=("Arial", 12, "bold"))

root = tk.Tk()                              # Fleet Battle window
root.title("Fleet Battle")
root.geometry("820x610")                    # fit both boards and controls
root.resizable(False, False)                # keep the fixed layout
root.configure(bg=BG)                       # use dark battle palette

main_frame = tk.Frame(root, bg=BG)          # holds all battle widgets
main_frame.pack(fill="both", expand=True, padx=18, pady=14)

title_label = tk.Label(main_frame, text="Fleet Battle",
                       font=("Arial", 24, "bold"), fg=TEXT, bg=BG)
title_label.pack()                          # headline over the boards
subtitle_label = tk.Label(                                    # fleet directions
    main_frame,
    text="Click Enemy Waters. Watch the computer fire at Your Fleet.",
    font=("Arial", 11, "bold"), fg=GRID_LINE, bg=BG)
subtitle_label.pack(pady=(2, 8))            # subtitle under the title

info_frame = tk.Frame(main_frame, bg=BG)    # counter row
info_frame.pack(pady=(0, 8))                # counters under subtitle
enemy_label = tk.Label(info_frame, font=("Arial", 12, "bold"),
                       fg=TEXT, bg=BG, width=22)
enemy_label.grid(row=0, column=0, padx=8)      # left counter
player_label = tk.Label(info_frame, font=("Arial", 12, "bold"),
                        fg=TEXT, bg=BG, width=22)
player_label.grid(row=0, column=1, padx=8)    # right counter

canvas = tk.Canvas(main_frame, width=CANVAS_W, height=CANVAS_H,
                   bg=PANEL, highlightthickness=2,
                   highlightbackground=GRID_LINE)
canvas.pack()                             # board canvas in place
canvas.bind("<Button-1>", player_fire)    # clicks filtered to the enemy grid

message_label = tk.Label(                   # status and result message
    main_frame,
    text="Fire on the enemy board. Computer fires after you.",
    font=("Arial", 11, "bold"), fg=TEXT, bg=BG,
    wraplength=740)
message_label.pack(pady=(8, 10))          # place the message label

restart_button = tk.Button(main_frame, text="Restart Battle",
                           font=("Arial", 12, "bold"), width=18,
                           command=reset_game, bg=ACCENT, fg=TEXT,
                           activebackground=ACCENT, bd=0)
restart_button.pack()                     # new fleets on demand

reset_game()                              # place both random fleets
root.mainloop()                           # handle shots, Restart, and CPU turns
