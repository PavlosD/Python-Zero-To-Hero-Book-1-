if roll_3 == 1:
    reel_3 = "cherry"
elif roll_3 == 2:
    reel_3 = "lemon"
elif roll_3 == 3:
    reel_3 = "star"
else:
    reel_3 = "bell"

score = 0                          # losing spins still earn zero
