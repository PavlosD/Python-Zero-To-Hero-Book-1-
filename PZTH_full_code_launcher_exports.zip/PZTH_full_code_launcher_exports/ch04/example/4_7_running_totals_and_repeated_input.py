total = 0
for i in range(3):                    # collect three numbers
    number = int(input("Enter a number: "))
    total = total + number            # add this entry to running total
    print("Current total:", total)    # total after this entry
