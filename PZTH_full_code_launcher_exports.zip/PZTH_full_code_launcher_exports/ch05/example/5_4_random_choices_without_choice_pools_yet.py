import random                         # pick the chest reward
reward_roll = random.randint(1, 4)    # choose one of four rewards
if reward_roll == 1:                  # coin reward
    reward = "coins"                  # common drop
elif reward_roll == 2:                # rare gem reward
    reward = "gem"                    # rare drop
elif reward_roll == 3:                # healing potion reward
    reward = "potion"                 # healing drop
else:
    reward = "shield"                 # defensive reward
print("You found:", reward)
