packages.append({        # package created above the play area
    "x": random.randint(42, WIDTH - 42),
    "y": random.randint(HUD_HEIGHT - 150, HUD_HEIGHT - 36),
    "size": 22,          # square side in px
    "speed": random.uniform(1.6, 2.4) + state["level"] * 0.22,
})
