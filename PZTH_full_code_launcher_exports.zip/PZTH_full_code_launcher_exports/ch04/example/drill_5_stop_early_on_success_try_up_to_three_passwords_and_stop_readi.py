correct = False                        # door still locked
attempt = 1                            # first password try
while attempt <= 3 and not correct:    # tries remain and door locked?
    typed = input(f"Password attempt {attempt}: ").strip().lower()
    if typed == "open sesame":         # password accepted?
        correct = True                 # unlock the door
    attempt = attempt + 1              # count the password try just completed
if correct:                            # did any try unlock the door?
    print("Door opens.")
else:
    print("Door stays locked.")        # every try failed
