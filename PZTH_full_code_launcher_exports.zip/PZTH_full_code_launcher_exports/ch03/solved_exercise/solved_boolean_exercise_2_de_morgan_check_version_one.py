a = True                           # first truth-table input
b = False                          # second truth-table input
left_side = not (a and b)          # left half of the law
right_side = (not a) or (not b)    # right half of the law
print(left_side)
print(right_side)
print(left_side == right_side)     # do both paths agree?
