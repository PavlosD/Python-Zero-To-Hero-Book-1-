# Cosmic Courier - Canvas Edition
# Move with arrow keys or WASD.
# Collect packages, dodge asteroids, and enter the portal.
# Press ENTER to start, H for help, P to pause, and ESC to leave help.

import random                     # spawn packages and asteroids unpredictably
import tkinter as tk

# ---- colour palette ----
BG    = "#0f1226"                 # deep navy window
PANEL = "#1b1f3a"                 # raised panel tone
TEXT  = "#e8eaf6"                 # soft white text
ACC   = "#7c83ff"                 # accent colour
GOOD  = "#27c66b"                 # win / go / correct
BAD   = "#ff5d6c"                 # lose / wrong / miss
WARN  = "#ffd166"                 # waiting / caution

# ---------------------- window settings ---------------------
WIDTH = 760                       # the arena is 760 px wide
HEIGHT = 520                      # 520 px tall
HUD_HEIGHT = 64                   # 64 px status strip on top
FRAME_DELAY_MS = 30               # 30 ms per frame is about 33 fps
PLAYER_SPEED = 7                  # the ship slides 7 px a frame
MAX_LEVEL = 3                     # across three delivery routes

window = tk.Tk()
window.configure(bg=BG)
window.title("Cosmic Courier - Canvas Edition")
window.resizable(False, False)        # lock the window size

canvas = tk.Canvas(                       # one drawing surface
    window,                                       # lives inside the window
    width=WIDTH,
    height=HEIGHT,
    bg=BG,
    highlightthickness=0,           # no focus border
)

canvas.pack()                     # place the canvas in the window

# Key values stay True only while that movement key is held.
keys = {                                         # one flag per movement key
    "Left": False,                     # arrows arrive capitalized
    "Right": False,                   # strafe right
    "Up": False,                         # climb
    "Down": False,                     # descend
    "a": False,                           # WASD, lowercase
    "d": False,                           # right on WASD
    "w": False,                           # up on WASD
    "s": False,                           # down on WASD
}

player = {                                     # ship collision geometry
    "x": WIDTH // 2,                 # start centered
    "y": HEIGHT - 78,               # near the floor
    "w": 34,                                 # hull width in px
    "h": 32,                                 # hull height in px
}

state = {                                       # screen and session state
    "screen": "title",         # title, help, playing, paused
    "score": 0,                           # points banked
    "lives": 3,                           # crashes allowed
    "level": 1,                           # current delivery-route number
    "deliveries": 0,                 # packages delivered on this route
    "required": 6,                     # crates needed for the exit
    "frame": 0,                           # ticks since launch
    "portal_active": False,        # exit starts shut
}

stars = []                     # background stars, not gameplay objects
packages = []                  # square delivery packages
asteroids = []                 # round hazards
frame_job = None              # ID of the one scheduled frame
portal = {"x": WIDTH // 2, "y": 126, "w": 74, "h": 74}

# -------------------- setup and helpers ---------------------
def build_stars():                       # rebuild the starfield
    stars.clear()  # reuse the existing list object
    for _ in range(105):
        stars.append({                     # one star per pass
            "x": random.randint(0, WIDTH),
            "y": random.randint(HUD_HEIGHT, HEIGHT),
            "size": random.choice([1, 1, 1, 2, 2, 3]),
            "speed": random.choice([0.25, 0.4, 0.6]),
        })

def reset_game():                        # restore first-route mission state
    player["x"] = WIDTH // 2             # ship returns to horizontal centre
    player["y"] = HEIGHT - 78            # starting height near the floor
    state["screen"] = "playing"          # leave the title screen
    state["score"] = 0                   # discard the previous score
    state["lives"] = 3                   # restore all lives
    state["level"] = 1                   # return to the first route
    state["deliveries"] = 0              # no packages delivered yet
    state["required"] = 6                # six packages unlock the portal
    state["frame"] = 0                   # restart the frame counter
    state["portal_active"] = False       # portal starts closed
    packages.clear()

    asteroids.clear()                    # remove old hazards
    portal["x"] = WIDTH // 2             # portal returns to centre

def clamp(value, low, high):             # constrain one coordinate to a range
    return max(low, min(value, high))

def player_box():                        # ship rectangle for collision checks
    half_w = player["w"] // 2            # horizontal centre-to-edge distance
    half_h = player["h"] // 2            # vertical centre-to-edge distance
    return (
        player["x"] - half_w,              # left edge
        player["y"] - half_h,              # top edge
        player["x"] + half_w,              # right edge
        player["y"] + half_h,              # bottom edge
    )

def object_box(item):          # collision box for a package or asteroid
    # Packages and asteroids both use a center point plus a size.
    half = item["size"] // 2   # center-to-edge distance
    return (                                        # box corners from half-size
        item["x"] - half,              # left
        item["y"] - half,              # top
        item["x"] + half,              # right
        item["y"] + half,              # bottom
    )

def portal_box():              # rings collide as a box
    # The portal is drawn as rings but tested as a rectangle.
    half_w = portal["w"] // 2  # center-to-edge, horizontal
    half_h = portal["h"] // 2  # center-to-edge, vertical
    return (                                        # portal overlap box
        portal["x"] - half_w,      # left
        portal["y"] - half_h,      # top
        portal["x"] + half_w,      # right
        portal["y"] + half_h,      # bottom
    )

def boxes_overlap(a, b):       # True when rectangles overlap
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    return ax1 < bx2 and ax2 > bx1 and ay1 < by2 and ay2 > by1

# ----------------- movement, spawning, collisions -----------
def spawn_package():           # drop a new crate to catch
    # New packages begin above the play area so they fall into view.
    packages.append({                      # spawn one delivery package
        "x": random.randint(42, WIDTH - 42),
        "y": random.randint(HUD_HEIGHT - 150, HUD_HEIGHT - 36),
        "size": 22,                          # square side in px

        "speed": random.uniform(1.6, 2.4) + state["level"] * 0.22,
    })

def spawn_asteroid():                      # drop a fresh hazard
    # Higher levels make each new rock a little faster.
    asteroids.append({                                     # falling asteroid
        "x": random.randint(34, WIDTH - 34),
        "y": random.randint(HUD_HEIGHT - 185, HUD_HEIGHT - 48),
        "size": random.randint(26, 42),        # rocks vary in size
        "speed": random.uniform(2.0, 3.0) + state["level"] * 0.45,
    })

def move_player():                         # move from the keys held this frame
    dx = 0                                 # no sideways input yet
    dy = 0                                 # no vertical input yet

    if keys["Left"] or keys["a"]:          # arrow or A steers left
        dx -= PLAYER_SPEED                             # move left
    if keys["Right"] or keys["d"]:         # arrow or D steers right
        dx += PLAYER_SPEED                             # move right
    if keys["Up"] or keys["w"]:            # arrow or W climbs
        dy -= PLAYER_SPEED                             # move up
    if keys["Down"] or keys["s"]:          # arrow or S dives
        dy += PLAYER_SPEED                             # move down

    player["x"] = clamp(player["x"] + dx, 24, WIDTH - 24)
    # Keep the ship below the HUD.
    player["y"] = clamp(player["y"] + dy, HUD_HEIGHT + 26, HEIGHT - 26)

def update_stars():                        # scroll the starfield
    # Drift stars down behind the playfield.
    for star in stars:                     # move and recycle each star
        star["y"] += star["speed"]             # each star drifts down
        if star["y"] > HEIGHT:             # recycle after leaving the bottom
            star["x"] = random.randint(0, WIDTH)
            star["y"] = HUD_HEIGHT         # respawn at the top

def update_objects():                      # move and remove off-screen objects
    for package in packages[:]:            # copy allows removal during the loop
        package["y"] += package["speed"]
        if package["y"] > HEIGHT + 30:     # package has fallen below the screen
            packages.remove(package)

    for asteroid in asteroids[:]:          # copy allows removal during the loop
        asteroid["y"] += asteroid["speed"]
        if asteroid["y"] > HEIGHT + 42:    # asteroid has left the arena
            asteroids.remove(asteroid)

def check_collisions():                    # apply contact effects
    ship = player_box()                    # one ship box reused below

    for package in packages[:]:            # catchable delivery objects
        if boxes_overlap(ship, object_box(package)):
            packages.remove(package)       # caught package leaves the screen
            state["score"] += 25 + state["level"] * 5
            state["deliveries"] += 1  # progress toward opening the portal

    for asteroid in asteroids[:]:          # damaging hazard objects
        if boxes_overlap(ship, object_box(asteroid)):
            asteroids.remove(asteroid)     # one collision consumes the asteroid
            state["lives"] -= 1              # crash costs one life
            state["score"] = max(0, state["score"] - 15)
            if state["lives"] <= 0:        # no lives remain
                state["screen"] = "game_over"
                return                       # stop after route failure

    if state["deliveries"] >= state["required"]:
        state["portal_active"] = True      # enough deliveries open the exit

    if state["portal_active"]:
        if boxes_overlap(ship, portal_box()):    # ship overlaps the open portal
            finish_level()

def finish_level():                    # award this route and prepare the next
    state["score"] += 100 * state["level"]

    if state["level"] == MAX_LEVEL:    # final route has been cleared
        state["screen"] = "won"        # victory screen next frame
        return

    state["level"] += 1                  # advance to the next route
    state["deliveries"] = 0            # no packages delivered on the new route
    state["required"] = 5 + state["level"]
    state["portal_active"] = False     # earn the portal again
    packages.clear()                     # remove old route objects

    asteroids.clear()                    # remove old route hazards
    player["x"] = WIDTH // 2           # ship returns to horizontal centre
    player["y"] = HEIGHT - 78          # ship returns near the floor
    portal["x"] = random.randint(130, WIDTH - 130)

# ---------------------- drawing helpers ---------------------
def draw_background():                 # repaint space and the playfield frame
    canvas.create_rectangle(0, 0, WIDTH, HEIGHT, fill="#111111", outline="")

    for star in stars:
        x = star["x"]
        y = star["y"]
        size = star["size"]
        canvas.create_oval(x, y, x + size, y + size, fill="#dddddd", outline="")

    canvas.create_rectangle(
        12,                              # left edge inset
        HUD_HEIGHT + 8,                  # below the HUD
        WIDTH - 12,                      # right edge inset
        HEIGHT - 12,                     # bottom inset
        outline="#777777",               # subdued playfield outline
        width=2,
    )

def draw_hud():                  # status strip along the top
    # The HUD shows score, lives, and route progress.
    canvas.create_rectangle(0, 0, WIDTH, HUD_HEIGHT, fill="#202020", outline="")
    hud = (                                             # one long status string
        f"Score: {state['score']}     "
        f"Lives: {state['lives']}     "
        f"Level: {state['level']}/{MAX_LEVEL}     "
        f"Deliveries: {state['deliveries']}/{state['required']}"
    )
    canvas.create_text(                     # pin HUD text to the left edge
        24,                                             # x: small left margin
        24,                                             # y: upper HUD line

        text=hud,
        anchor="w",                             # west: grow rightward
        fill=TEXT,
        font=("Arial", 13, "bold"),
    )

    if state["portal_active"]:   # change the prompt when the portal opens
        message = "PORTAL OPEN - fly into the rings"
    else:                                                 # portal still closed
        message = "Collect packages before the next asteroid belt closes in"

    canvas.create_text(                     # hint line underneath
        24,                                             # same left margin
        48,                                             # second HUD line
        text=message,
        anchor="w",                             # left-aligned again
        fill="#dddddd",
        font=("Arial", 10),

    )

def draw_player():                  # the courier ship itself
    # The polygon forms a small spacecraft.
    x = player["x"]                 # unpack for short math
    y = player["y"]                 # ship centre y-coordinate
    w = player["w"]                 # ship width
    h = player["h"]                 # ship height
    canvas.create_polygon(                  # four points, drawn in order
        x,                                                  # nose tip x
        y - h // 2,                                # nose tip y, at the top
        x - w // 2,                                # left wing x
        y + h // 2,                                # wing y, at the bottom
        x,                                                  # tail notch x

        y + 8,                                          # notch above the wings
        x + w // 2,                                # right wing x
        y + h // 2,                                # same wing height
        fill="#eeeeee",                        # pale hull
        outline="#555555",                  # darker rim
        width=2,
    )

    flame = 18 if state["frame"] % 8 < 4 else 10
    canvas.create_line(x, y + 13, x, y + 13 + flame, fill="#bbbbbb", width=3)

def draw_packages():                # square crates with ribbons
    # Packages are square, so they read differently from round asteroids.
    for package in packages:        # each crate on screen
        x1, y1, x2, y2 = object_box(package)
        canvas.create_rectangle(      # crate body
            x1, y1, x2, y2,                # corners from object_box
            fill="#f2f2f2", outline="#444444"
        )
        canvas.create_line(x1, y1 + 7, x2, y1 + 7, fill="#888888")

        canvas.create_line(x1 + 7, y1, x1 + 7, y2, fill="#888888")

def draw_asteroids():               # cratered round hazards
    # Crater marks keep hazards recognizable in grayscale print.
    for asteroid in asteroids:      # each rock on screen
        x1, y1, x2, y2 = object_box(asteroid)
        canvas.create_oval(x1, y1, x2, y2, fill="#777777", outline="#333333")
        canvas.create_oval(x1 + 8, y1 + 7, x1 + 15, y1 + 14, fill="#555555")
        canvas.create_oval(x2 - 14, y2 - 15, x2 - 7, y2 - 8, fill="#555555")

def draw_portal():                       # pulsing exit rings
    # Hide the portal until deliveries are complete.
    if not state["portal_active"]:       # skip drawing until the portal unlocks
        return

    x = portal["x"]                      # portal center
    y = portal["y"]                      # portal centre y-coordinate
    pulse = state["frame"] % 18          # 0-17, repeats forever
    for ring in range(3):
        size = 34 + ring * 15 + pulse    # expand each ring with the pulse
        canvas.create_oval(                # one ring per pass
            x - size,                      # box left

            y - size,                      # box top
            x + size,                      # box right
            y + size,                      # box bottom
            outline="#eeeeee",             # bright ring line
            width=2,
        )
    canvas.create_text(x, y, text="EXIT", fill=TEXT, font=("Arial", 10, "bold"))

# --------------------- screens and overlays -----------------
def draw_overlay(title, subtitle, prompt):    # shared pause/lose/win panel
    # One panel style serves pause, loss, and victory screens.
    canvas.create_rectangle(              # dim panel behind the text
        135, 160, 625, 360,               # panel corners
        fill="#222222", outline="#dddddd"
    )
    canvas.create_text(                   # big headline
        WIDTH // 2,                       # headline on the centre line
        220,                              # headline height
        text=title,
        fill=TEXT,

        font=("Arial", 26, "bold"),
    )
    canvas.create_text(                   # smaller detail line
        WIDTH // 2,                       # subtitle shares the centre line
        272,                              # below the headline
        text=subtitle,
        fill="#dddddd",
        font=("Arial", 13),
    )
    canvas.create_text(
        WIDTH // 2,                       # prompt shares the centre line
        318,                              # lowest line

        text=prompt,
        fill=TEXT,
        font=("Arial", 14, "bold"),
    )

def show_title():           # draw the opening screen
    canvas.delete("all")    # wipe the frame before redraw
    draw_background()              # stars behind the menu
    canvas.create_text(          # main game title
        WIDTH // 2,                  # title on the centre line
        120,                                # high on the screen
        text="COSMIC COURIER",
        fill=TEXT,
        font=("Arial", 30, "bold"),
    )
    canvas.create_text(          # mission summary
        WIDTH // 2,                  # mission summary shares the centre

        174,                                # under the title
        text="Collect packages, dodge asteroids, and reach the portal.",
        fill="#dddddd",
        font=("Arial", 13),

    )
    canvas.create_rectangle(250, 238, 510, 304, outline="#bbbbbb", width=2)
    canvas.create_text(          # inside the button box
        WIDTH // 2,                  # start prompt centred in its box
        270,                                # box midline
        text="Press ENTER to Start",
        fill=TEXT,
        font=("Arial", 18, "bold"),
    )
    canvas.create_text(          # controls reminder
        WIDTH // 2,                  # controls note centred below
        342,                                # below the box

        text="Arrow keys or WASD to move. H opens the briefing.",
        fill="#cccccc",
        font=("Arial", 12),
    )

def show_help():                           # mission briefing screen
    canvas.delete("all")                   # wipe the frame before redraw
    draw_background()                        # same sky as the game
    lines = [                                # briefing, one line each
        "Mission Briefing",                  # index 0 is the heading
        "1. Fly into square packages to complete deliveries.",
        "2. Avoid round asteroids. Each hit costs one life.",
        "3. After enough deliveries, the portal opens.",
        "4. Enter the portal to advance to the next route.",
        "5. Clear three routes to win the courier contract.",
        "Press ESC to return to the title screen.",
    ]

    for index, line in enumerate(lines):
        size = 23 if index == 0 else 13    # heading bigger than body
        weight = "bold" if index == 0 else "normal"
        fill = TEXT if index == 0 else "#dddddd"
        canvas.create_text(                  # one line per pass
            WIDTH // 2,                      # briefing uses one centre line
            110 + index * 42,                # even vertical spacing
            text=line,
            fill=fill,
            font=("Arial", size, weight),
        )

def draw_game():                           # one full frame, in order
    # Rebuild the frame from the stored mission state.
    canvas.delete("all")                   # wipe the frame before redraw
    draw_background()                        # start with the space backdrop
    draw_portal()                            # exit under the actors
    draw_packages()                          # crates
    draw_asteroids()                         # hazards
    draw_player()                            # the ship on top
    draw_hud()                               # HUD above everything

    if state["screen"] == "paused":        # overlays sit on the scene
        draw_overlay(
            "PAUSED",
            "Flight controls are paused.",
            "Press P to continue")
    elif state["screen"] == "game_over":
        draw_overlay(
            "ROUTE FAILED",
            f"Final score: {state['score']}",
            "Press ENTER to fly another route")
    elif state["screen"] == "won":         # victory uses the same panel
        draw_overlay(
            "ROUTE COMPLETE",
            f"Final score: {state['score']}",
            "Press ENTER to fly another route")

# ---------------- game loop and keyboard input ----------------
def schedule_next_frame():               # keep one callback chain alive
    global frame_job                      # replace the shared callback ID
    if frame_job is None and state["screen"] == "playing":
        frame_job = window.after(FRAME_DELAY_MS, update_game)

def update_game():                       # run one animation frame
    global frame_job                      # fired job no longer waits
    frame_job = None                      # this callback is running now

    if state["screen"] != "playing":     # non-playing screens skip physics
        draw_game()
        return

    state["frame"] += 1                   # advance the frame counter
    update_stars()
    move_player()

    if len(packages) < 3 and random.random() < 0.035:
        spawn_package()
    asteroid_chance = 0.045 + state["level"] * 0.01
    too_few_asteroids = len(asteroids) < 4 + state["level"]
    if too_few_asteroids and random.random() < asteroid_chance:
        spawn_asteroid()

    update_objects()
    check_collisions()
    draw_game()
    schedule_next_frame()                 # book one later frame, never two

def start_game():                        # Enter starts or retries
    if state["screen"] in ("title", "game_over", "won"):
        reset_game()                      # restore the first-route state
        if frame_job is None:
            update_game()                 # begin the single frame chain

def key_down(event):                   # hold movement keys or switch screens
    key = event.keysym                 # key name from the press event

    if key in keys:
        keys[key] = True               # movement remains active while held

    if key == "Return":                # Enter starts or retries
        start_game()
    elif key.lower() == "h" and state["screen"] == "title":
        state["screen"] = "help"
        show_help()                      # redraw the help screen
    elif key == "Escape" and state["screen"] == "help":

        state["screen"] = "title"
        show_title()                     # redraw the title screen
    elif key.lower() == "p" and state["screen"] == "playing":
        state["screen"] = "paused"
        draw_game()                      # add the pause overlay
    elif key.lower() == "p" and state["screen"] == "paused":
        state["screen"] = "playing"
        if frame_job is None:             # no callback is already waiting
            update_game()                 # resume one frame chain

def key_up(event):                     # release one movement key
    key = event.keysym                 # key name from the release event
    if key in keys:
        keys[key] = False

# ----------------------- program start -----------------------
build_stars()                            # starfield before title
window.bind("<KeyPress>", key_down)    # key presses enter key_down
window.bind("<KeyRelease>", key_up)    # key releases enter key_up
window.focus_set()                       # send keyboard events to this window
show_title()                             # draw the opening screen
window.mainloop()                      # listen for courier controls
