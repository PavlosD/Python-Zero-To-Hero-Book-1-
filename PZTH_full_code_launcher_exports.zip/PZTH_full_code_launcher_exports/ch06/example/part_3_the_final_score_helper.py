def show_final_score(score):          # final-rank function
    print("================================")
    print(f"Final banner score: {score}")
    if score >= 50:                   # high-score boundary
        print("Rank: Boss Artist")
    else:                             # lowest banner rank
        print("Rank: Banner Apprentice")
