player_speed = 4.5        # pixels per move
critical_chance = 0.25    # a 25% crit chance
