for i in range(5):
    print("*")           # one star per loop pass
