inventory = ["potion", "shield", "potion"]
inventory.remove("potion")    # potion leaves the bag
print(inventory)              # current contents
