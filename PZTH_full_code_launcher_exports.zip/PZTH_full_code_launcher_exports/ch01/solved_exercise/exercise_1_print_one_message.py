print("Welcome to Python.")    # first welcome message
