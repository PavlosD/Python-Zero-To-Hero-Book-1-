window.mainloop()    # listen for game controls
