def change_direction(new_direction):    # queue a keyboard turn
    global next_direction               # queue a turn for the next tick

    blocked_turns = {                   # reverse turns are illegal
        "Up": "Down",                   # up cannot snap downward
        "Down": "Up",                   # down cannot snap upward
        "Left": "Right",                # left cannot snap right
        "Right": "Left"                 # right cannot snap left
    }
