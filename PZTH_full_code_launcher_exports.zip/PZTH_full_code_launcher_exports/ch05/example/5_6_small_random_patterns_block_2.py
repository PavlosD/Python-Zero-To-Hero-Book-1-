import random                          # vary the coin reward
coins_found = random.randint(5, 15)    # chest contains 5 to 15 coins
print("Coins found:", coins_found)
