import random                    # vary slash and strike damage
attack = input("Choose attack (slash or strike): ").strip().lower()
damage = random.randint(3, 8)    # shared 3-to-8 damage roll
# Slash and strike use the same damage roll.
if attack == "slash":            # slash attack selected
    print(f"You use Slash and deal {damage} damage.")
elif attack == "strike":         # strike uses the shared damage roll
    print(f"You use Strike and deal {damage} damage.")
else:
    print("Unknown attack.")     # fallback for typos
