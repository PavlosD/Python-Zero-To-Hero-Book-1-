def draw_one_board(base_x, title, board, view, show_ships):
    canvas.create_text(base_x + 4 * CELL, BOARD_Y - 48,
                       text=title, fill=TEXT,
                       font=("Arial", 15, "bold"))
    for col in range(GRID_SIZE):             # letters above this board
        x = base_x + col * CELL + CELL // 2      # letter centered on column
        canvas.create_text(x, BOARD_Y - 18, text=LETTERS[col],
                           fill=TEXT, font=("Arial", 9, "bold"))
    for row in range(GRID_SIZE):             # numbers beside this board
        y = BOARD_Y + row * CELL + CELL // 2
        canvas.create_text(base_x - 20, y, text=str(row + 1),
                           fill=TEXT, font=("Arial", 9, "bold"))
