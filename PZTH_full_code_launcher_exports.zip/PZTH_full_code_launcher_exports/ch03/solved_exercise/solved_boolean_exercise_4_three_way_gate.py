has_key = True          # player carries the key
has_password = False    # password not entered
is_admin = False        # no administrator override
if has_key and (has_password or is_admin):
    print("open")
else:
    print("locked")     # password and admin routes both fail
