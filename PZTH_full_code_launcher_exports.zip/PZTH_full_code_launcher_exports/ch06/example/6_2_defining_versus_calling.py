def show_title():                     # title function used more than once
    print("=== MONSTER ARENA ===")
show_title()
