command = input("Enter a command: ").strip().lower()
words = command.split()           # separate command words
# Only read words[1] if the command has at least two words.
if len(words) >= 2:               # verb plus target?
    action = words[0]             # first word is the verb
    target = words[1]             # second word is the object
    print(f"Action: {action}")
    print(f"Target: {target}")
else:
    print("Try a two-word command, like open door.")
