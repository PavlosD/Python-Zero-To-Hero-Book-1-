player_gold = 10
print(player_gold)
player_gold = 25      # wallet now holds 25 gold
print(player_gold)
