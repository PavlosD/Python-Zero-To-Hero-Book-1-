canvas = tk.Canvas(                                # the playing board itself
    root,                          # board belongs to window
    width=CANVAS_WIDTH,
    height=CANVAS_HEIGHT,
    bg=PANEL,
    highlightthickness=2,          # visible board frame
    highlightbackground=TEXT       # frame uses text colour
)
canvas.pack(pady=12)               # board sits below score
