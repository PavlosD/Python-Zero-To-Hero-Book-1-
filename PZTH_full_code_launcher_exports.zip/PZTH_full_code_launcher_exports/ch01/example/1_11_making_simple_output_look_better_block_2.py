print("=== START ===")            # title before the spacing
print("")                         # blank line between title and scene
print("The adventure begins.")
