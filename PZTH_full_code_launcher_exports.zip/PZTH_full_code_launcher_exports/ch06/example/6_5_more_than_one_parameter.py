def show_stats(name, health):    # two facts, one line
    print(f"{name} has {health} health.")
show_stats("Nora", 100)
show_stats("Drake", 85)
