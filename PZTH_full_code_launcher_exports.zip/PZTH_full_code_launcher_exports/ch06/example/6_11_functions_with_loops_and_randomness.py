import random                      # random tools for roll_die()
def roll_die():                    # roll one six-sided die
    return random.randint(1, 6)    # return a new die roll
roll = roll_die()                  # save the returned die roll
print(f"You rolled {roll}.")       # report the roll
