parts = ["take", "silver", "key"]    # a pre-split command
sentence = " ".join(parts)           # space as glue
print(sentence)                      # take silver key
