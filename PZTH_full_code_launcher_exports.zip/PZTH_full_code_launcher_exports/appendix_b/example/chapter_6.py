def cheer():             # define cheer before calling it
    print("Victory!")

cheer()
