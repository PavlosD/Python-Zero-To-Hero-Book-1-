def greet_player(name):           # one parameter receives each name
    print(f"Welcome, {name}!")    # format the current argument
greet_player("Rin")
greet_player("Theo")
