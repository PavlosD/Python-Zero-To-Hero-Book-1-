import random                            # pick one enemy from the list
enemies = ["shade", "shade", "drake"]    # two shades make them more likely
enemy = random.choice(enemies)           # one name drawn from the list
print(enemy)
