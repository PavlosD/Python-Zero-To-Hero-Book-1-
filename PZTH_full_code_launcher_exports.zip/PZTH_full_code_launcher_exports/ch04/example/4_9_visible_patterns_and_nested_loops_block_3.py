for round_number in range(1, 3):      # two game rounds
    print(f"Round {round_number}")
    for jump in range(1, 4):          # three jumps inside each round
        print(f" Jump {jump}")
