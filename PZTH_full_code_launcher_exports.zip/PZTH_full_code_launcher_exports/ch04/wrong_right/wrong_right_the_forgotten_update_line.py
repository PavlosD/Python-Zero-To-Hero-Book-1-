# WRONG VERSION - commented out so the launcher can run safely
# count = 1
# while count <= 5:
#     print(count)  # prints 1 forever
# # count never changes, so the condition stays true

# RIGHT VERSION
count = 1
while count <= 5:
    print(count)
    count = count + 1  # count advances toward the stop value
