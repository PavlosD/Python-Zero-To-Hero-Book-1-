board[row][col] = current_player    # update hidden board before win check
buttons[row][col].config(text=current_player, state="disabled")
