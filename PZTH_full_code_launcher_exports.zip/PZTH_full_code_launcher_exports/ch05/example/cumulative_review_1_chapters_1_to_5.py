print("=== ARENA ===")
