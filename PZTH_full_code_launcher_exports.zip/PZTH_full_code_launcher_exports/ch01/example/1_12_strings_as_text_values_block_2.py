print("Mage")
print('Rogue')    # single quotes work too
