board = [
    [".", ".", "P", "."],
    [".", "#", ".", "."],
    ["T", ".", ".", "."]
]
print(board[0][2])    # row 0, column 2 cell
print(board[2][0])    # bottom-left cell
