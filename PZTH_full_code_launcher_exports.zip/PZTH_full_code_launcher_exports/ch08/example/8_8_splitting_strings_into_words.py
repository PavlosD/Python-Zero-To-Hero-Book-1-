command = "take key"       # two-word command sample
words = command.split()    # separate action and target
print(words)
