# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: the list is reset every loop pass.
# for slot in range(3):
#     backpack = []
#     backpack.append("potion")

# RIGHT VERSION
# CORRECT: create the list before the loop.
backpack = []
for slot in range(3):
    backpack.append("potion")
print(backpack)
