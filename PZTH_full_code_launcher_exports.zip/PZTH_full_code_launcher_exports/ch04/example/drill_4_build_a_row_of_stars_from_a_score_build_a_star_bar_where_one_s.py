score = 7
bar = ""                  # empty score bar
for i in range(score):    # one pass per point
    bar = bar + "*"       # grow the bar one star
print(bar)                # completed score bar
