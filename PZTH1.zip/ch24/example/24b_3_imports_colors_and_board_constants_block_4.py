UNKNOWN = "?"                # square not fired
MISS = "o"                   # shot with no ship
HIT = "X"                    # shot that found a ship
SHIP = "S"                   # hidden or visible ship
SEA = "~"                    # empty sea cell
SHIP_SIZES = [4, 3, 3, 2]    # four ships: 4, 3, 3, 2
LETTERS = "ABCDEFGH"         # column labels
