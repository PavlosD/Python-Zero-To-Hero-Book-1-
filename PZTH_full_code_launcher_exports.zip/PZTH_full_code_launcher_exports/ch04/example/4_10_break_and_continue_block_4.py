for reward_slot in range(1, 6):    # inspect five reward slots
    reward = int(input(f"Reward for slot {reward_slot}: "))
    if reward == 0:                # empty slot this spin
        continue                   # ignore an empty reward slot
    print("Reward:", reward)
