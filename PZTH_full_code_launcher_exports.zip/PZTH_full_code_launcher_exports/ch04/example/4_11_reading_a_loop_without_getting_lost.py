total_damage = 0                          # damage from completed turns
for turn in range(1, 4):                  # ask for three turn values
    damage = int(input(f"Damage on turn {turn}: "))
    total_damage = total_damage + damage
print(f"Total damage: {total_damage}")    # damage across all three turns
