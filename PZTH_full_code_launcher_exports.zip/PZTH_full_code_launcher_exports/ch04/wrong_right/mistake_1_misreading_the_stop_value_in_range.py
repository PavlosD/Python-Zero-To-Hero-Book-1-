# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: this prints 1, 2, 3, 4
# for i in range(1, 5):
#     print(i)

# RIGHT VERSION
# CORRECT: this prints 1, 2, 3, 4, 5
for i in range(1, 6):  # five rows, because 6 is excluded
    print(i)
