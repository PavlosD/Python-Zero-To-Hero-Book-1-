inventory = ["potion", "shield", "rope", "key", "torch"]
print(inventory[0:2])    # first two items
print(inventory[2:4])    # middle two items
print(inventory[2:])     # from index 2 to the end
print(inventory[:3])     # first three items
print(inventory[-2:])
print(inventory[:])
