weapons = ["dagger", "bow", "staff"]    # three weapon strings
print(weapons)
