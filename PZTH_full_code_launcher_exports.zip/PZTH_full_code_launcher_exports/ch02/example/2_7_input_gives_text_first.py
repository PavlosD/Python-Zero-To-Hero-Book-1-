player_age = input("Enter your age: ")    # age arrives as text until converted
print(player_age)
