inventory = ["potion", "shield", "key"]    # the same three items
print("=== INVENTORY ===")
for item in inventory:                     # walk the bag again
    print(f"- {item}")
