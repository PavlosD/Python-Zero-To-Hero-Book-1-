score = 0
score = score + 10    # standard form
score += 10           # shortcut: same meaning
print(score)          # 20
