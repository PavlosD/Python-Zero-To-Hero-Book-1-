def update_objects():                      # move and remove off-screen objects
    for package in packages[:]:            # copy allows removal during the loop
        package["y"] += package["speed"]
        if package["y"] > HEIGHT + 30:     # package has fallen below the screen
            packages.remove(package)

    for asteroid in asteroids[:]:          # copy allows removal during the loop
        asteroid["y"] += asteroid["speed"]
        if asteroid["y"] > HEIGHT + 42:    # asteroid has left the arena
            asteroids.remove(asteroid)
