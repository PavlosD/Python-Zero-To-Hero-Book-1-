stars = []                     # background stars, not gameplay objects
packages = []                  # square delivery packages
asteroids = []                 # round hazards
frame_job = None              # ID of the one scheduled frame
portal = {"x": WIDTH // 2, "y": 126, "w": 74, "h": 74}
