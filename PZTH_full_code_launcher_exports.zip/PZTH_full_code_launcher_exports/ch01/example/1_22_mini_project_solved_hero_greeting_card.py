print("================================")
print("       HERO GREETING CARD       ")
print("================================")

print("")                                # blank line after the card heading

print("Welcome, brave traveler.")        # greet the new player
print("Your path begins at the edge of the Whispering Woods.")
print("A silver trail glows beneath the moonlight.")
