has_key = False
if not has_key:                         # key is not carried
    print("You still need the key.")
