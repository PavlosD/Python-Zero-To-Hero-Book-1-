weapons = ["dagger", "bow", "staff"]    # weapon list for index practice
print(weapons[1])                       # second weapon
