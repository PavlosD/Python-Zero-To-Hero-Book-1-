print(f"| {'Knight':<10} |")
print(f"| {'Wizard':<10} |")
print(f"| {'Archer':<10} |")
