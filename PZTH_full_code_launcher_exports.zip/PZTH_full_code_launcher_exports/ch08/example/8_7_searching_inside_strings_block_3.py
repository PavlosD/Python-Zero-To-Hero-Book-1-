message = "The old gate opens."    # original text stays unchanged
new_message = message.replace("old", "ancient")
print(new_message)                 # changed copy, original preserved
