health = 15
if health <= 20:                     # low-health warning threshold
    print("Warning: low health!")
