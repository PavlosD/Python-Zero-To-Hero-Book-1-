import random                      # roll five dice and keep the highest
best_roll = 0                      # below every possible die result
for i in range(5):                 # five attempts
    roll = random.randint(1, 6)    # one new die result
    print("Roll:", roll)
    if roll > best_roll:           # only a higher roll replaces the record
        best_roll = roll
print("Best roll:", best_roll)     # best result after all five attempts
