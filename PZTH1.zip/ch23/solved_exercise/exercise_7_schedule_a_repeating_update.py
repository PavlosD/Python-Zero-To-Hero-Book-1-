import tkinter as tk

window = tk.Tk()
count = 0
label = tk.Label(window, text="Frame: 0")
label.pack(padx=30, pady=30)

def update():                    # one HUD refresh
    global count                   # reuse the shared frame counter
    count += 1                     # one more frame shown
    label.config(text="Frame: " + str(count))
    window.after(500, update)    # queue the next HUD refresh
