gold_found = int(input("Enter gold found: "))
gem_value = int(input("Enter gem value: "))
total_loot = gold_found + gem_value         # sum the haul
print("=== LOOT SUMMARY ===")               # summary title
print(f"Total loot value: {total_loot}")
