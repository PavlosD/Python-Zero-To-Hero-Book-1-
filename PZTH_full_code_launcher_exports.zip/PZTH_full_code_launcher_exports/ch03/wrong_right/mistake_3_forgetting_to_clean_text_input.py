# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: Open and open are treated differently
# command = input("Enter command: ")
# if command == "open":
#     print("The chest opens.")

# RIGHT VERSION
# CORRECT: clean spaces and capitalization
command = input("Enter command: ").strip().lower()
if command == "open":
    print("The chest opens.")
