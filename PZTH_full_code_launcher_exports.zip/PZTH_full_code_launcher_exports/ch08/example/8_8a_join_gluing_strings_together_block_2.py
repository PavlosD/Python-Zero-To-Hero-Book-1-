letters = ["t", "h", "e"]            # three letters to join
print("".join(letters))
print(", ".join(["a", "b", "c"]))
