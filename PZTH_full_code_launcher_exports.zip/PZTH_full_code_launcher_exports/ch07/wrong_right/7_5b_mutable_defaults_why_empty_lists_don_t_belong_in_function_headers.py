# WRONG VERSION - commented out so the launcher can run safely
# # WRONG - every call shares the same default
# def remember(item, log=[]):
#     log.append(item)
#     return log
#
# print(remember("sword"))
# print(remember("shield"))

# RIGHT VERSION
# CORRECT - create the fresh list inside
def remember(item, log=None):
    if log is None:
        log = []
    log.append(item)
    return log
