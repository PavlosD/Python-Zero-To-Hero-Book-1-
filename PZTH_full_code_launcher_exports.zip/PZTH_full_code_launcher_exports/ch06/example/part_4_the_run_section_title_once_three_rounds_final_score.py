# start the three-round reward total
score = 0
show_title()                             # show the title once

for round_number in range(1, 4):         # run three rounds
    print(f"Round {round_number}")
    monster = choose_monster_name()      # pick this boss
    draw_monster_card(monster)           # draw the boss card
    reward = roll_reward()               # roll the round reward
    score = score + reward               # add reward to score
    print(f"Reward earned: {reward}")
    print()                              # leave space after each boss round
