command = input("Command: ").strip().lower()
