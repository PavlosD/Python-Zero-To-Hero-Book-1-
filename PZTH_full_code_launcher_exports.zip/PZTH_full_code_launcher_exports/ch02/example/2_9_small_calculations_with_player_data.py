player_gold = 20
quest_reward = 15     # gold for the quest
player_gold = player_gold + quest_reward
print(player_gold)    # wallet after reward
