# define the function first
def show_title():                   # game-banner function
    print("=== STAR HUNTER ===")

# show the banner once
show_title()
