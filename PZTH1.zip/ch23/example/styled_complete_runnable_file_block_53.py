def start_game():                        # Enter starts or retries
    if state["screen"] in ("title", "game_over", "won"):
        reset_game()                      # restore the first-route state
        if frame_job is None:
            update_game()                 # begin the single frame chain
