import random
score = 0
reward = random.randint(5, 15)    # this reward is worth 5 to 15 points
score = score + reward            # bank the reward
print("Reward:", reward)
print("Score:", score)            # final tally
