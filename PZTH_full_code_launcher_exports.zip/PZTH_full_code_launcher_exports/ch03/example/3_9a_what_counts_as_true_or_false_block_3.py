name = "Pavlos"                  # a non-empty sample name
if name:                         # non-empty name?
    print("greet the player")    # any non-empty string counts
