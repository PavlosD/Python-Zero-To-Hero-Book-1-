# WRONG VERSION - commented out so the launcher can run safely
# command = "look"
# words = command.split()
# # WRONG: there is no second word
# # target = words[1]

# RIGHT VERSION
command = "look"
words = command.split()
# CORRECT: check the list length first
if len(words) >= 2:
    target = words[1]
    print(target)
else:
    print("No target word was given.")
