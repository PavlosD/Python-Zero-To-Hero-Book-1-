import random

roll_1 = random.randint(1, 4)    # first reel result
roll_2 = random.randint(1, 4)    # second reel result
roll_3 = random.randint(1, 4)    # third reel result
