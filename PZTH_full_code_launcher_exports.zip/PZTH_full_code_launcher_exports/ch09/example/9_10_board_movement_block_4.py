board[new_row][new_col] = "P"          # place player on the new cell
print(board)
