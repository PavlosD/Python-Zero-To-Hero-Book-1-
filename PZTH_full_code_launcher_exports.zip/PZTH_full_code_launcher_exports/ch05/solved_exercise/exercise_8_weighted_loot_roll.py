import random                          # roll a percentile loot tier
roll = random.randint(1, 100)          # percent-style loot roll
if roll <= 70:                         # common-loot range
    print("Common: copper coin.")
elif roll <= 95:                       # rare-loot range
    print("Rare: silver coin.")
else:
    print("Legendary: gold crown.")    # top-tier loot
