player_name = "Iris"             # four-letter name for index practice
first_letter = player_name[0]    # index 0 of the string
print(first_letter)
