import random                       # pick a card rank
card_roll = random.randint(1, 4)    # choose one of four card ranks
if card_roll == 1:
    card = "A"                      # ace on a roll of 1
elif card_roll == 2:
    card = "K"                      # king on a roll of 2
elif card_roll == 3:
    card = "Q"                      # queen on a roll of 3
else:
    card = "J"                      # jack on a roll of 4
print("Card drawn:", card)
