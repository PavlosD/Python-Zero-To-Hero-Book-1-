from pathlib import Path           # build asset paths beside the script

BASE_DIR = Path(__file__).resolve().parent
ASSET_DIR = BASE_DIR / "assets"    # asset folder sits next to the script
