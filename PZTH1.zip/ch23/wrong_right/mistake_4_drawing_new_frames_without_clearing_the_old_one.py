# WRONG VERSION - commented out so the launcher can run safely
# def draw_game():
#     draw_player()
#     draw_asteroids()

# RIGHT VERSION
def draw_game():
    canvas.delete("all")
    draw_player()
    draw_asteroids()
