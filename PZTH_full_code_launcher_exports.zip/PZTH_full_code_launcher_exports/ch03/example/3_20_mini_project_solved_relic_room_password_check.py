# Clean both inputs before comparison.
password = input("Speak the relic password: ").strip().lower()
player_rank = input("Enter your rank: ").strip().lower()

is_password_correct = password == "ember"
has_guardian_rank = player_rank == "guardian"
has_full_access = is_password_correct and has_guardian_rank
