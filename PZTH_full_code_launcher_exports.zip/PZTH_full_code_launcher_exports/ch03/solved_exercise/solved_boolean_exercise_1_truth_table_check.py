print(True and True)     # both true -> True
print(True and False)    # one is false -> False
print(False or True)     # one is true -> True
print(False or False)    # all false -> False
print(not True)          # not True -> False
print(not False)         # not False -> True
