message_label = tk.Label(                    # crash / win feedback
    root,                          # feedback stays under board
    text="",                       # reset_game() fills
    font=("Arial", 11, "bold"),
    bg=BG,
    fg=TEXT,
    wraplength=460
)
message_label.pack(pady=4)         # separate board and button
