player = {                                     # ship collision geometry
    "x": WIDTH // 2,                 # start centered
    "y": HEIGHT - 78,               # near the floor
    "w": 34,                                 # hull width in px
    "h": 32,                                 # hull height in px
}
