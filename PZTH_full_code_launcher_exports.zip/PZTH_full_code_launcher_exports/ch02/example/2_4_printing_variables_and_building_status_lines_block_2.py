player_name = "Rin"              # name reused in the status lines below
player_score = 120
print("Player:", player_name)    # name with a label
print("Score:", player_score)    # label plus the number
