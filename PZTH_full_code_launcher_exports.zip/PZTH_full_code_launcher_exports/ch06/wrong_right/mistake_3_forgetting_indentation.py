# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: the print line must be indented.
# # def cheer():
# # print("Victory!")

# RIGHT VERSION
# CORRECT: the function body is indented.
def cheer():  # helper reused for win messages
    print("Victory!")
cheer()  # call after the definition
