gold = 8
if gold >= 10:                    # potion is affordable
    print("Potion purchased.")
else:
    print("Not enough gold.")
