def spawn_food():                          # find a food cell outside the snake
    global food                            # replace active food target

    open_cells = []                        # cells not occupied by snake

    for x in range(GRID_WIDTH):            # walk across the board
        for y in range(GRID_HEIGHT):       # walk down the board
            if (x, y) not in snake:        # snake body cannot hold food
                open_cells.append((x, y))      # a legal food spot
