import random    # load Python's random tools
