# WRONG VERSION - commented out so the launcher can run safely
# def rank(score):
#     if score >= 50:
#         return "Boss"          # function ends here
#         print("High score!")   # unreachable after return
#     return "Apprentice"

# RIGHT VERSION
def rank(score):
    if score >= 50:
        print("High score!")  # prints before return
        return "Boss"
    return "Apprentice"
