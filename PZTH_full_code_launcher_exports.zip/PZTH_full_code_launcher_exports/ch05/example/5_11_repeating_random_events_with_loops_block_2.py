import random                         # roll points across five rounds
score = 0
for round_number in range(1, 6):      # play five reward rounds
    points = random.randint(5, 15)    # this round pays 5 to 15
    score = score + points            # bank the reward
    print(f"Round {round_number}: +{points} points")
    print(f"Total: {score}")          # score after this round
