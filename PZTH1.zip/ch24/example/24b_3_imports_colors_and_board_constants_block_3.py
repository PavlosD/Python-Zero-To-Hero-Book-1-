GRID_SIZE = 8                # 8 by 8 board
CELL = 34                    # pixel size of one cell
ENEMY_X = 54                 # enemy board left edge
PLAYER_X = 430               # player board left edge
BOARD_Y = 76                 # top edge for both boards
CANVAS_W = 760               # two boards plus gap
CANVAS_H = 430               # boards, labels, overlay
COMPUTER_DELAY = 600         # pause before computer fires
