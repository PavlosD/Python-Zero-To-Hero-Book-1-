raw_name = input("Hero name: ")     # uncleaned name from the player
name = raw_name.strip().title()
print(f"=== {name.upper()} ===")    # uppercase name in the banner
print(f"Welcome, {name}.")          # title-cased name in the greeting
