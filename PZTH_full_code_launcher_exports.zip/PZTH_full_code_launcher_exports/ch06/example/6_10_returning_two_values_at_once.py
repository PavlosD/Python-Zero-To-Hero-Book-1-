def collect_coin(score, coins):    # apply one coin pickup to both totals
    score = score + 10             # one coin is worth 10 points
    coins = coins + 1              # one more coin in the bag
    return score, coins            # return both updated values together

new_score, new_coins = collect_coin(50, 3)
print(new_score)                   # 60
print(new_coins)                   # 4
