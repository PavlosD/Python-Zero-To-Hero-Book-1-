score = 80     # current player score
if score >= 50:
    rank = "Pass"
else:
    rank = "Try again"
print(rank)
