if roll_2 == 1:
    reel_2 = "cherry"
elif roll_2 == 2:
    reel_2 = "lemon"
elif roll_2 == 3:
    reel_2 = "star"
else:
    reel_2 = "bell"
