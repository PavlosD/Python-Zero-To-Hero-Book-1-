def object_box(item):          # collision box for a package or asteroid
    # Packages and asteroids both use a center point plus a size.
    half = item["size"] // 2   # center-to-edge distance
    return (                                        # box corners from half-size
        item["x"] - half,              # left
        item["y"] - half,              # top
        item["x"] + half,              # right
        item["y"] + half,              # bottom
    )

