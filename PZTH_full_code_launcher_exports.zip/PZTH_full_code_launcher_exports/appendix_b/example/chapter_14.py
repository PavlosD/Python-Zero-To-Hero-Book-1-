class Pet:                               # pet whose feed() lowers hunger
    def __init__(self, name, hunger):
        self.name = name                 # store this pet name
        self.hunger = hunger             # starting hunger for this pet
    def feed(self, amount):              # lower hunger, floor at 0
        self.hunger = max(0, self.hunger - amount)
