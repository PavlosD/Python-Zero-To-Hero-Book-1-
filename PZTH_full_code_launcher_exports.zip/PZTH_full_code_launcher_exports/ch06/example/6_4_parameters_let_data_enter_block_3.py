def show_enemy(enemy_name):
    print(f"A wild {enemy_name} appears!")
show_enemy("brigand")
show_enemy("shadow shade")
