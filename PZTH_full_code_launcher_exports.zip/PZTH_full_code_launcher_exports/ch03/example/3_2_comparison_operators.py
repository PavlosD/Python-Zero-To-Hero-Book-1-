gold = 25
print(gold == 25)    # True: exact match
print(gold != 25)    # False: they are equal
print(gold >= 20)    # True: 25 is at least 20
