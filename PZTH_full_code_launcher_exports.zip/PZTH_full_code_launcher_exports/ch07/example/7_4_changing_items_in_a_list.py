inventory = ["potion", "shield", "key"]    # starting bag before replacement
inventory[1] = "magic shield"              # replace second item
print(inventory)                           # list, brackets and all
