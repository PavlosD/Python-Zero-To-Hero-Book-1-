print("=== SKY FORTRESS ===")
print("")                        # blank line between title and scene
print("Clouds move around the ancient tower.")
