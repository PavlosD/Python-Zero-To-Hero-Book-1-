password = ""                  # password starts blank
while password != "dragon":
    password = input("Enter the password: ").strip().lower()
print("Access granted.")
