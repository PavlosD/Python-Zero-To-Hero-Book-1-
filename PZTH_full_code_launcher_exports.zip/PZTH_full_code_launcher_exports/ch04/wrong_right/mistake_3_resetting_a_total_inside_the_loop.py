# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: total resets every round
# for round_number in range(1, 4):  # resets the total
#     total = 0
#     points = 10
#     total = total + points

# RIGHT VERSION
# CORRECT: total starts before the loop
total = 0
for round_number in range(1, 4):  # all rounds share total
    points = 10
    total = total + points
