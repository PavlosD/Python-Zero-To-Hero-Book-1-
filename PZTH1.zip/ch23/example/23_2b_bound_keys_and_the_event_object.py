import tkinter as tk

window = tk.Tk()
window.title("key demo")
label = tk.Label(window, text="press a key", font=("Arial", 20))
label.pack(padx=40, pady=40)

def on_key(event):                   # read one pressed key
    label.config(text=f"keysym: {event.keysym}")
