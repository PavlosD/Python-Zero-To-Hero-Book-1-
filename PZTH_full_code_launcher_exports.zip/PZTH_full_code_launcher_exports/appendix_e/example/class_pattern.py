class Hero:                      # smallest useful Hero blueprint
    def __init__(self, name):
        self.name = name         # Hero name available through the object
