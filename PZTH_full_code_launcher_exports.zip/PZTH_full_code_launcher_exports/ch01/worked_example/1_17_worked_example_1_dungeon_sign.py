print("=== DUNGEON SIGN ===")            # print the title before the warning
print("The old gate creaks open.")
print("A warning is carved into the stone.")
print("Only the brave should enter.")
