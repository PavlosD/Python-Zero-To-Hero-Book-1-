inventory = ["potion", "shield", "key"]    # items whose indexes will be printed
for i in range(len(inventory)):
    print(f"Slot {i}: {inventory[i]}")
