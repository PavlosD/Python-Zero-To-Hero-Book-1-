board = [[".", ".", "T"], ["P", ".", "."]]
print(board[0][2])    # read treasure from grid
