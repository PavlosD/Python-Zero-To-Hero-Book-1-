print("=== ARENA OF ECHOES ===")
print("")                           # blank line after the title
print("Welcome, challenger.")       # speak directly to the player
print("Tonight you face the arena for the first time.")
print("--------------------")       # divider before the closing line
print("Survive, and your name will be remembered.")
