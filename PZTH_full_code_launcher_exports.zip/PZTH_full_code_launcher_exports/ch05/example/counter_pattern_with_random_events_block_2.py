roll = 4                      # a forced four
