for i in range(4):
    print("Collect the coins!")
