hero_class = "Wizard"            # class name stored as text
location_name = "Shadow Cave"    # name shown for the current location
