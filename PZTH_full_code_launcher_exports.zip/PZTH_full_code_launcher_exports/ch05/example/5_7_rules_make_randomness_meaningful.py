import random                     # roll for attack quality
roll = random.randint(1, 6)       # one six-sided die result
print("You rolled", roll)
if roll == 6:                     # highest possible roll
    print("Critical success!")
elif roll >= 4:                   # rolls 4 and 5 are solid hits
    print("Good result.")
else:                             # rolls 1 to 3 are weak
    print("Weak result.")
