heroes = ["Knight", "Wizard", "Archer"]    # three hero names for the loop
for hero in heroes:                        # one hero at a time
    print(hero)
