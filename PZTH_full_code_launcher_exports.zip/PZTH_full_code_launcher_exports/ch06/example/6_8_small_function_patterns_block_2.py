def shout(word):         # add an exclamation mark to one battle cry
    print(word + "!")
shout("Charge")          # shout the battle cry
