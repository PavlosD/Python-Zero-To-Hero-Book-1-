name = "Rin"    # name for the welcome
