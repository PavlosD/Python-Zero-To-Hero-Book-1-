word = "dragon"    # the word players must guess
# index positions:
# d r a g o n
print(word[0])     # first letter
print(word[1])     # second letter
print(word[5])     # sixth letter
