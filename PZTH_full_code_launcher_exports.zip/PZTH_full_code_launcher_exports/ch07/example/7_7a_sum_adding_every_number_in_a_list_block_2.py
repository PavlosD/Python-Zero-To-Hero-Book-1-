scores = [60, 90, 75, 80]              # four scores to scan
average = sum(scores) / len(scores)    # mean of the scores
print(average)                         # 76.25
