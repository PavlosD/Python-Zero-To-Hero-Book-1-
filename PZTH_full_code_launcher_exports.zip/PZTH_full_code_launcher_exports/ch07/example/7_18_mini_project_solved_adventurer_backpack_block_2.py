print("=== BACKPACK CONTENTS ===")
for item in backpack:                      # display backpack contents in order
    print(f"- {item}")                     # one visible row for this item
print(f"Total items: {len(backpack)}")     # how many slots used

potion_count = backpack.count("potion")    # count duplicate potions
print(f"Potion count: {potion_count}")
if "key" in backpack:                      # gate-opener present?
    print("You are ready to unlock hidden gates.")
else:                                      # no key in the bag
    print("You may want to find a key before entering.")
