snake = [(5, 10), (4, 10), (3, 10)]    # snake body cells

import random           # choose an open food cell
import tkinter as tk    # GUI toolkit for Snake

BG = "#0f1226"          # dark frame around the board
PANEL = "#1b1f3a"       # empty board tile
GRID = "#252a48"        # thin seams between tiles
TEXT = "#e8eaf6"        # light text on dark panels
ACCENT = "#7c83ff"      # snake body
HEAD = "#27c66b"        # head, brighter than body
FOOD = "#ffd166"       # food dot colour
DANGER = "#ff5d6c"      # crash + game-over text

CELL_SIZE = 20                             # one snake square is 20 px
GRID_WIDTH = 20                            # horizontal cell count
GRID_HEIGHT = 20                           # vertical cell count
MOVE_DELAY = 120                           # milliseconds per snake step

CANVAS_WIDTH = CELL_SIZE * GRID_WIDTH      # 20 cells across, in pixels
CANVAS_HEIGHT = CELL_SIZE * GRID_HEIGHT    # 20 cells down, in pixels

snake = []                  # body cells, head is index 0
direction = "Right"         # direction used this tick
next_direction = "Right"    # queued legal direction
food = None                 # one food cell, (x, y)
score = 0                   # foods eaten this round
game_running = False        # Snake is not moving yet
move_job = None             # callback ID for the next move

# convert grid coordinates into canvas coordinates
def grid_to_pixels(x, y):              # cell coords to pixel box
    left = x * CELL_SIZE               # left edge of snake tile
    top = y * CELL_SIZE                # top edge of snake tile
    right = left + CELL_SIZE           # right edge of snake tile
    bottom = top + CELL_SIZE           # cell bottom edge
    return left, top, right, bottom    # canvas rectangle edges

def draw_cell(x, y, colour):           # draw one snake tile
    left, top, right, bottom = grid_to_pixels(x, y)
    canvas.create_rectangle(                      # one solid tile
        left, top, right, bottom,      # fill this grid square
        fill=colour,
        outline=BG                     # dark seam between tiles
    )

def spawn_food():                          # find a food cell outside the snake
    global food                            # replace active food target

    open_cells = []                        # cells not occupied by snake

    for x in range(GRID_WIDTH):            # walk across the board
        for y in range(GRID_HEIGHT):       # walk down the board
            if (x, y) not in snake:        # snake body cannot hold food
                open_cells.append((x, y))      # a legal food spot

    if not open_cells:                     # snake filled the board
        food = None                        # no food can be placed
        return                             # move_snake() handles win

    food = random.choice(open_cells)       # pick one unoccupied food cell

# Rebuild the visible board from the stored Snake state.
def draw_game():                        # one complete Snake frame
    canvas.delete("all")                # discard the previous frame

    for x in range(GRID_WIDTH):         # columns from left to right
        for y in range(GRID_HEIGHT):    # rows from top to bottom
            left, top, right, bottom = grid_to_pixels(x, y)
            canvas.create_rectangle(
                left, top, right, bottom,      # one empty board cell
                fill=PANEL,
                outline=GRID
            )

    if food is not None:  # food may be absent after a board-fill win
        x, y = food
        left, top, right, bottom = grid_to_pixels(x, y)
        canvas.create_oval(
            left + 4, top + 4,          # inset the dot inside its cell
            right - 4, bottom - 4,
            fill=FOOD,
            outline=TEXT,
            width=2
        )

    for index, (x, y) in enumerate(snake):      # index 0 identifies the head
        if index == 0:
            draw_cell(x, y, HEAD)
        else:
            draw_cell(x, y, ACCENT)

def reset_game():                          # restart with one callback chain
    global snake, direction, next_direction
    global food, score, game_running, move_job

    if move_job is not None:               # the old run still has a queued tick
        root.after_cancel(move_job)         # prevent two movement loops
        move_job = None                    # no callback is queued now

    snake = [(5, 10), (4, 10), (3, 10)]    # three-cell body facing right
    direction = "Right"                    # current movement direction
    next_direction = "Right"               # no turn is queued yet
    score = 0                              # new round starts with no food eaten
    game_running = True                    # movement callbacks may run again

    score_label.config(text="Score: 0")
    message_label.config(
        text="Eat dots. Avoid walls and your own body."
    )

    spawn_food()                           # place the first legal target
    draw_game()                            # redraw the reset board
    schedule_next_move()                   # start exactly one movement chain

def change_direction(new_direction):    # queue a keyboard turn
    global next_direction               # queue a turn for the next tick

    blocked_turns = {                   # reverse turns are illegal
        "Up": "Down",                   # up cannot snap downward
        "Down": "Up",                   # down cannot snap upward
        "Left": "Right",                # left cannot snap right
        "Right": "Left"                 # right cannot snap left
    }

    if blocked_turns[direction] == new_direction:
        return                          # ignore unsafe reversal

    next_direction = new_direction      # keep this legal turn for the next tick

def schedule_next_move():                # queue one Snake tick
    global move_job                      # reuse the shared callback ID
    move_job = root.after(MOVE_DELAY, move_snake)

def move_snake():                        # move the snake once
    global direction, score, move_job    # these change during a tick

    move_job = None                      # fired callback is no longer queued

    if not game_running:                 # frozen or finished round
        return                           # do not move a frozen snake

    direction = next_direction           # apply latest legal turn
    head_x, head_y = snake[0]            # current head cell

    if direction == "Up":                # target cell is above
        head_y -= 1                      # move one row upward
    elif direction == "Down":            # target cell is below
        head_y += 1                      # move one row downward
    elif direction == "Left":            # target cell is left
        head_x -= 1                      # move one column left

    elif direction == "Right":           # target cell is right
        head_x += 1                      # move one column right

    new_head = (head_x, head_y)          # candidate next head

    hit_left = head_x < 0                 # left of column 0
    hit_right = head_x >= GRID_WIDTH      # past the final column
    hit_top = head_y < 0                  # above row 0
    hit_bottom = head_y >= GRID_HEIGHT    # past the final row

    if hit_left or hit_right or hit_top or hit_bottom:
        end_game("You hit the wall.")
        return                            # wall collision ends this tick

    will_eat_food = new_head == food      # eating keeps the tail in place
    if will_eat_food:
        body_to_check = snake             # growing snake keeps its tail
    else:
        body_to_check = snake[:-1]        # moving tail frees the last cell

    if new_head in body_to_check:         # head enters a body cell that remains
        end_game("You hit yourself.")
        return                            # body collision ends this tick

    snake.insert(0, new_head)             # add the next head position

    if will_eat_food:
        score += 1                        # one point per food
        score_label.config(text=f"Score: {score}")
        spawn_food()

        if food is None:                  # no empty cell remains
            draw_game()
            end_game("You filled the board. You win!", "YOU WIN")
            return                        # full board ends this tick
    else:

        snake.pop()                       # ordinary move removes the old tail

    draw_game()
    schedule_next_move()                  # queue exactly one later tick

def end_game(message, title="GAME OVER"):  # freeze the run and label result
    global game_running                   # block future movement ticks

    game_running = False                  # freeze Snake movement
    message_label.config(text=message)    # display ending reason
    overlay_colour = HEAD if title == "YOU WIN" else DANGER

    canvas.create_text(
        CANVAS_WIDTH // 2,                # middle of board, x
        CANVAS_HEIGHT // 2,               # middle of board, y
        text=title,                       # loss or full-board victory
        fill=overlay_colour,              # green win, red loss

        font=("Arial", 28, "bold")
    )

root = tk.Tk()
root.title("Snake")
root.geometry("520x610")           # fits board and controls
root.resizable(False, False)       # fixed grid stays aligned
root.configure(bg=BG)              # match the dark palette

title_label = tk.Label(                        # headline over the board
    root,                          # put title in main window
    text="Snake",                  # title shown above board
    font=("Arial", 24, "bold"),
    bg=BG,
    fg=TEXT

)
title_label.pack(pady=(16, 4))     # leave room above score

score_label = tk.Label(                        # live score readout
    root,                          # score sits under title
    text="Score: 0",               # score before first food
    font=("Arial", 14, "bold"),
    bg=BG,
    fg=TEXT
)
score_label.pack(pady=4)           # tight score spacing

canvas = tk.Canvas(                                # the playing board itself
    root,                          # board belongs to window
    width=CANVAS_WIDTH,
    height=CANVAS_HEIGHT,
    bg=PANEL,
    highlightthickness=2,          # visible board frame
    highlightbackground=TEXT       # frame uses text colour
)
canvas.pack(pady=12)               # board sits below score

message_label = tk.Label(                    # crash / win feedback
    root,                          # feedback stays under board
    text="",                       # reset_game() fills
    font=("Arial", 11, "bold"),
    bg=BG,
    fg=TEXT,
    wraplength=460
)
message_label.pack(pady=4)         # separate board and button

restart_button = tk.Button(                # Restart button begins a fresh run
    root,                          # button belongs to window
    text="Restart",
    font=("Arial", 12, "bold"),
    command=reset_game,            # Restart rebuilds every Snake field
    bg=ACCENT,
    fg=TEXT,
    activebackground=ACCENT,       # no colour jump on click
    bd=0,
    width=16
)
restart_button.pack(pady=10)       # bottom control spacing

def bind_key(key_name, new_direction):    # connect key to turn
    root.bind(                            # register key on window
        key_name,  # Tkinter key names are case-sensitive
        lambda event: change_direction(new_direction)
    )

bind_key("<Up>", "Up")
bind_key("<Down>", "Down")
bind_key("<Left>", "Left")
bind_key("<Right>", "Right")

bind_key("w", "Up")
bind_key("s", "Down")                     # S also steers down
bind_key("a", "Left")                     # A also steers left
bind_key("d", "Right")                    # D also steers right

reset_game()                              # draw board and queue first tick
root.mainloop()                           # listen for Snake keys and Restart
