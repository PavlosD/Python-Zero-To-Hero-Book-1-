print("Roll:", roll)           # reveal the roll before applying the rule
