score = 0
for hit in range(1, 6):           # land five hits in a row
    score = score + 10            # each hit pays ten points
    print(f"Hit {hit}: score is {score}")
print(f"Final score: {score}")
