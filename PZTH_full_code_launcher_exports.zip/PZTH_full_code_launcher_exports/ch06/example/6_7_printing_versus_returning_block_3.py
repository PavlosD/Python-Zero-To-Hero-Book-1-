def show_damage(base):
    print(base + 3)       # base plus the weapon bonus
def get_damage(base):     # return the calculated damage
    return base + 3
show_damage(5)
damage = get_damage(5)    # damage from this hit
print(damage)
