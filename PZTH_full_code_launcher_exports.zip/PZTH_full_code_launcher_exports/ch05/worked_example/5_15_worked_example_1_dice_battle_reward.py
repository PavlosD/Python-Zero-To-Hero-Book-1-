import random                             # roll for loot quality
roll = random.randint(1, 6)               # a fair six-sided die
print(f"You rolled a {roll}.")            # include the roll in the message
if roll == 6:                             # the lucky face
    print("Critical hit! Bonus loot.")
elif roll >= 4:                           # standard-loot range
    print("Solid swing. Standard loot.")
else:                                     # no-loot range
    print("Glancing blow. No loot.")
