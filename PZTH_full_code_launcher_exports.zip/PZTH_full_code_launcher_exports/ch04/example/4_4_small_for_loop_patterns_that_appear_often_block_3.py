for round_number in range(1, 4):    # three numbered game rounds
    print(f"Round {round_number} begins!")
