# WRONG VERSION - commented out so the launcher can run safely
# def show_stats(name, health):
#     print(name, health)
#
# show_stats(100, "Nora")  # WRONG: 100 lands in name

# RIGHT VERSION
def show_stats(name, health):
    print(name, health)

show_stats("Nora", 100)  # CORRECT: name, then health
