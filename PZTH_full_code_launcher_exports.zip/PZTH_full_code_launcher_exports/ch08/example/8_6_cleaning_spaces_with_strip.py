raw_command = "   open   "             # command with edge spaces
clean_command = raw_command.strip()    # remove edge spaces
print(clean_command)
