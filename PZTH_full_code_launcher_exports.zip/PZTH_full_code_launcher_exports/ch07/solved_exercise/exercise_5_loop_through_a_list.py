inventory = ["potion", "shield", "key"]    # the usual three
for item in inventory:                     # show every item in the pack
    print(item)
