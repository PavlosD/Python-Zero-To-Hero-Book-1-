score = 0                              # running total begins at zero
