title_label = tk.Label(main_frame, text="Fleet Battle",
                       font=("Arial", 24, "bold"), fg=TEXT, bg=BG)
title_label.pack()                          # headline over the boards
subtitle_label = tk.Label(                                    # fleet directions
    main_frame,
    text="Click Enemy Waters. Watch the computer fire at Your Fleet.",
    font=("Arial", 11, "bold"), fg=GRID_LINE, bg=BG)
subtitle_label.pack(pady=(2, 8))            # subtitle under the title
