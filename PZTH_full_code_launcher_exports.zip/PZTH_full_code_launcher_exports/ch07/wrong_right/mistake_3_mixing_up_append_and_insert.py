# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: append() always adds at the end
# inventory = ["potion", "key"]
# inventory.append("shield")
# print(inventory)

# RIGHT VERSION
# CORRECT: insert() places the item at index 1
inventory = ["potion", "key"]
inventory.insert(1, "shield")
print(inventory)
