backpack.sort()                            # sort item names alphabetically
print("=== SORTED BACKPACK ===")           # heading for the sorted view
for item in backpack:                      # walk the sorted bag
    print(f"- {item}")
