def portal_box():              # rings collide as a box
    # The portal is drawn as rings but tested as a rectangle.
    half_w = portal["w"] // 2  # center-to-edge, horizontal
    half_h = portal["h"] // 2  # center-to-edge, vertical
    return (                                        # portal overlap box
        portal["x"] - half_w,      # left
        portal["y"] - half_h,      # top
        portal["x"] + half_w,      # right
        portal["y"] + half_h,      # bottom
    )
