message = "old grey gate"
new_message = message.replace("old", "ancient").replace("grey", "silver")
print(new_message)           # ancient silver gate
