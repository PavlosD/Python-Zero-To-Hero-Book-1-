print("=== FIRE PATH ===")
print("Heat rises from the stones below.")
