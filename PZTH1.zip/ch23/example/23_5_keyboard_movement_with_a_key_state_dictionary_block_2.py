player = {               # courier ship geometry
    "x": WIDTH // 2,     # centered left-to-right
    "y": HEIGHT - 78,    # near the bottom of the arena
    "w": 34,             # 34 px wide
    "h": 32,             # 32 px tall
}
