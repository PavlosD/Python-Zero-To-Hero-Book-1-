def add_points(points):       # return the new total
    return points + 10
new_score = add_points(25)    # 25 points become 35
print(new_score)
