import random                         # pick one of three loot drops
reward_roll = random.randint(1, 3)    # choose one of three rewards
if reward_roll == 1:                  # gem reward
    reward = "gem"                    # rare drop
elif reward_roll == 2:                # potion reward
    reward = "potion"                 # healing drop
else:
    reward = "shield"                 # the fallback drop
print(reward)
