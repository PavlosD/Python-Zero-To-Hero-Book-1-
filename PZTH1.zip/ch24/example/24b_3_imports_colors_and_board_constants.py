import random                # place both fleets and choose computer shots
import tkinter as tk         # GUI toolkit for both boards

BG = "#101820"               # dark window frame
PANEL = "#172a3a"            # canvas sea background
WATER = "#244b67"            # unknown water square
SHIP_FILL = "#6c757d"        # your visible ship cells
GRID_LINE = "#d8f3dc"        # board lines and labels
TEXT = "#f2f2f2"             # light text on dark panels
ACCENT = "#7c83ff"           # restart button colour
HIT_COLOUR = "#ff5d6c"       # hit marker colour
MISS_COLOUR = "#d8f3dc"      # miss dot colour
