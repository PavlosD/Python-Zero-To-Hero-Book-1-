hero_name = "iris"          # lowercase, on purpose
print(hero_name.upper())    # uppercase copy for a nameplate
