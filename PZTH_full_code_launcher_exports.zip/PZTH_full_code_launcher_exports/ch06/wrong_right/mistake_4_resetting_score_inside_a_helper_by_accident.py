# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: this ignores the score passed in
# def add_reward(score, reward):
#     score = 0  # wipes the score passed into the helper
#     return score + reward  # the old points are lost

# RIGHT VERSION
# CORRECT: use the score value that was passed
def add_reward_fixed(score, reward):
    return score + reward  # keep the points
score = add_reward_fixed(21, 5)  # 21 + 5
print(score)  # 26
