# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: score is text, not an integer
# score = input("Enter score: ")
# # if score >= 93:
# # print("Victory")

# RIGHT VERSION
# CORRECT: convert the typed answer first
score = int(input("Enter score: "))
if score >= 93:
    print("Victory")
