inventory = []          # empty exercise bag
collected_stars = []    # empty collections ready to fill
