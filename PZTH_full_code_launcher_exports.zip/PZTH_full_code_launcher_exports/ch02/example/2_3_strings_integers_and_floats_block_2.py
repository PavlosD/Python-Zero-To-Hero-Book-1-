player_lives = 3      # mistakes still allowed
player_score = 120
