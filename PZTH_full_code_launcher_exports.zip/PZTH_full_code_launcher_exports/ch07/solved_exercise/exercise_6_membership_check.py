phrases = ["greetings", "azure", "tower"]
if "azure" in phrases:           # required phrase present?
    print("Gate opens.")
else:
    print("Gate stays shut.")    # required phrase missing
