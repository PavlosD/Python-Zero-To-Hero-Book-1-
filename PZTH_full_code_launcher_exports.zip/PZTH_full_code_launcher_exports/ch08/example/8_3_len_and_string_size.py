password = "ember"        # the secret to unlock
length = len(password)    # count the characters
print(length)             # password length
