# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: count never changes, so the loop can run forever
# # count = 1
# # while count <= 5:
# # print(count)

# RIGHT VERSION
# CORRECT: count increases each time
count = 1
while count <= 5:
    print(count)
    count = count + 1
