import tkinter as tk
window = tk.Tk()
tk.Label(window, text="Hello").pack()    # place greeting label
window.mainloop()                        # run the greeting window's event loop
