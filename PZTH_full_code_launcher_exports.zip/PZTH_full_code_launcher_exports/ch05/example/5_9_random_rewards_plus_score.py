import random                          # vary the coins found
score = 0
coins_found = random.randint(5, 20)    # chest contains 5 to 20 coins
score = score + coins_found            # bank the found coins
print("You found", coins_found, "coins.")
print("Score:", score)                 # total after adding this find
