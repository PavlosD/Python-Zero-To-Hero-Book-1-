def show_divider():                  # divider reused between report sections
    print("====================")
def show_welcome(name):              # greet one player
    print(f"Welcome, {name}!")
show_divider()
show_welcome("Juno")
show_divider()
