def show_title():             # opening screen
    print("=== ARENA ===")

show_title()
