coins = 10
if coins >= 10:                         # enough coins for the potion
    print("You can buy the potion.")
