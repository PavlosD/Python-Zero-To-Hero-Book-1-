from tkinter import ttk
button = ttk.Button(window, text="Start", command=start_game)
