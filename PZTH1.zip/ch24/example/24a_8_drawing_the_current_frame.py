# Rebuild the visible board from the stored Snake state.
def draw_game():                        # one complete Snake frame
    canvas.delete("all")                # discard the previous frame

    for x in range(GRID_WIDTH):         # columns from left to right
        for y in range(GRID_HEIGHT):    # rows from top to bottom
            left, top, right, bottom = grid_to_pixels(x, y)
            canvas.create_rectangle(
                left, top, right, bottom,      # one empty board cell
                fill=PANEL,
                outline=GRID
            )
