item = items.get(item_id) or enemies.get(item_id)
if item is None:             # item ID was not found
    print("Unknown item")    # safe fallback message
