def draw_game():                           # one full frame, in order
    # Rebuild the frame from the stored mission state.
    canvas.delete("all")                   # wipe the frame before redraw
    draw_background()                        # start with the space backdrop
    draw_portal()                            # exit under the actors
    draw_packages()                          # crates
    draw_asteroids()                         # hazards
    draw_player()                            # the ship on top
    draw_hud()                               # HUD above everything
