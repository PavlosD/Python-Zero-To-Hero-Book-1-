player_name = "Rin"
player_score = 120
print(f"{player_name} has {player_score} points.")
