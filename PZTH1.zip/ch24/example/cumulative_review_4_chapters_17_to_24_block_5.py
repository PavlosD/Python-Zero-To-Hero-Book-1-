answer_entry = tk.Entry(window)    # answer input box
