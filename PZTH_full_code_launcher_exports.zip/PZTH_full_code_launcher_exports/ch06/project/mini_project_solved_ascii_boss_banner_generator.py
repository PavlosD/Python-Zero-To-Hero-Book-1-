import random                        # pick one of four boss names

def show_title():                    # arcade-title function
    print("================================")
    print("      ASCII BOSS BANNER         ")
    print("================================")

def choose_monster_name():           # pick this round's villain
    roll = random.randint(1, 4)      # one roll, four villains
    if roll == 1:                    # the marauder warlord
        return "Brigand King"
    elif roll == 2:                  # the silent wraith

        return "Shadow Shade"
    elif roll == 3:                  # the rusted golem
        return "Iron Husk"
    else:                            # the desert tyrant
        return "Moon Drake"

def roll_reward():                   # roll the boss gold drop
    return random.randint(10, 25)    # between 10 and 25 gold

def draw_monster_card(name):              # turn one boss name into a stat card
    if name == "Brigand King":            # marauder stats
        hp = 36
        attack = 7                        # Brigand King attack strength
        face = "<o_o>"                    # Brigand King portrait
    elif name == "Shadow Shade":          # wraith stats
        hp = 24
        attack = 9                        # Shadow Shade attack strength
        face = "(v^v)"                    # Shadow Shade portrait
    elif name == "Iron Husk":             # golem stats
        hp = 42
        attack = 5

        face = "[===]"                    # Iron Husk portrait
    else:                                 # drake stats
        hp = 30
        attack = 8                        # Moon Drake attack strength
        face = "/^..^/"                   # Moon Drake portrait

    print("+------------------------------+")
    print(f"| {name:<28} |")
    print(f"| Face: {face:<22} |")
    print(f"| HP: {hp:<24} |")
    print(f"| Attack: {attack:<20} |")
    print("+------------------------------+")

def show_final_score(score):          # final-rank function
    print("================================")
    print(f"Final banner score: {score}")
    if score >= 50:                   # high-score boundary
        print("Rank: Boss Artist")
    else:                             # lowest banner rank
        print("Rank: Banner Apprentice")

# start the three-round reward total
score = 0
show_title()                             # show the title once

for round_number in range(1, 4):         # run three rounds
    print(f"Round {round_number}")
    monster = choose_monster_name()      # pick this boss
    draw_monster_card(monster)           # draw the boss card
    reward = roll_reward()               # roll the round reward
    score = score + reward               # add reward to score
    print(f"Reward earned: {reward}")
    print()                              # leave space after each boss round

show_final_score(score)                  # finish with the rank earned
