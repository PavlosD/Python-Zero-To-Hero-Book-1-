import random                  # roll a six-sided die
roll = random.randint(1, 6)    # roll first, judge next
print(roll)
