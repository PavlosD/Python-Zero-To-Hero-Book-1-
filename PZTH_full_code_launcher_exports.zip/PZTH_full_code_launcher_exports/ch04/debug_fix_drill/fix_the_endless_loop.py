# BROKEN
# count = 3
# while count > 0:
# print(count)
