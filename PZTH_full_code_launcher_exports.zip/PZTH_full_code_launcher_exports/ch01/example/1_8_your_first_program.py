print("Hello, world!")    # first visible Python output
