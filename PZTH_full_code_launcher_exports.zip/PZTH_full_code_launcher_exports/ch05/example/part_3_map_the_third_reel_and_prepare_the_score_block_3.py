print(f"Score earned: {score}")
if score == 100:                    # top rank for jackpot
    print("Rank: Slot Master")
elif score == 25:                   # rank for a two-symbol match
    print("Rank: Lucky Spinner")
else:                               # every other spin gets Try Again
    print("Rank: Try Again")        # give retry feedback
