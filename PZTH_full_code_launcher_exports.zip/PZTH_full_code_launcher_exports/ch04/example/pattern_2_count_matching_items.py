wins = 0                            # no winning rounds yet
for round_number in range(1, 6):    # check five scores for wins
    score = int(input(f"Score {round_number}: "))
    if score >= 50:                 # winning threshold reached?
        wins = wins + 1             # count this winning round
print("Wins:", wins)                # number of winning rounds
