def boxes_overlap(a, b):      # True when rectangles overlap
    ax1, ay1, ax2, ay2 = a      # unpack box corners
    bx1, by1, bx2, by2 = b      # unpack the other box corners
    return ax1 < bx2 and ax2 > bx1 and ay1 < by2 and ay2 > by1
