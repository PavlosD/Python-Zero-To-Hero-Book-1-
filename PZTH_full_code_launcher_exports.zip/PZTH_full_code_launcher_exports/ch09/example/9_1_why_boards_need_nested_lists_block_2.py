row_1 = [".", ".", "P", "."]    # top row of the grid
row_2 = [".", "#", ".", "."]    # middle row, wall at slot 1
row_3 = ["T", ".", ".", "."]    # bottom row, treasure at 0
