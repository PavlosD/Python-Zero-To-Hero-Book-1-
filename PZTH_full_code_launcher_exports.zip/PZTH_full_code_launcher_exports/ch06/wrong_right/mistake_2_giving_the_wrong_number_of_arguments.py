# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: show_stats expects two arguments.
# def show_stats(name, health):
#     print(name, health)
#     # show_stats("Luna"): one arg short
#     # raises TypeError

# RIGHT VERSION
# CORRECT: define the function, then provide both arguments
def show_stats(name, health):
    print(name, health)

show_stats("Luna", 93)
