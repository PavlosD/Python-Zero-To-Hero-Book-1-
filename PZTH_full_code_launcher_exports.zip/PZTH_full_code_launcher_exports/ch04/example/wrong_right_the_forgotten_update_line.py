energy = 3                 # three actions to spend
while energy > 0:          # continue while dash energy remains
    print("Dash!")
    energy = energy - 1    # one action used
