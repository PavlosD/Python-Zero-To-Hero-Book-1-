coins = int(input("Coins: "))
coins = coins + 5                # add the five-coin bonus
print(coins)
