damage = 5
print("Damage dealt:", damage)    # fixed damage value
