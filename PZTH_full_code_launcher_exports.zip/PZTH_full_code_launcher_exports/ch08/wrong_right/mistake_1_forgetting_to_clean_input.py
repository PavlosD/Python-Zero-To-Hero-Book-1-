# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: this rejects Open and extra spaces
# command = input("Enter command: ")
# if command == "open":
#     print("Opened.")

# RIGHT VERSION
# CORRECT: clean spaces and lowercase
command = input("Enter command: ").strip().lower()
if command == "open":
    print("Opened.")
