player_score = 0
player_score = player_score + 10       # plus ten for the win
print(f"New score: {player_score}")    # total after the bonus
