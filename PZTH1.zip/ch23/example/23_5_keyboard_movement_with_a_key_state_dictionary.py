keys = {                 # true only while a key is held
    "Left": False,       # arrow keys arrive capitalized
    "Right": False,            # strafe right
    "Up": False,                  # climb
    "Down": False,              # descend
    "a": False,          # WASD arrives lowercase
    "d": False,                    # right on WASD
    "w": False,                    # up on WASD
    "s": False,                    # down on WASD
}
