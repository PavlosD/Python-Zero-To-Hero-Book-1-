range(5)
range(1, 6)
range(2, 11, 2)    # step controls the count
