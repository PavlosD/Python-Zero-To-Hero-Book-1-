snake = []                  # body cells, head is index 0
direction = "Right"         # direction used this tick
next_direction = "Right"    # queued legal direction
food = None                 # one food cell, (x, y)
score = 0                   # foods eaten this round
game_running = False        # Snake is not moving yet
move_job = None             # callback ID for the next move
