player_class = input("Choose a class: ").strip().lower()
if player_class == "warrior":              # the front-liner
    print("You start with extra armor.")
elif player_class == "mage":               # the spellcaster
    print("You start with bonus mana.")    # mage receives bonus mana
elif player_class == "ranger":             # the marksman
    print("You start with a longbow.")     # ranger receives a longbow
else:                                      # unknown class
    print("Unknown class. Standard gear equipped.")
