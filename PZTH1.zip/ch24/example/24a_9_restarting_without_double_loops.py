def reset_game():                          # restart with one callback chain
    global snake, direction, next_direction
    global food, score, game_running, move_job

    if move_job is not None:               # the old run still has a queued tick
        root.after_cancel(move_job)         # prevent two movement loops
        move_job = None                    # no callback is queued now
