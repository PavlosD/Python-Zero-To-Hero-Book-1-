print("=== ADVENTURER BACKPACK ===")       # backpack heading
print("Choose 4 items for your backpack.")
print()                                    # blank line before item entry
backpack = []

for slot in range(1, 5):                   # ask for four backpack items
    item = input(f"Enter item {slot}: ").strip().lower()
    backpack.append(item)                  # store this item in the bag

print("=== BACKPACK CONTENTS ===")
for item in backpack:                      # display backpack contents in order
    print(f"- {item}")                     # one visible row for this item
print(f"Total items: {len(backpack)}")     # how many slots used

potion_count = backpack.count("potion")    # count duplicate potions
print(f"Potion count: {potion_count}")
if "key" in backpack:                      # gate-opener present?
    print("You are ready to unlock hidden gates.")
else:                                      # no key in the bag
    print("You may want to find a key before entering.")

backpack.sort()                            # sort item names alphabetically
print("=== SORTED BACKPACK ===")           # heading for the sorted view
for item in backpack:                      # walk the sorted bag
    print(f"- {item}")
