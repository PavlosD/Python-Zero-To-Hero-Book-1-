coins = 10
if coins >= 10:                   # enough coins for the potion
    print("Potion purchased.")
    print("Gold will be reduced later.")
