game_over = False                 # round starts open for play
is_alive = True                   # player still has health
if not game_over and is_alive:    # round active and player alive?
    print("still playing")
else:
    print("round ended")          # no more turns
