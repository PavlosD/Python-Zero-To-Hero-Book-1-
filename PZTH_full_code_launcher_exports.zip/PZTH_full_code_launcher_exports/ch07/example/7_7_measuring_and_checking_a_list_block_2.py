inventory = ["potion", "shield", "potion", "key"]
print(inventory.count("potion"))    # how many potions held
