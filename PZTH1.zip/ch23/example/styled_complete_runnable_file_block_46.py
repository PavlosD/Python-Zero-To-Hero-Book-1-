def show_help():                           # mission briefing screen
    canvas.delete("all")                   # wipe the frame before redraw
    draw_background()                        # same sky as the game
    lines = [                                # briefing, one line each
        "Mission Briefing",                  # index 0 is the heading
        "1. Fly into square packages to complete deliveries.",
        "2. Avoid round asteroids. Each hit costs one life.",
        "3. After enough deliveries, the portal opens.",
        "4. Enter the portal to advance to the next route.",
        "5. Clear three routes to win the courier contract.",
        "Press ESC to return to the title screen.",
    ]
