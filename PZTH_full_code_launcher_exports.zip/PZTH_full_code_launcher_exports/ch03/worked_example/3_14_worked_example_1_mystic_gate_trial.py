command = input("Speak to the gate: ").strip().lower()
if command == "open":            # the magic word
    print("The gate rumbles and opens.")
elif command == "knock":         # polite but not enough
    print("The gate stays closed, but something moves behind it.")
else:                            # anything else fails
    print("Nothing happens.")
