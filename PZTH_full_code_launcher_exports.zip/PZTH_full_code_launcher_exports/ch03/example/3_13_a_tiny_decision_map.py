command = "knock"                # the word the rules test against
