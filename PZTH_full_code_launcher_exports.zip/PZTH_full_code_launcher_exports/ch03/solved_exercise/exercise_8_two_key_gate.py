has_silver = True
has_gold = False
if has_silver and has_gold:      # both badges are required
    print("Door opens.")
else:
    print("Door stays shut.")    # gold badge is still missing
