def clamp(value, low, high):             # keep a coordinate inside arena bounds
    return max(low, min(value, high))    # never below low, never above high

x = 900
x = clamp(x, 24, 736)                    # keep x inside arena
print(x)                                 # clamped position
