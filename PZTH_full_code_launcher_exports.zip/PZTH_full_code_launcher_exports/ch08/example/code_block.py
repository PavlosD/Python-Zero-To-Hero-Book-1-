command = "  OPEN  ".strip().lower()    # clean spaces and case
print(command)
