def boxes_overlap(a, b):              # True when rectangles overlap
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    return ax1 < bx2 and ax2 > bx1 and ay1 < by2 and ay2 > by1

player_box = (100, 100, 140, 140)     # ship rectangle used in the overlap check
package_box = (130, 120, 155, 145)    # delivery item to collect
print(boxes_overlap(player_box, package_box))
