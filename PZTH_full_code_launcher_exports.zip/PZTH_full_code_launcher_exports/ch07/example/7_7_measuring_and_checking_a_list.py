inventory = ["potion", "shield", "key"]    # three items again
print(len(inventory))                      # list item count
