age = int(input("Enter age: "))    # convert typed text to an integer
print(age + 1)                     # converted age can now be increased
