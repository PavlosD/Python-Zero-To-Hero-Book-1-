command = input("Enter command: ").lower()
if command == "open":           # open command survives cleanup
    print("The gate opens.")
