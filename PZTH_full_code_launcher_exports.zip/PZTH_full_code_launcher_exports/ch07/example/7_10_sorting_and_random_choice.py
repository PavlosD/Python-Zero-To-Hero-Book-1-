scores = [40, 10, 30, 20]    # unsorted scores to arrange
scores.sort()
print(scores)                # sorted score list
