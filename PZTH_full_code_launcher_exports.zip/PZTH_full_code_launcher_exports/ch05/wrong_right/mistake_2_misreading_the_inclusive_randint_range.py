# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: this can return 6 too
# import random
# roll = random.randint(0, 6)
# print(roll)

# RIGHT VERSION
# CORRECT: 0 through 5 stops at 5
import random
roll = random.randint(0, 5)
print(roll)
