CELL_SIZE = 20                             # one snake square is 20 px
GRID_WIDTH = 20                            # horizontal cell count
GRID_HEIGHT = 20                           # vertical cell count
MOVE_DELAY = 120                           # milliseconds per snake step

CANVAS_WIDTH = CELL_SIZE * GRID_WIDTH      # 20 cells across, in pixels
CANVAS_HEIGHT = CELL_SIZE * GRID_HEIGHT    # 20 cells down, in pixels
