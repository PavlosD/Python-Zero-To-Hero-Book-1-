words = "look".split()    # split command into words
if len(words) >= 2:       # command has a target word
    target = words[1]     # second word is the object
    print(target)
