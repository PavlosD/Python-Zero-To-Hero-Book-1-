board = [
    [".", ".", "P", "."],
    [".", "#", ".", "."],
    ["T", ".", ".", "."]
]
print(board)    # whole grid on one line
