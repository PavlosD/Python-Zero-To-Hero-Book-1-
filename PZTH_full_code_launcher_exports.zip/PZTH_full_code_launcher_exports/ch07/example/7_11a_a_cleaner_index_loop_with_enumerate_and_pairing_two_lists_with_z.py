heroes = ["Knight", "Wizard", "Archer"]    # hero names paired with HP totals
hp_values = [42, 24, 30]                   # three HP totals to compare
for hero, hp in zip(heroes, hp_values):    # pair each hero with its HP
    print(f"{hero}: {hp} HP")              # one clean paired output line
