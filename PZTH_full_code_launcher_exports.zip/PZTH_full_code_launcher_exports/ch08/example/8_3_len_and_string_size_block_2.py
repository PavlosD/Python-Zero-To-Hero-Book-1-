message = "open door"
print(len(message))      # message length including the space
