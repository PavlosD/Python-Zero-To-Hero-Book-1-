snake = [(5, 10), (4, 10), (3, 10)]    # snake body cells
