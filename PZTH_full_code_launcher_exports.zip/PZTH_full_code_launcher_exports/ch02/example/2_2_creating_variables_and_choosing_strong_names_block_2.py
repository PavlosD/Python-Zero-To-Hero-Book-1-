h = 100      # h of what? unclear
x = "Rin"    # bad name: x hides its meaning
y = 25
