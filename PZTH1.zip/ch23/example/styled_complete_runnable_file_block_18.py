def spawn_asteroid():                      # drop a fresh hazard
    # Higher levels make each new rock a little faster.
    asteroids.append({                                     # falling asteroid
        "x": random.randint(34, WIDTH - 34),
        "y": random.randint(HUD_HEIGHT - 185, HUD_HEIGHT - 48),
        "size": random.randint(26, 42),        # rocks vary in size
        "speed": random.uniform(2.0, 3.0) + state["level"] * 0.45,
    })

def move_player():                         # move from the keys held this frame
    dx = 0                                 # no sideways input yet
    dy = 0                                 # no vertical input yet
