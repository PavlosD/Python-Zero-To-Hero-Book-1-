def schedule_next_move():                # queue one Snake tick
    global move_job                      # reuse the shared callback ID
    move_job = root.after(MOVE_DELAY, move_snake)

def move_snake():                        # move the snake once
    global direction, score, move_job    # these change during a tick

    move_job = None                      # fired callback is no longer queued
