score = 75
if score >= 90:              # Gold begins at ninety
    print("Rank: Gold")
elif score >= 70:            # Silver-rank threshold
    print("Rank: Silver")
else:
    print("Rank: Bronze")    # scores below 70 earn Bronze
