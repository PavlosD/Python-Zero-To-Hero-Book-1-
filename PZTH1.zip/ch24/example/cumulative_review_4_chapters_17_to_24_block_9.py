button = tk.Button(window, text="Check", command=check_answer)
