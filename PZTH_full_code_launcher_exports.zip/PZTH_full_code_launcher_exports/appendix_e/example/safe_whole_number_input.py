while True:
    try:
        score = int(input("Score: "))
        break
    except ValueError:
        print("Enter a whole number.")
