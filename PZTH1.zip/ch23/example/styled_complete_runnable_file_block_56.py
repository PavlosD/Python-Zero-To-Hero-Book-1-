def key_up(event):                     # release one movement key
    key = event.keysym                 # key name from the release event
    if key in keys:
        keys[key] = False

# ----------------------- program start -----------------------
build_stars()                            # starfield before title
window.bind("<KeyPress>", key_down)    # key presses enter key_down
window.bind("<KeyRelease>", key_up)    # key releases enter key_up
window.focus_set()                       # send keyboard events to this window
show_title()                             # draw the opening screen
window.mainloop()                      # listen for courier controls
