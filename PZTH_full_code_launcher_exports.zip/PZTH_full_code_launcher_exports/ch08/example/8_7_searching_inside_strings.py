description = "a rusty key lies under the table"
if "key" in description:    # room text contains "key"?
    print("You notice something useful.")
