hero_class = "Mage"                 # mage unlocks the bonus
if hero_class == "Mage":            # Mage receives the mana bonus
    print("Mana bonus applied.")
