def can_buy(gold, price):        # report whether the item is affordable
    return gold >= price

if can_buy(30, 20):              # 30 gold vs 20 price
    print("Potion bought.")
else:
    print("Not enough gold.")    # wallet cannot cover the price
