print("Ready!")
