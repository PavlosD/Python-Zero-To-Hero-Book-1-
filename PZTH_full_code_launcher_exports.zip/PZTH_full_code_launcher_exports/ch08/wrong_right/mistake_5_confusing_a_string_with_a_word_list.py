# WRONG VERSION - commented out so the launcher can run safely
# command = "take monkey"
# # WRONG: substring matching also finds key inside monkey
# if "key" in command:
#     print("The command mentions a key.")

# RIGHT VERSION
command = "take monkey"
# CORRECT: split first when the program needs whole words
words = command.split()
if "key" in words:
    print("The command mentions a key.")
