word = "gate"     # the secret word to match
print(word)
print(word[0])
