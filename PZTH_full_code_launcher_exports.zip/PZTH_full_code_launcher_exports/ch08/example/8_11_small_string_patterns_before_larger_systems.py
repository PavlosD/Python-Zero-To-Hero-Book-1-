name = "  iris  "                    # lowercase with edge spaces
clean_name = name.strip().title()
print(clean_name)
command = "take key"                 # two-word command sample
words = command.split()              # split, then decide
action = words[0]                    # first word is the verb
target = words[1]                    # second word is the object
print(action)
print(target)
