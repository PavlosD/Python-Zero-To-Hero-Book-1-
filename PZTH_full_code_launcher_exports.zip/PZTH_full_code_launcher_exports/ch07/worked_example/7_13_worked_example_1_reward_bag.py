rewards = []                       # rewards collected this run
rewards.append("coin")
rewards.append("potion")
rewards.append("key")

for item in rewards:               # show the reward bag in order
    print(f"- {item}")
print(f"Total: {len(rewards)}")    # number of rewards collected
