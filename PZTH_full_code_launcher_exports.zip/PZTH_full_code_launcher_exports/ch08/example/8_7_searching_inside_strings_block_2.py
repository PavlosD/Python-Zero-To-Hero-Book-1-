message = "gold gold gem gold"        # text searched below
gold_count = message.count("gold")    # number of "gold" matches
print(gold_count)
