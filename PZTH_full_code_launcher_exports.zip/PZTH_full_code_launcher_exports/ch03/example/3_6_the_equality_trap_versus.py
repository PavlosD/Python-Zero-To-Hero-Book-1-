gold = 25
print(gold == 25)    # True: gold is exactly 25
