def greet():       # return reusable greeting text
    return "hi"

print(greet())     # display returned greeting
