def clamp(value, low, high):             # constrain one coordinate to a range
    return max(low, min(value, high))

def player_box():                        # ship rectangle for collision checks
    half_w = player["w"] // 2            # horizontal centre-to-edge distance
    half_h = player["h"] // 2            # vertical centre-to-edge distance
    return (
        player["x"] - half_w,              # left edge
        player["y"] - half_h,              # top edge
        player["x"] + half_w,              # right edge
        player["y"] + half_h,              # bottom edge
    )
