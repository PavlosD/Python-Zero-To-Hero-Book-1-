happiness = 8                             # pet mood score
boost = 5                                 # reward booster
happiness = min(10, happiness + boost)    # 10, not 13
print(happiness)                          # happiness capped at ten
