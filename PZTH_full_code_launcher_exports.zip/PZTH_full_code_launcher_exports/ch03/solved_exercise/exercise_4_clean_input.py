command = input("Enter command: ").strip().lower()
if command == "open":            # open command entered?
    print("The chest opens.")
