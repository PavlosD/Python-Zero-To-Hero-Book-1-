score = 95
if score >= 90:        # test Gold before the broader Silver range
    print("Gold")
elif score >= 70:      # Silver-rank threshold
    print("Silver")
