def greet(name="hero"):           # greet, defaulting to "hero"
    print(f"Welcome, {name}!")    # greet with the argument
