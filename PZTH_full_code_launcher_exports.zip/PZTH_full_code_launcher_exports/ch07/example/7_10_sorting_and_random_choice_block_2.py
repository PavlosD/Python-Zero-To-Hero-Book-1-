items = ["shield", "apple", "potion"]    # items currently tracked
items.sort()
print(items)                             # sorted item list
