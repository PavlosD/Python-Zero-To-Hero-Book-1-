import random

roll_1 = random.randint(1, 4)    # first reel result
roll_2 = random.randint(1, 4)    # second reel result
roll_3 = random.randint(1, 4)    # third reel result

if roll_1 == 1:
    reel_1 = "cherry"
elif roll_1 == 2:
    reel_1 = "lemon"
elif roll_1 == 3:
    reel_1 = "star"
else:
    reel_1 = "bell"

if roll_2 == 1:
    reel_2 = "cherry"
elif roll_2 == 2:
    reel_2 = "lemon"
elif roll_2 == 3:
    reel_2 = "star"
else:
    reel_2 = "bell"

if roll_3 == 1:
    reel_3 = "cherry"
elif roll_3 == 2:
    reel_3 = "lemon"
elif roll_3 == 3:
    reel_3 = "star"
else:
    reel_3 = "bell"

score = 0                          # losing spins still earn zero

print(f"[ {reel_1} | {reel_2} | {reel_3} ]")
if reel_1 == reel_2 and reel_2 == reel_3:
    score = 100                     # jackpot pays full points
    print("JACKPOT! Three symbols match.")
elif reel_1 == reel_2 or reel_1 == reel_3 or reel_2 == reel_3:
    score = 25                      # two matching symbols pay 25 points
    print("Small win! Two symbols match.")
else:                               # nothing matched
    print("No match this time.")

print(f"Score earned: {score}")
if score == 100:                    # top rank for jackpot
    print("Rank: Slot Master")
elif score == 25:                   # rank for a two-symbol match
    print("Rank: Lucky Spinner")
else:                               # every other spin gets Try Again
    print("Rank: Try Again")        # give retry feedback
