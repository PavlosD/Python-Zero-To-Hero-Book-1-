board[2][0] = "."    # clear selected board cell
