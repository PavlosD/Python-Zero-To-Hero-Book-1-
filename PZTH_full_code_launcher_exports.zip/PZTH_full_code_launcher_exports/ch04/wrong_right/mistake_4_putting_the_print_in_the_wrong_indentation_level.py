# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: final message repeats every time
# for i in range(3):
#     print("Wave cleared")
#     print("All waves finished")

# RIGHT VERSION
# CORRECT: final message runs after the loop
for i in range(3):
    print("Wave cleared")
print("All waves finished")
