description = "a key lies near the wall"
if "key" in description:       # room text mentions a key?
    print("You see a key.")
