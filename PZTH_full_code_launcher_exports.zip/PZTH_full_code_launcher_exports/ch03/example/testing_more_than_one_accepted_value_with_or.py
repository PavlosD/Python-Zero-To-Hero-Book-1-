key = "B"                         # shortcut key for the Buy menu
if key == "B" or key == "b":      # either case opens the menu
    print("Buy menu open")
