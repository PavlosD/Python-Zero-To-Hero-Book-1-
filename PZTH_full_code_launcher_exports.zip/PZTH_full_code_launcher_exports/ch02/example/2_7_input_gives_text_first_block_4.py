speed = float(input("Enter movement speed: "))
print(speed)    # speed converted to a decimal number
