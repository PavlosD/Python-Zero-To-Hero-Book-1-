monster = {"speed": 7, "attack": 5}    # monster stats stored under named keys
print(monster["speed"])                # read speed from dictionary
