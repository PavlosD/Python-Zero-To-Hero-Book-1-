coins = 10
print(coins > 5)    # True: 10 is greater than 5
print(coins < 5)    # False: 10 is not below 5
