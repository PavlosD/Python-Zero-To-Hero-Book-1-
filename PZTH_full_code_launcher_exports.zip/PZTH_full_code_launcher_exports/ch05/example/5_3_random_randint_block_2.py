import random                      # random healing values
healing = random.randint(5, 12)    # restore between 5 and 12 HP
print("You restored", healing, "health.")
