print("================================")
print("        PLAYER PROFILE          ")
print("================================")
print(f"Name:  {player_name}")
print(f"Class: {player_class}")
print(f"Level: {player_level}")
# final gold including the bonus
print(f"Gold:  {total_gold}")
