inventory = ["potion", "shield"]    # two items only
inventory.append("key")             # add "key" to the inventory
print(inventory)
