if command == "open":
    print("The gate opens.")
elif command == "knock":
    print("Something moves behind the gate.")
else:
    print("Nothing happens.")    # no command rule matched
