with open("save.txt", "r") as file:
    data = file.read()
