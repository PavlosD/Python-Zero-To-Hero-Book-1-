# collect the hero name
player_name = input("Enter your hero name: ")
# collect the chosen class
player_class = input("Enter your class: ")
player_level = int(input("Enter starting level: "))
print("=== PLAYER PROFILE ===")
print(f"Name: {player_name}")
print(f"Class: {player_class}")
print(f"Level: {player_level}")
