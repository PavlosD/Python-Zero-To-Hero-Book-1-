location = "shadow forest"    # the current location
print(location.title())
