rolls = [4, 6, 2, 5, 3]    # five dice results
print(sum(rolls))          # 20
