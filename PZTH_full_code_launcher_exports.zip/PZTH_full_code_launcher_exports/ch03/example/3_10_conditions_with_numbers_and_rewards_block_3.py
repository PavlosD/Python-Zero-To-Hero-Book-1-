potion_price = 5     # cost of one potion
potion_count = 3
total_cost = potion_price * potion_count
print(total_cost)    # cost of three potions
