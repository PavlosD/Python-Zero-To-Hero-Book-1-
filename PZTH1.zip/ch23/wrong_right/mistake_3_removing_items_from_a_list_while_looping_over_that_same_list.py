# WRONG VERSION - commented out so the launcher can run safely
# for asteroid in asteroids:
#     if asteroid["y"] > HEIGHT:
#         asteroids.remove(asteroid)

# RIGHT VERSION
for asteroid in asteroids[:]:
    if asteroid["y"] > HEIGHT:
        asteroids.remove(asteroid)
