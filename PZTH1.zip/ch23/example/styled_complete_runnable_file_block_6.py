# Key values stay True only while that movement key is held.
keys = {                                         # one flag per movement key
    "Left": False,                     # arrows arrive capitalized
    "Right": False,                   # strafe right
    "Up": False,                         # climb
    "Down": False,                     # descend
    "a": False,                           # WASD, lowercase
    "d": False,                           # right on WASD
    "w": False,                           # up on WASD
    "s": False,                           # down on WASD
}
