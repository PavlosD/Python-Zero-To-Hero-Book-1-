command = input("Enter command: ").strip().lower()
if command == "open":            # normalized command matches "open"
    print("The chest opens.")
else:
    print("Unknown command.")    # not in the action list
