word = "dragon"    # the word players must guess
print(word[0])
