for _ in range(6):                       # six successful pickups
    collect_package()                      # simulate six pickups

print("deliveries:", state["deliveries"])
print("portal_active:", state["portal_active"])
