score = 0
print("Score:", score)    # match opens with no points
