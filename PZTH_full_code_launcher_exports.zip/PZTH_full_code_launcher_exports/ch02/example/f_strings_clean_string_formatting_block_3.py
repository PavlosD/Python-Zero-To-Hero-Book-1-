hero_name = "Zev"        # hero name printed in the arena line
hero_class = "Ranger"    # class printed in the arena line
print(f"{hero_name} enters the arena as a {hero_class}.")
