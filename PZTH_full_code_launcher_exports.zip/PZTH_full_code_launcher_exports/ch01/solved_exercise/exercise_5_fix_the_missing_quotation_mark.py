# CORRECT: both quotation marks are present
print("The gate is open.")
