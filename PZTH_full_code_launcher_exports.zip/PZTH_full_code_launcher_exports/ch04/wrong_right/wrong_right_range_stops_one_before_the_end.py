# WRONG VERSION - commented out so the launcher can run safely
# # Goal: print 1, 2, 3, 4, 5
# for i in range(1, 5):  # stops at 4, not at 5
#     print(i)

# RIGHT VERSION
# range(1, 6) reaches 5 because 6 is excluded
for i in range(1, 6):
    print(i)
