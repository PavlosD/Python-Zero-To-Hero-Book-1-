enemies = ["hollow", "shade", "drake"]    # drake hides at the end
print(enemies)                            # active enemy list
