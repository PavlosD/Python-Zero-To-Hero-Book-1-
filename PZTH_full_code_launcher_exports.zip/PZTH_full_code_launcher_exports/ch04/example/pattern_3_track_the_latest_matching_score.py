latest_winner = 0                   # no qualifying score yet
for round_number in range(1, 6):    # track the latest qualifying score
    score = int(input(f"Score {round_number}: "))
    if score >= 50:                 # winning threshold reached?
        latest_winner = score       # store the latest qualifying score
print("Latest winning score:", latest_winner)
