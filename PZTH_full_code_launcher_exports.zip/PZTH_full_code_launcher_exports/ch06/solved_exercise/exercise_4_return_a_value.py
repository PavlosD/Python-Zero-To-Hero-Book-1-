def add_bonus(score):
    return score + 10       # return the increased score

new_score = add_bonus(25)   # capture the bonus-adjusted score
print(new_score)
