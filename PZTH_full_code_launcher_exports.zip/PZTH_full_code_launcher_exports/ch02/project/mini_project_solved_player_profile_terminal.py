player_name = input("Enter your hero name: ")
player_class = input("Enter your class: ")

# convert level and gold because the program needs numbers, not text
player_level = int(input("Enter your starting level: "))
starting_gold = int(input("Enter your starting gold: "))

welcome_bonus = 10                 # starting bonus for a new hero
total_gold = starting_gold + welcome_bonus

print("================================")
print("        PLAYER PROFILE          ")
print("================================")
print(f"Name:  {player_name}")
print(f"Class: {player_class}")
print(f"Level: {player_level}")
# final gold including the bonus
print(f"Gold:  {total_gold}")
