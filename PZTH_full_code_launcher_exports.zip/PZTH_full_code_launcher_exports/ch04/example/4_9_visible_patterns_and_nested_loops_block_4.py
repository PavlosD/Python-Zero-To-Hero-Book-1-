for row in range(2):
    for col in range(3):      # draw three cells in this row
        print("#", end="")    # stay on the same row
    print()                   # end the row
