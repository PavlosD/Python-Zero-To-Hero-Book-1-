inventory = ["potion", "shield", "key"]
for item in inventory:                     # scan the bag
    print(item)
