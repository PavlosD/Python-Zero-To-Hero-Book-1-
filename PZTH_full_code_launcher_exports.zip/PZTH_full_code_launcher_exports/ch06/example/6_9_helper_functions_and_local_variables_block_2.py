def demo():  # keep the local-variable example inside one function
    message = "Inside function"    # exists only inside demo()
    print(message)
demo()
