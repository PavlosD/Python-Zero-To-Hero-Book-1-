# BROKEN
# cheer()
# def cheer():
# print("Victory!")
