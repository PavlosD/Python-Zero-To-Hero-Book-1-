# WRONG VERSION - commented out so the launcher can run safely
# import random
# # WRONG: score resets every chest
# for chest in range(1, 4):
#     score = 0                          # reset erases earlier rewards
#     reward = random.randint(5, 21)     # one reward for this chest
#     score = score + reward
# print("Final score:", score)

# RIGHT VERSION
import random
# CORRECT: score survives all chests
score = 0
for chest in range(1, 4):
    reward = random.randint(5, 21)
    score = score + reward
print("Final score:", score)
