player_score = 0
print(player_score)
player_score = 50
print(player_score)
