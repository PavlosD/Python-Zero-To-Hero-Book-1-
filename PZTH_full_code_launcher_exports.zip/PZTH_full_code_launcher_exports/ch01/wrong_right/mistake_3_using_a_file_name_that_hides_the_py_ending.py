# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: hidden extensions can create notes.py.txt
# # notes.py.txt

# RIGHT VERSION
# CORRECT: the file ends with .py
print("My Python file is running.")  # inside notes.py
