print("=== MOON QUEST ===")
print("You land on a silent moon base.")
print("The lights flicker in the distance.")
