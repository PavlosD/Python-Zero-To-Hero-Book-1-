score = 120
if score >= 100:                      # victory-score threshold
    print("Bonus stage unlocked!")    # reward threshold message
