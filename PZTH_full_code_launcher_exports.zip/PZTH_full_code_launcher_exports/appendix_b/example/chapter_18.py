def play_round(choice):               # one rock-paper-scissors turn
    print("Player chose:", choice)
rock_btn = ttk.Button(window, text="Rock", command=choose_rock)
