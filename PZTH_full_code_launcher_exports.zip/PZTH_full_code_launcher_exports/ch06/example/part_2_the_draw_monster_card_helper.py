def draw_monster_card(name):              # turn one boss name into a stat card
    if name == "Brigand King":            # marauder stats
        hp = 36
        attack = 7                        # Brigand King attack strength
        face = "<o_o>"                    # Brigand King portrait
    elif name == "Shadow Shade":          # wraith stats
        hp = 24
        attack = 9                        # Shadow Shade attack strength
        face = "(v^v)"                    # Shadow Shade portrait
    elif name == "Iron Husk":             # golem stats
        hp = 42
        attack = 5
