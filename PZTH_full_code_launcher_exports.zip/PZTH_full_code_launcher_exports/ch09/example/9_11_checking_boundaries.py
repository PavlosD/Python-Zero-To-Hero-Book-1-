# store the attempted destination
board = [
    [".", ".", "."],
    [".", "P", "."],
    [".", ".", "."]
]
new_row = 1                               # proposed row after move
new_col = 3
rows = len(board)                         # board height
cols = len(board[0])                      # board width
if 0 <= new_row < rows and 0 <= new_col < cols:
    print("Move is inside the board.")    # the move stays on the board
