import random                       # flip a virtual coin
flip_roll = random.randint(1, 2)    # choose heads or tails
if flip_roll == 1:
    result = "heads"                # the coin landed heads
else:
    result = "tails"                # the only other face
print(result)
