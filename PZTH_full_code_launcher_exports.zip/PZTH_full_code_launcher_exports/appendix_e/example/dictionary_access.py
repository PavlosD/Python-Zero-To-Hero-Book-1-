health = player["health"]    # read health field
