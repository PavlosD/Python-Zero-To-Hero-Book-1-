import random                       # roll five attack checks

critical_hits = 0                   # no critical rolls yet

for attack in range(1, 6):          # make five attack rolls
    roll = random.randint(1, 20)    # twenty-sided critical check
    print("Roll:", roll)            # reveal the roll before judging it

    if roll >= 18:                  # critical-hit threshold
        critical_hits = critical_hits + 1

print(f"Critical hits: {critical_hits}")
