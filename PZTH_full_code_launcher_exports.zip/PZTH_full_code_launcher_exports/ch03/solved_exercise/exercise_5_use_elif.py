score = 72
if score >= 90:        # Gold-rank threshold
    print("Gold")
elif score >= 70:      # Silver-rank threshold
    print("Silver")
else:
    print("Bronze")
