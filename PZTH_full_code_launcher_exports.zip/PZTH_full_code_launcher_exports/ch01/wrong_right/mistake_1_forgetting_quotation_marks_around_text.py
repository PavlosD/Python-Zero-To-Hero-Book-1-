# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: unquoted words are treated as Python names
# # print(Dragon Gate)

# RIGHT VERSION
# CORRECT: the text is inside quotation marks
print("Dragon Gate")
