has_key = True                       # player carries the key
knows_code = False
can_open = has_key and knows_code    # both must be true

if can_open:                         # both gate requirements passed?
    print("Gate opened.")
else:
    print("Gate locked.")            # code is still missing
