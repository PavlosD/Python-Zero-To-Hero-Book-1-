player_gold = 40
potion_cost = 12
player_gold = player_gold - potion_cost
print(player_gold)    # gold after the shop purchase
