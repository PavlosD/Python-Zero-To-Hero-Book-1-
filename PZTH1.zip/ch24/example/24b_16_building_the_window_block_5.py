
restart_button = tk.Button(main_frame, text="Restart Battle",
                           font=("Arial", 12, "bold"), width=18,
                           command=reset_game, bg=ACCENT, fg=TEXT,
                           activebackground=ACCENT, bd=0)
restart_button.pack()                     # new fleets on demand

reset_game()                              # place both random fleets
root.mainloop()                           # handle shots, Restart, and CPU turns
