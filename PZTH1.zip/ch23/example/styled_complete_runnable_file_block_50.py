# ---------------- game loop and keyboard input ----------------
def schedule_next_frame():               # keep one callback chain alive
    global frame_job                      # replace the shared callback ID
    if frame_job is None and state["screen"] == "playing":
        frame_job = window.after(FRAME_DELAY_MS, update_game)

def update_game():                       # run one animation frame
    global frame_job                      # fired job no longer waits
    frame_job = None                      # this callback is running now
