# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: coins is still text here
# coins = input("Enter coins: ")
# # coins = coins + 5

# RIGHT VERSION
# CORRECT: convert before adding
coins = int(input("Enter coins: "))
coins = coins + 5
print(coins)
