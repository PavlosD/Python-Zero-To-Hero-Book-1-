inventory = ["potion", "shield", "key"]    # the three-item bag
if "key" in inventory:                     # is the key in the bag?
    print("The gate unlocks.")
else:
    print("You still need a key.")         # bag has no key
