score = 0
for i in range(3):        # add ten points three times
    score = score + 10    # ten more each pass
    print(score)
