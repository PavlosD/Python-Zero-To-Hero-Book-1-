# BROKEN
# command = "open"
# if command = "open":
# print("Gate opens")
