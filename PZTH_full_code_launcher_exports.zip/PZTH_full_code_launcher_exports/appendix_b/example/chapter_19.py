if question_index >= len(questions):    # index reached the total
    show_final_screen()
else:
    load_question()
