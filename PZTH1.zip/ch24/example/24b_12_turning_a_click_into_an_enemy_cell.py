def enemy_cell_from_click(event):        # map a canvas click to an enemy cell
    col = (event.x - ENEMY_X) // CELL    # pixel x to enemy column
    row = (event.y - BOARD_Y) // CELL    # pixel y to enemy row
    inside_row = 0 <= row < GRID_SIZE    # row must be valid
    inside_col = 0 <= col < GRID_SIZE    # column must be valid
    if inside_row and inside_col:        # click is inside enemy grid
        return row, col                  # convert a click to its board cell
    return None                          # ignore outside clicks
