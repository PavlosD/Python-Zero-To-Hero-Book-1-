message_label.pack()    # place the message label
