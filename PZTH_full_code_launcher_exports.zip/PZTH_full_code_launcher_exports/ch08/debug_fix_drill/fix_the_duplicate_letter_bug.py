# BROKEN IDEA
# guessed_letters.append(guess)
# if guess in secret_word:
# print("Good guess!")
