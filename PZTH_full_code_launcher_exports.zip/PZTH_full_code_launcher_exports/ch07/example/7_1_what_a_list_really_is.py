inventory = ["potion", "shield", "key"]    # current backpack contents
