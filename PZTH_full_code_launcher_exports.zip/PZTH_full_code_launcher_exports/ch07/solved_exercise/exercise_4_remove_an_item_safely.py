inventory = ["potion", "shield", "key"]    # trio for this exercise
if "potion" in inventory:                  # any potion carried?
    inventory.remove("potion")
print(inventory)
