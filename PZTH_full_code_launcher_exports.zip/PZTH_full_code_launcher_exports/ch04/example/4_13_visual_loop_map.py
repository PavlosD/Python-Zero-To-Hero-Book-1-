count = 3
while count > 0:
    print(count)
    count = count - 1    # move one step toward zero
print("Go!")
