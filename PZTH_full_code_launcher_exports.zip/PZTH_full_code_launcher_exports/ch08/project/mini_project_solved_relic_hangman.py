secret_word = "relic"    # word to uncover
guessed_letters = []     # letters already attempted
wrong_guesses = 0        # misses made so far
max_wrong = 6            # game ends after six misses

print("================================")
print("          RELIC HANGMAN         ")
print("================================")
print("Guess the relic word one letter at a time.")
print()                  # separate banner from first turn

while wrong_guesses < max_wrong:      # guesses remain?
    display = ""                      # rebuild mask this turn

    for letter in secret_word:        # inspect each secret letter
        if letter in guessed_letters: # has player tried this letter?
            display = display + letter + " "
        else:
            display = display + "_ "  # hide unguessed letter

    print(f"Word: {display}")         # blanks and found letters
    print(f"Tried: {' '.join(guessed_letters)}")
    print(f"Wrong guesses: {wrong_guesses}/{max_wrong}")
    danger = "#" * wrong_guesses + "." * (max_wrong - wrong_guesses)
    print(f"Danger: {danger}")

    if "_" not in display:    # every letter revealed?
        break                 # solved; leave main loop

    guess = input("Guess one letter: ").strip().lower()

    if len(guess) != 1 or not guess.isalpha():
        print("Enter exactly one letter.")
        continue

    if guess in guessed_letters:    # letter already attempted?
        print("You already tried that letter.")
        print()
        continue                    # reject the duplicate guess

    guessed_letters.append(guess)      # store this attempted letter

    if guess in secret_word:           # letter appears in the word?
        print("Good guess!")
    else:
        wrong_guesses = wrong_guesses + 1
        print("The trap tightens!")

    print()                            # leave a blank line after this guess

if wrong_guesses >= max_wrong:          # wrong guesses hit limit
    danger = "#" * max_wrong            # fully filled final danger bar
    print(f"Wrong guesses: {wrong_guesses}/{max_wrong}")
    print(f"Danger: {danger}")
    print("The relic stays sealed.")
    print(f"The word was: {secret_word}")
else:
    print("Relic recovered!")
