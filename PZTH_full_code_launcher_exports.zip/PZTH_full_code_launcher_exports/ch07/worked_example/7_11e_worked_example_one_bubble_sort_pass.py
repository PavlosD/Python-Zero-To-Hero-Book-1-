scores = [12, 47, 33, 7, 64, 18, 90, 25]
for i in range(len(scores) - 1):     # compare every neighbouring pair once
    if scores[i] > scores[i + 1]:    # neighbor is smaller
        # swap two neighboring scores
        scores[i], scores[i + 1] = scores[i + 1], scores[i]
print(scores)
