state = {                                  # progress toward the portal
    "deliveries": 0,                       # packages banked so far
    "required": 6,                         # goal for this level
    "portal_active": False,                # door starts closed
}

def collect_package():                   # bank one delivery
    state["deliveries"] += 1             # one more package delivered
    if state["deliveries"] >= state["required"]:
        state["portal_active"] = True    # the portal turns on once
