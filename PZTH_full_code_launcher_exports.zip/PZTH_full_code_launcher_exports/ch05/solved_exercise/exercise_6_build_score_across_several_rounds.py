import random                        # roll four score rewards
score = 0
for round_number in range(1, 5):     # play four scoring rounds
    reward = random.randint(2, 8)    # this round earns 2 to 8 points
    score = score + reward           # add this round's reward to the total
    print(f"Round {round_number}: +{reward}")
    print(f"Total: {score}")         # score after this round
