window.bind("<KeyPress>", on_key)    # send every key press to on_key
window.focus_set()
window.mainloop()                    # listen for key presses
