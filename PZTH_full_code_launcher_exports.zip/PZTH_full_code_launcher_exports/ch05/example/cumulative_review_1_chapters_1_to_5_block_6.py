coins = int(input("Coins: "))    # convert typed coins
