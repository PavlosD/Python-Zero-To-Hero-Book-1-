player_name = input("Enter your hero name: ")
player_title = input("Enter your title: ")
print("=== ARENA NAME CARD ===")    # card title
print(f"{player_name}, the {player_title}")
