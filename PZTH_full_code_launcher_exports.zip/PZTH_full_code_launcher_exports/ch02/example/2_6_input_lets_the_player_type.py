name = input("Enter your name: ")    # store typed player name
print(name)
