speed = float(input("Enter movement speed: "))
print(f"Movement speed: {speed}")    # report the final speed
