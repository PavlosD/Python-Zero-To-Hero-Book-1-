import random                     # vary each attack's damage
damage = random.randint(4, 7)     # this hit deals 4 to 7 damage
print("Damage dealt:", damage)
