def battle_intro():                    # battle-opening function
    print("=== BATTLE START ===")
    print("Hero enters the arena.")
battle_intro()
battle_intro()
