scores = [45, 12, 89, 70, 22]    # unsorted scores with a clear top two
best = 0
second_best = 0                  # runner-up so far

for score in scores:             # test each score once
    if score > best:             # new first place?
        second_best = best       # previous best becomes runner-up
        best = score             # store the new highest score
    elif score > second_best:    # new runner-up?
        second_best = score      # store second place

print(f"1st: {best}, 2nd: {second_best}")
