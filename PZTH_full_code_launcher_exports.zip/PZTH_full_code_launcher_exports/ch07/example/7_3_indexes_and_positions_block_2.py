animals = ["fox", "owl", "bear"]    # three woodland picks
print(animals[0])
