coins_as_text = "25"          # still a string, not a number
coins_as_number = 25
print(coins_as_text)
print(coins_as_number + 5)    # arithmetic works on ints
