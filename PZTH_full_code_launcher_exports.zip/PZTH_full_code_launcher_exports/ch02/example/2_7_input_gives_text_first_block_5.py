potion_count = int(input("Enter potion count: "))
potion_count = potion_count + 1    # add the newly found potion
print(potion_count)                # updated potion count
