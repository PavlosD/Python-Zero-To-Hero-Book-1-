def battle_banner():                       # battle-opening function
    print("=== BATTLE BEGINS ===")
    print("The arena lights flare on.")

battle_banner()                            # first battle opening
battle_banner()                            # reuse it for round two
