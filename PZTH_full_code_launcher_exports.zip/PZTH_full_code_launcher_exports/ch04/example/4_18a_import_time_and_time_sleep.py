import time         # make time.sleep() available
print("Frame 1")
time.sleep(1)       # hold each countdown number for one second
print("Frame 2")
