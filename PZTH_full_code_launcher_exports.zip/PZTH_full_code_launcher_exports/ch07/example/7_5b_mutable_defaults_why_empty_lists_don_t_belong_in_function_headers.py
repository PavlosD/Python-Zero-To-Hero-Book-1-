inventory = ["potion", "key"]    # no shield this time
inventory.insert(1, "shield")    # insert shield at index 1
print(inventory)                 # what the bag holds now
