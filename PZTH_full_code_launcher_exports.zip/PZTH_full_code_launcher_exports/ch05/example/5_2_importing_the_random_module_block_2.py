import random                   # make random tools available
print("Random tools ready.")    # execution continued past the import
