print(screen_size[0])    # 800 (the width)
print(red_color[2])      # 0 (the blue channel)
