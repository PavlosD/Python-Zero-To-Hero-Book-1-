cell = board[1][1]    # one square on the board
print(cell)
