def tick():                   # advance one animation step
    ball["x"] += 4            # move the stored ball position
    canvas.delete("all")      # erase the previous ball frame
    canvas.create_oval(       # draw the ball at its new position
        ball["x"], 50,          # left-top corner
        ball["x"] + 20, 70,     # right-bottom corner
        fill="white", outline="",      # solid dot, no border
    )
    window.after(30, tick)    # schedule the next animation frame

tick()                          # first frame starts the chain
window.mainloop()             # run the clear-and-redraw cycle
