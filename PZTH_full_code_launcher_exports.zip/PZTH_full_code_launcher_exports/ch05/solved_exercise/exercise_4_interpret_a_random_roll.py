import random                  # roll once for feedback
roll = random.randint(1, 6)    # one die roll for this round
print("Roll:", roll)
# turn the roll into three feedback tiers
if roll == 6:                  # best-result face
    print("Great!")
elif roll >= 4:                # good-result range
    print("Good!")
else:
    print("Low!")              # fallback for rolls 1 to 3
