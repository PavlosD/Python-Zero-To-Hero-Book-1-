potions = 3                  # three potions available
while potions > 0:           # any potions left?
    print("Potion used")
    potions = potions - 1    # spend one potion
