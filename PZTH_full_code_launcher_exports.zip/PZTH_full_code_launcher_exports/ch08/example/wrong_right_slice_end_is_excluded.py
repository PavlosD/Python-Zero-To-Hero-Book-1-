name = "Dragon"    # six letters make the excluded end easy to see
