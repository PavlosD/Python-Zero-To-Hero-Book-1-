def bind_key(key_name, new_direction):    # connect key to turn
    root.bind(                            # register key on window
        key_name,  # Tkinter key names are case-sensitive
        lambda event: change_direction(new_direction)
    )

bind_key("<Up>", "Up")
bind_key("<Down>", "Down")
bind_key("<Left>", "Left")
bind_key("<Right>", "Right")
