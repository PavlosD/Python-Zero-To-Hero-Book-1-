print("")                                # gap before the mission line
print("--------------------------------")
print("Tonight, your legend begins.")
