def show_title():                     # banner, printed not drawn
    print("=== MONSTER ARENA ===")
