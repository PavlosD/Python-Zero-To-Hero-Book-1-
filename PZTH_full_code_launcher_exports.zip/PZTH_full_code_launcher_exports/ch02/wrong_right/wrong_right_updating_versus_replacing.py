# WRONG VERSION - commented out so the launcher can run safely
# score = 0                              # score before the discarded update
# score + 10  # computes 10, then throws it away
# print(score)  # still 0

# RIGHT VERSION
score = 0                              # reset before the corrected update
score = score + 10  # keep the ten-point update
print(score)  # 10
