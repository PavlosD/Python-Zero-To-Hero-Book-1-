def get_damage(base):    # return boosted damage, not print it
    return base + 3      # caller can reuse the boosted damage
