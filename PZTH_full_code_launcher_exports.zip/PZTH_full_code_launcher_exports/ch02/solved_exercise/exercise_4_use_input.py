player_name = input("Enter your hero name: ")
print(f"Welcome, {player_name}!")    # personalized welcome
