print(abs(10 - 25))    # 15
print(abs(25 - 10))    # 15
