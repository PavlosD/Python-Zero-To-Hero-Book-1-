# WRONG VERSION - commented out so the launcher can run safely
# # WRONG: this joins text as "1021"
# first_loot = "10"
# second_loot = "21"
# print(first_loot + second_loot)

# RIGHT VERSION
# CORRECT: these are integers, so + adds
first_loot = 10
second_loot = 21
print(first_loot + second_loot)
