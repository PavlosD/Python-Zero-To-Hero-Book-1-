board = [
    [".", ".", "P", "."],
    [".", "#", ".", "."],
    ["T", ".", ".", "."]
]
print(board[0])    # first row only
print(board[1])    # second board row
