name = "Rin"    # name inserted into the f-string
score = 120
print(f"Welcome, {name}! Your score is {score}.")
