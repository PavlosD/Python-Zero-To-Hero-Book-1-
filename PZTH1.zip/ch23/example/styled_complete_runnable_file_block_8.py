state = {                                       # screen and session state
    "screen": "title",         # title, help, playing, paused
    "score": 0,                           # points banked
    "lives": 3,                           # crashes allowed
    "level": 1,                           # current delivery-route number
    "deliveries": 0,                 # packages delivered on this route
    "required": 6,                     # crates needed for the exit
    "frame": 0,                           # ticks since launch
    "portal_active": False,        # exit starts shut
}
