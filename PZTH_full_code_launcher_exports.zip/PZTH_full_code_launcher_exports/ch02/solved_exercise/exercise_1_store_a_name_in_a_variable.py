player_name = "Rin"    # name for the score line
print(player_name)
