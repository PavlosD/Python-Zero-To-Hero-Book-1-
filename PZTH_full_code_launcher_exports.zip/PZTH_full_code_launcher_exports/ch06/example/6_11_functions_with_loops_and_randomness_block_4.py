import random                       # random tools for reward rolls
def random_reward():                # roll five to fifteen gold
    return random.randint(5, 15)
score = 0
for i in range(3):                  # generate three rewards
    reward = random_reward()        # reward returned for this round
    score = score + reward          # add it to the running total
    print(f"Reward: {reward}   Total: {score}")
