# ---------------------- window settings ---------------------
WIDTH = 760                       # the arena is 760 px wide
HEIGHT = 520                      # 520 px tall
HUD_HEIGHT = 64                   # 64 px status strip on top
FRAME_DELAY_MS = 30               # 30 ms per frame is about 33 fps
PLAYER_SPEED = 7                  # the ship slides 7 px a frame
MAX_LEVEL = 3                     # across three delivery routes
