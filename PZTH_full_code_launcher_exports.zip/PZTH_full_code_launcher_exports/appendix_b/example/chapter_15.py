# bar_helper.py
def show_bar(value):               # bar function reused from another file
    print("HP:", value)

# main.py
from bar_helper import show_bar    # bring show_bar() into main.py
show_bar(80)
