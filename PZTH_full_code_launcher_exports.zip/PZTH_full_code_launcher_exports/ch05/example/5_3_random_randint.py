import random                  # roll a six-sided die
roll = random.randint(1, 6)    # one six-sided die
print(f"Roll: {roll}")
