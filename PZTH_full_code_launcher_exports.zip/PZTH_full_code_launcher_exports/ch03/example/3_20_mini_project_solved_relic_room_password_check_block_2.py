if has_full_access:                       # password and rank both passed
    print("================================")
    print("       RELIC ROOM OPENED        ")
    print("================================")
    print("The ancient door slides aside.")
elif is_password_correct:                 # correct word, insufficient rank
    print("Password accepted, but your rank is too low.")
else:                                     # password did not match
    print("The chamber stays sealed.")

print("Relic check complete.")
